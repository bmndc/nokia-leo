var View = {
  length: 3,
  start: FxaModuleStates.ENTER_ACCOUNT_PN
};

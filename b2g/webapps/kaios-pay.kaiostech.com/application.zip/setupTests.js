import Adapter from 'enzyme-adapter-react-15.4';
import { mount, render, shallow, configure } from 'enzyme';
import cloneDeep from 'lodash.clonedeep';
import PropertiesReader from 'properties-reader';

// global mocks
import './test/__mocks__/history';
import './test/__mocks__/localStorage';
import './test/__mocks__/performance';
import './test/__mocks__/BroadcastChannel';
import {
  mozApps,
  mozL10n,
  kaiAuth,
  mozMobileMessage,
  mozSetMessageHandler,
  mozMobileConnections,
  mozSettings
} from './test/__mocks__/navigator';

configure({ adapter: new Adapter() });

global.mount = mount;
global.render = render;
global.shallow = shallow;
navigator.mozApps = cloneDeep(mozApps);
navigator.mozL10n = cloneDeep(mozL10n);
navigator.kaiAuth = cloneDeep(kaiAuth);
navigator.mozMobileMessage = cloneDeep(mozMobileMessage);
navigator.mozSetMessageHandler = mozSetMessageHandler;
navigator.mozMobileConnections = cloneDeep(mozMobileConnections);
navigator.mozSettings = cloneDeep(mozSettings);
global.l10n_data = PropertiesReader(
  './locales/kaios-pay.en-US.properties'
)._properties;

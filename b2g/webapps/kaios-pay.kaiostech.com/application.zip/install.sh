#!/usr/bin/env bash

# This is a simlified and hacky script simliar to gaia `make reset-gaia`
# Use with your own modification if needed

# This folder contains application.zip and manifest.webapp.
# Usually is the folder after making gaia profile:
#   profile/webapps/kaios-pay.kaiostech.com
KAIPAY="kaios-pay.kaiostech.com"
GAIA_PATH="../.."
KAIPAY_PATH="${GAIA_PATH}/profile/webapps/${KAIPAY}"

LOCAL_WEBAPPS="/data/local/webapps"
SYSTEM_WEBAPPS="/system/b2g/webapps"

# generate profile(application.zip, manifest.webapp)
DEVICE_DEBUG=1 NO_BUNDLE=1 APP=kaios-pay make -C ${GAIA_PATH}/

adb root

adb shell stop b2g
adb shell rm -r /cache/*
adb shell rm -r /data/b2g/*
adb shell rm -r ${LOCAL_WEBAPPS}/${KAIPAY}

adb remount
adb shell rm -r ${SYSTEM_WEBAPPS}/${KAIPAY}

adb push ${KAIPAY_PATH} ${LOCAL_WEBAPPS}/
adb push ${KAIPAY_PATH} ${SYSTEM_WEBAPPS}/

# To correct apps.kaiPayment.manifest
# (should be the same as application ID)
# pull user.js, revise it and push back
# adb pull /system/b2g/defaults/pref/user.js
# adb push user.js /system/b2g/defaults/pref/

adb shell start b2g

# adb reboot

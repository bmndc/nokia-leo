define([ "require", "exports", "module", "./message_list" ], function(e) {
    return [ e("./message_list"), {
        mode: "search"
    } ];
});
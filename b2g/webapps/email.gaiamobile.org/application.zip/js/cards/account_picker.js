define([ "require", "exports", "module", "./folder_picker" ], function(e) {
    return [ e("./folder_picker"), {
        mode: "account"
    } ];
});
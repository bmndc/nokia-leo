// This file is overwritten by the build process to include final build
// credentials either from /build/services.json or from a distribution-specific
// file. A default is provided here so code will run in a non-build mode.
define({
  oauth2: {
    google: {
      clientId:
     '1076439968824-h2hhq8rkbknsqrksvo7hjqmr44aikffs.apps.googleusercontent.com',
      clientSecret: 'F7H7mQ-w6oakrZkAK49LBxEt'
    }
  }
});

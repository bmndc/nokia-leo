(function() {
    function e(e) {
        setTimeout(e);
    }
    window.setZeroTimeout = e;
})();
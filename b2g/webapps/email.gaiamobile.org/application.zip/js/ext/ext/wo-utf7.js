define([ "./utf7" ], function(e) {
    return e;
});
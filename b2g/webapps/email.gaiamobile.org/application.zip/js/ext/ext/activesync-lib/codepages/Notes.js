(function(e, t) {
    "object" == typeof exports ? module.exports = t() : "function" == typeof define && define.amd ? define([], t) : e.ASCPNotes = t();
})(this, function() {
    return {
        Tags: {
            Subject: 5893,
            MessageClass: 5894,
            LastModifiedDate: 5895,
            Categories: 5896,
            Category: 5897
        }
    };
});

onload = function () {
	// <!-- var e = document.getElementById("page_is_dirty");
	// <!-- if (e.value == "no") e.value = "yes"; -->
	// <!-- else { e.value = "no"; location.reload(); } -->
}

var DoodleJump = DoodleJump || {};

DoodleJump.MainMenu = function() {

};

DoodleJump.MainMenu.prototype = {
    preload: function() {
        //loading screen
    },

    create: function() {
        if (globalHighscoreboard == null) {
            globalHighscoreboard = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            localStorage.setObj(highscoreKey, globalHighscoreboard);
        } else {
            globalHighscoreboard = localStorage.getObj(highscoreKey);
        }

        if (G_CurrentLevel == null) {
            G_CurrentLevel = 0;
        } else {
            G_CurrentLevel = localStorage.getItem(levelKey);
        }

        if (G_IsMute == null) {
            G_IsMute = 0;
        } else {
            G_IsMute = localStorage.getItem(muteKey);
        }

        this.buttonIndex = 0;
        this.PanelIndex = 0;
        this.levelIndex = Number(G_CurrentLevel);

        this.backgroundGroup = this.game.add.group();
        this.mainMenuGroup = this.game.add.group();
        // this.buttonGroup = this.game.add.group();
        this.highScoreGroup = this.game.add.group();

        this.mainMenuProperties = {
            background: ['background', 'background_jungle', 'background_space'],
            player: ['TheDoodler', 'TheExplorer', 'TheAstornaute'],
            foreground: ['bg-01', 'bg-02', 'bg-03'],
            levelName: [TEXTS.GAME_CLASSIC_NEW_TEXT[lang], TEXTS.GAME_JUNGLE_NEW_TEXT[lang], TEXTS.GAME_SPACE_NEW_TEXT[lang]]
        };

        this.jumpSFX = this.game.add.audio('jump');

        this.tilebackground = this.game.add.tileSprite(0, 0, 240, 320, 'background');
        this.tilebackground.fixedToCamera = true;
        this.backgroundGroup.add(this.tilebackground);

        this.logo = this.mainMenuGroup.create(this.world.centerX, this.world.centerY - 85, 'logo');
        this.logo.anchor.setTo(0.5, 0.5);

        this.enemy = this.mainMenuGroup.create(this.world.centerX + 75, this.world.centerY - 55, 'enemy');
        this.enemy.anchor.setTo(0.5, 0.5);
        this.enemy.scale.x = this.enemy.scale.y = 0.8;

        this.doodler = this.mainMenuGroup.create(this.world.centerX - 68, this.world.centerY + 62, 'TheDoodler');
        this.doodler.anchor.setTo(0.5, 0.5);
        this.doodler.scale.x = -0.8;
        this.doodler.scale.y = 0.8;

        this.doodlerTween = this.game.add.tween(this.doodler).to({ y: 190 }, 500, Phaser.Easing.Circular.InOut, true, -1, 1000, true).loop(true);
        this.doodlerTween.onLoop.add(this.onDoodlerJump, this);

        this.platform = this.mainMenuGroup.create(this.world.centerX - 75, this.world.centerY + 85, 'greenPlatform');
        this.platform.anchor.setTo(0.5, 0.5);
        this.platform.scale.x = this.platform.scale.y = 0.8;

        this.playButton = this.mainMenuGroup.create(this.world.centerX + 75, this.world.centerY - 23, 'button_short_1');
        this.playButton.anchor.setTo(0.5, 0.5);

        var style = { font: "bold 15px Arial", fill: "#000000", boundsAlignH: "center", boundsAlignV: "center" };

        var playTextStyle = { font: "bold 15px Arial", fill: "#000000", boundsAlignH: "center", boundsAlignV: "center" };
        this.playtext = this.game.add.text(this.playButton.x, this.playButton.y + 1, TEXTS.GAME_PLAY_TEXT[lang], playTextStyle);
        this.playtext.anchor.setTo(0.5);
        this.playtext.scale.x = this.playtext.scale.y = 0.8;
        this.mainMenuGroup.add(this.playtext);

        this.soundButton = this.mainMenuGroup.create(this.world.centerX - 50, this.world.centerY - 2, 'button_normal_2');
        this.soundButton.anchor.setTo(0.5, 0.5);

        let soundTextStyle = { font: "bold 18px Arial", fill: "#000000", boundsAlignH: "right", boundsAlignV: "right" };
        this.soundText = this.game.add.text(this.soundButton.x, this.soundButton.y + 1, TEXTS.GAME_SOUND_TEXT[lang] + " : " + TEXTS.GAME_ON_TEXT[lang], soundTextStyle);
        this.soundText.scale.x = this.soundText.scale.y = 0.8;
        this.soundText.anchor.setTo(0.5);
        this.mainMenuGroup.add(this.soundText);

        this.highScoreButton = this.mainMenuGroup.create(this.world.centerX + 50, this.world.centerY + 35, 'button_normal_2');
        this.highScoreButton.anchor.setTo(0.5, 0.5);

        let highScoreTextStyle = { font: "bold 18px Arial", fill: "#000000", boundsAlignH: "right", boundsAlignV: "right" };

        this.highScoreText = this.game.add.text(this.highScoreButton.x, this.highScoreButton.y + 1, TEXTS.GAME_HIGH_SCORE_TEXT[lang], highScoreTextStyle);
        this.highScoreText.scale.x = this.highScoreText.scale.y = 0.8;
        this.highScoreText.anchor.setTo(0.5);
        this.mainMenuGroup.add(this.highScoreText);

        // console.log("Text Property :" + this.highScoreText.text.split('').length);

        this.playtext.fontSize = this.setFontSize(this.playtext, 12);
        this.soundText.fontSize = this.setFontSize(this.soundText, 12);
        this.highScoreText.fontSize = this.setFontSize(this.highScoreText, 12);

        // this.helpButton = this.mainMenuGroup.create(this.world.centerX + 50, this.world.centerY + 70, 'button_short_2');
        // this.helpButton.anchor.setTo(0.5, 0.5);

        // this.helpText = this.game.add.text(this.world.centerX + 33, this.world.centerY + 63, "help", style);
        // this.helpText.scale.x = this.helpText.scale.y = 0.8;
        // this.mainMenuGroup.add(this.helpText);

        this.foreground = this.mainMenuGroup.create(this.game.world.centerX, 320, 'bg-01')
        this.foreground.anchor.setTo(0.5, 1)
        this.foreground.scale.setTo(1)

        this.levelText = this.game.add.text(this.world.centerX, this.world.centerY + 120, TEXTS.GAME_CLASSIC_NEW_TEXT[lang], {
            font: "bold 20px Arial",
            fill: "#ffffff",
            align: "center"
        });
        this.levelText.anchor.setTo(0.5, 0.5);
        this.levelText.scale.x = this.levelText.scale.y = 0.8;
        //this.levelText.addColor("#FFFFFF", 0);
        this.mainMenuGroup.add(this.levelText);

        this.previousButton = this.mainMenuGroup.create(this.world.centerX - 110, this.world.centerY + 120, 'arrow_left');
        this.previousButton.anchor.setTo(0.5, 0.5);

        this.nextButton = this.mainMenuGroup.create(this.world.centerX + 110, this.world.centerY + 120, 'arrow_right');
        this.nextButton.anchor.setTo(0.5, 0.5);

        this.selectButton = this.mainMenuGroup.create(this.world.centerX - 110, this.world.centerY + 150, 'select');
        this.selectButton.anchor.setTo(0.5, 0.5);

        this.exitButton = this.mainMenuGroup.create(this.world.centerX + 110, this.world.centerY - 150, 'exit');
        this.exitButton.anchor.setTo(0.5, 0.5);

        this.scoreBorder = this.game.add.tileSprite(0, 298, 240, 1, 'background_space');
        this.scoreBorder.fixedToCamera = true;
        this.scoreBorder.visible = true;
        this.mainMenuGroup.add(this.scoreBorder);

        this.highScoreTitle = this.highScoreGroup.create(this.world.centerX - 50, this.world.centerY - 110, 'logo');
        this.highScoreTitle.anchor.setTo(0.5, 0.5);
        this.highScoreTitle.scale.setTo(0.75);
        this.highScoreTitle.angle = -5;

        let highSCoreBoardTextStyle = { font: "bold 18px Arial", fill: "#000000", boundsAlignH: "right", boundsAlignV: "right" };

        this.highScoreTitleText = this.game.add.text(this.world.centerX, 85, TEXTS.GAME_HIGH_SCORE_TEXT[lang], highSCoreBoardTextStyle);
        this.highScoreTitleText.scale.x = this.highScoreTitleText.scale.y = 0.8;
        this.highScoreTitleText.anchor.setTo(0.5, 0);
        this.highScoreGroup.add(this.highScoreTitleText);

        this.backButton = this.highScoreGroup.create(240, 320, 'back');
        this.backButton.anchor.setTo(1, 1);


        let scoreBoardYPos = 120;
        let scoreBoardIndex = 1;
        let highscoreArray = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        for (var i = 0; i < 10; i++) {
            let frame = this.highScoreGroup.create(this.world.centerX + 13, scoreBoardYPos, 'scoreBoard_' + scoreBoardIndex);
            frame.anchor.setTo(0.5, 0.5);
            frame.scale.setTo(0.8, 0.7);

            let highScoreIndex = this.game.add.text(35, scoreBoardYPos + 3, (i + 1) + ' .', highSCoreBoardTextStyle);
            highScoreIndex.scale.x = highScoreIndex.scale.y = 0.8;
            highScoreIndex.anchor.setTo(0, 0.5);
            this.highScoreGroup.add(highScoreIndex);

            let highScore = this.game.add.text(235, scoreBoardYPos + 3, String(globalHighscoreboard[i]), highSCoreBoardTextStyle);
            highScore.scale.x = highScore.scale.y = 0.8;
            highScore.anchor.setTo(1, 0.5);
            this.highScoreGroup.add(highScore);
            scoreBoardYPos += 17.5;
            if (scoreBoardIndex === 1) {
                scoreBoardIndex = 2;
            } else {
                scoreBoardIndex = 1;
            }
        }

        this.highScoreFrame = this.highScoreGroup.create(this.world.centerX, this.world.centerY + 35, 'highScoreFrame');
        this.highScoreFrame.anchor.setTo(0.5, 0.5);
        this.highScoreFrame.scale.setTo(0.8);

        this.mainMenuPanel = [this.playButton, this.soundButton, this.highScoreButton, this.exitButton];
        this.panels = [this.mainMenuPanel]

        this.setKeyConfiguration();

        this.setLevel(this.levelIndex);
        this.setButton(this.buttonIndex);

        this.highScoreGroup.visible = false;

        this.soundText.setText((G_IsMute == 1) ? TEXTS.GAME_SOUND_TEXT[lang] + " : " + TEXTS.GAME_OFF_TEXT[lang] : TEXTS.GAME_SOUND_TEXT[lang] + " : " + TEXTS.GAME_ON_TEXT[lang]);
        this.game.sound.mute = (G_IsMute == 1) ? true : false;

    },

    onDoodlerJump() {
        if (this.doodler.y > 200) {
            this.jumpSFX.play();
        }
    },

    createButton: function(sprite, XPos, YPos, scale, Label) {
        var buttonElement = this.mainMenuGroup.create(this.game.world.centerX + XPos, this.game.world.centerY + YPos, sprite)
        if (Label != null) {
            var buttonLabel = this.game.add.bitmapText(0, 2.5, 'tikiFont', Label, 20)
            buttonLabel.anchor.setTo(0.5)
                // buttonElement.alpha = 0.1
            buttonElement.addChild(buttonLabel)
        }
        buttonElement.anchor.setTo(0.5)
        buttonElement.scale.setTo(scale)
        return buttonElement
    },

    setFontSize(textObject, minFontSize) {
        var fontLength = textObject.text.split('').length;
        var fontSize = 0;
        if (minFontSize < fontLength) {
            fontSize = 17;
        } else {
            fontSize = 18;
        }

        // console.log("Font Size: " + fontSize)
        return fontSize;
    },

    setKeyConfiguration: function() {
        this.upKey = this.game.input.keyboard.addKey(Phaser.Keyboard.UP)
        this.downKey = this.game.input.keyboard.addKey(Phaser.Keyboard.DOWN)
        this.leftKey = this.game.input.keyboard.addKey(Phaser.Keyboard.LEFT)
        this.rightKey = this.game.input.keyboard.addKey(Phaser.Keyboard.RIGHT)
        this.enterKey = this.game.input.keyboard.addKey(Phaser.Keyboard.ENTER)
        this.backKey = this.game.input.keyboard.addKey(Phaser.Keyboard.THREE)
            // this.increaseVolume = this.game.input.keyboard.addKey(Phaser.Keyboard.THREE)
            // this.decreaseVolume = this.game.input.keyboard.addKey(Phaser.Keyboard.ONE)

        this.upKey.onDown.add(function() {
            if (this.PanelIndex === 0) {
                if (this.buttonIndex > 0) {
                    this.buttonIndex -= 1
                } else {
                    this.buttonIndex = this.panels[this.PanelIndex].length - 1
                }
                this.setButton(this.buttonIndex);
                // console.log("Button ID: " + this.buttonIndex)
            }
        }, this)

        this.downKey.onDown.add(function() {
            if (this.PanelIndex === 0) {
                if (this.buttonIndex < this.panels[this.PanelIndex].length - 1) {
                    this.buttonIndex += 1
                } else {
                    this.buttonIndex = 0
                }
                this.setButton(this.buttonIndex);

                // console.log("Button ID: " + this.buttonIndex)
            }
        }, this)

        this.leftKey.onDown.add(function() {
            if (this.PanelIndex === 0) {
                if (this.levelIndex > 0) {
                    this.levelIndex -= 1
                } else {
                    this.levelIndex = this.mainMenuProperties.background.length - 1
                }
                this.setLevel(this.levelIndex);
                // console.log("Level ID: " + this.levelIndex);
            }
        }, this)

        this.rightKey.onDown.add(function() {
            if (this.PanelIndex === 0) {
                if (this.levelIndex < this.mainMenuProperties.background.length - 1) {
                    this.levelIndex += 1
                } else {
                    this.levelIndex = 0
                }
                this.setLevel(this.levelIndex);
                // console.log("Level ID: " + this.levelIndex);
            }
        }, this)

        this.enterKey.onDown.add(function() {
            this.buttonFunction(this.buttonIndex);
        }, this);

        this.backKey.onDown.add(function() {
            // if (this.PanelIndex === 1) {
            //     this.PanelIndex = 0;
            //     this.buttonIndex = 0;
            //     this.highScoreGroup.visible = false;
            //     this.mainMenuGroup.visible = true;
            //     this.setButton(this.buttonIndex);
            // }
        }, this);

        this.game.input.keyboard.addCallbacks(this, function(event) {

            if (event.key == "Backspace") {
                event.preventDefault();
            }

            if (event.key === 'SoftLeft' || event.which == 55) { // softleft or 7
                if (this.PanelIndex === 0) {
                    this.buttonFunction(this.buttonIndex);
                }
                // console.log('Soft Left Button');
            }

            if (event.key === 'SoftRight' || event.which == 57) { // softright or 9
                if (this.PanelIndex === 1) {
                    this.PanelIndex = 0;
                    this.buttonIndex = 0;
                    this.highScoreGroup.visible = false;
                    this.mainMenuGroup.visible = true;
                    this.setButton(this.buttonIndex);
                }
                // console.log('Soft Right Button');
            }
        });
    },

    setButton: function(buttonIndex) {
        for (var i = 0; i < this.panels[this.PanelIndex].length; i++) {
            if (i == buttonIndex) {
                if (i == 0 || i == 3) {
                    this.mainMenuPanel[i].loadTexture((i == 3) ? 'exit_1' : 'button_short_1');
                } else {
                    this.mainMenuPanel[i].loadTexture('button_normal_1');
                }
            } else {
                if (i == 0 || i == 3) {
                    this.mainMenuPanel[i].loadTexture((i == 3) ? 'exit_2' : 'button_short_2');
                } else {
                    this.mainMenuPanel[i].loadTexture('button_normal_2');
                }
            }
        }
    },

    setLevel: function(index) {
        G_CurrentLevel = index;
        // console.log("Level Index: " + index);
        // this.tilebackground.loadTexture(this.mainMenuProperties.background[index]);
        this.foreground.loadTexture(this.mainMenuProperties.foreground[index]);
        this.doodler.loadTexture(this.mainMenuProperties.player[index]);
        this.levelText.setText(this.mainMenuProperties.levelName[index]);
    },

    OnMuteButton: function() {
        if (this.game.sound.mute) {
            // isMute = false;
            G_IsMute = 0;
            localStorage.setItem(muteKey, G_IsMute);
            this.game.sound.mute = false;
            this.soundText.setText(TEXTS.GAME_SOUND_TEXT[lang] + " : " + TEXTS.GAME_ON_TEXT[lang]);
            this.soundText.fontSize = this.setFontSize(this.soundText, 12);
        } else {
            // isMute = true;
            G_IsMute = 1;
            localStorage.setItem(muteKey, G_IsMute);
            this.game.sound.mute = true;
            this.soundText.setText(TEXTS.GAME_SOUND_TEXT[lang] + " : " + TEXTS.GAME_OFF_TEXT[lang]);
            this.soundText.fontSize = this.setFontSize(this.soundText, 12);
        }
    },

    buttonFunction(index) {
        // console.log("Panel Index is :" + this.PanelIndex)
        // console.log("Button Index is : " + this.buttonIndex)
        switch (index) {
            case 0:
                if (this.PanelIndex === 0) {
                    localStorage.setItem(levelKey, G_CurrentLevel);
                    this.state.start('Game');
                }
                break;

            case 1:
                if (this.PanelIndex === 0) {
                    this.OnMuteButton();
                }
                break;

            case 2:
                if (this.PanelIndex === 0) {
                    this.mainMenuGroup.visible = false;
                    this.highScoreGroup.visible = true;
                    this.PanelIndex = 1;
                }
                break;

            case 3:
                if (this.PanelIndex === 0) {
                    window.parent.close();
                }
                break;
        }
    }
};
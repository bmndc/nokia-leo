var DoodleJump = DoodleJump || {};

DoodleJump.game = new Phaser.Game(240, 320, Phaser.CANVAS, '');

DoodleJump.game.state.add('Boot', DoodleJump.Boot);
DoodleJump.game.state.add('Preload', DoodleJump.Preload);
DoodleJump.game.state.add('MainMenu', DoodleJump.MainMenu);
DoodleJump.game.state.add('Game', DoodleJump.Game);

DoodleJump.game.state.start('Boot');

var DoodleJump = DoodleJump || {

};

DoodleJump.Game = function() {

};

DoodleJump.Game.prototype = {
    preload: function() {
        this.game.time.advancedTiming = true;
    },

    create: function() {
        // this.game.time.desiredFps = 30;
        this.gameSettings = {
            background: ['background', 'background_jungle', 'background_space'],
            player: ['TheDoodler', 'TheExplorer', 'TheAstornaute']
        };

        // Background
        this.tilebackground = this.game.add.tileSprite(0, 0, 240, 320, this.gameSettings.background[G_CurrentLevel]);
        this.tilebackground.fixedToCamera = true;

        // camera and platform tracking vars
        this.cameraYMin = 99999;
        this.platformYMin = 99999;
        this.gameStart = false;
        this.jetpackSpawned = false;
        this.doodleFacingLeft = false;

        this.leftKeyDown = false;
        this.rightKeyDown = false;

        this.currentScore = 0;
        this.highScore = globalHighscoreboard;

        this.currentPlatformYPosition;
        // if(this.highScore != null)
        // // console.log("Previous HighScore: " + this.highScore[0]);

        this.currentDoodlerHeight = 0;
        this.scoreOffset = 0;

        this.jetpackFrequency = 40;
        this.enemyFrequency = 500;
        this.numberOfPlatformsToPowerUp = 0;
        this.numberOfPlatformsToEnemy = 0;
        this.accumulator = 0;
        this.currentTimeValue = 0;
        this.dtValue = 0;

        this.jetpack = this.game.add.sprite(-50, 0, 'jetpack');
        this.physics.arcade.enable(this.jetpack);
        this.jetpack.enableBody = false;
        this.jetpack.anchor.set(0.5);
        this.jetpack.fixedToCamera = true;

        this.progressionMultipler = 30;
        this.progressionScore = 0;
        this.maxProgressionMultiplier = 60; // Max distance between 2 platforms
        this.scoreToIncreaseProgression = 100; // Progression
        this.platformXValue = 0;
        this.platformOffset = 0;
        this.movingPlatformStartingScore = 2000;
        this.movingPlatformDecider = 1;
        this.movingPlatformValue = 0;

        this.brokenPlatformValue = 0;
        this.objectOnPreviousPlatform = false;
        this.isPreviousPlatformBroken = false;
        this.isPreviousPlatformEnemy = false;
        this.isPreviousPlatformMoving = false;
        this.enforceGreenPlatformCreation = false;

        this.canPause = false;
        this.canSpawn = true;
        this.tempValue = 1;

        this.jumpSFX = this.game.add.audio('jump');
        this.platformBreakSFX = this.game.add.audio('break');
        this.fallingSFX = this.game.add.audio('falling');

        this.canJump = true;

        // create platforms
        this.platformsCreate();

        // create doodler
        this.doodlerCreate();

        this.spaceScoreBorder = this.game.add.tileSprite(0, 18, 240, 1, 'background');
        this.spaceScoreBorder.fixedToCamera = true;
        this.spaceScoreBorder.visible = false;

        this.scoreBorder = this.game.add.tileSprite(0, 18, 240, 1, 'background_space');
        this.scoreBorder.fixedToCamera = true;
        this.scoreBorder.visible = true;

        var style = { font: "bold 20px Arial", fill: "#000000", boundsAlignH: "center", boundsAlignV: "left" };
        this.text = this.game.add.text(5, 0, "0", style);
        this.text.fixedToCamera = true;

        this.pauseIcon = this.game.add.sprite(240, 0, 'pause-icon');
        this.pauseIcon.anchor.setTo(1, 0)
        this.pauseIcon.fixedToCamera = true;

        this.pauseButtonIndex = 0;
        var pauseTextStyle = { font: "bold 25px Arial", fill: "#ffffff", boundsAlignH: "center", boundsAlignV: "center" };
        var pauseButtonTextstyle = { font: "bold 20px Arial", fill: "#000000", boundsAlignH: "center", boundsAlignV: "left" };
        this.pauseMenuGroup = this.game.add.group();
        this.pauseMenuGroup.fixedToCamera = true;

        this.pauseBG = this.pauseMenuGroup.create(this.world.centerX, this.world.centerY, "bg")
        this.pauseBG.anchor.setTo(0.5);
        this.pauseBG.alpha = 0.8
        this.pauseBG.scale.setTo(1.2, 1.6);

        this.continueButton = this.pauseMenuGroup.create(this.world.centerX, this.world.centerY, 'button_normal_2');
        this.continueButton.anchor.setTo(0.5);

        this.continuetext = this.game.add.text(this.continueButton.x, this.continueButton.y + 5, TEXTS.GAME_RESUME_TEXT[lang], pauseButtonTextstyle);
        this.continuetext.scale.x = this.continuetext.scale.y = 0.8;
        this.continuetext.anchor.setTo(0.5);
        this.pauseMenuGroup.add(this.continuetext);

        this.exitButton = this.pauseMenuGroup.create(this.world.centerX, this.world.centerY + 50, 'button_normal_2');
        this.exitButton.anchor.setTo(0.5);

        this.exitText = this.game.add.text(this.exitButton.x, this.exitButton.y + 5, TEXTS.GAME_EXIT_TEXT[lang], pauseButtonTextstyle);
        this.exitText.scale.x = this.exitText.scale.y = 0.8;
        this.exitText.anchor.setTo(0.5);
        this.pauseMenuGroup.add(this.exitText);

        this.pauseText = this.game.add.text(this.world.centerX, this.world.centerY - 50, "PAUSED", pauseTextStyle);
        this.pauseText.anchor.set(0.5);
        this.pauseMenuGroup.add(this.pauseText);

        this.pauseMenuGroup.visible = false;

        var gameOverTextStyle = { font: "bold 25px Arial", fill: "#000000", boundsAlignH: "center", boundsAlignV: "center" };

        this.gameOverText = this.game.add.text(this.world.centerX, this.world.centerY, TEXTS.GAME_OVER_TEXT[lang], gameOverTextStyle);
        this.gameOverText.anchor.set(0.5);
        this.gameOverText.visible = false;
        this.gameOverText.fixedToCamera = true;

        window.addEventListener('keydown', (e) => this.addKeyDownConfiguration(e));
        window.addEventListener('keyup', (e) => this.addKeyUpConfiguration(e));

        this.setKeyConfiguration();
        if (this.gameStart == false) {
            this.canPause = true;
            this.gameStart = this.doodler.alive = true;
            if (this.doodler.alive) {
                this.doodler.body.gravity.y = 500;
                this.doodler.body.velocity.y = -350;
            }
        }
    },

    setPauseMenuButtons(buttonIndex) {
        if (this.pauseButtonIndex === 0) {
            this.continueButton.loadTexture('button_normal_1')
            this.exitButton.loadTexture('button_normal_2')
        } else {
            this.continueButton.loadTexture('button_normal_2')
            this.exitButton.loadTexture('button_normal_1')
        }
        // // console.log("pauseButtonIndex : " + this.pauseButtonIndex)
    },

    setKeyConfiguration: function() {
        this.upKey = this.game.input.keyboard.addKey(Phaser.Keyboard.UP)
        this.downKey = this.game.input.keyboard.addKey(Phaser.Keyboard.DOWN)
        this.leftKey = this.game.input.keyboard.addKey(Phaser.Keyboard.LEFT)
        this.rightKey = this.game.input.keyboard.addKey(Phaser.Keyboard.RIGHT)
        this.enterKey = this.game.input.keyboard.addKey(Phaser.Keyboard.ENTER)
            // this.increaseVolume = this.game.input.keyboard.addKey(Phaser.Keyboard.THREE)
            // this.decreaseVolume = this.game.input.keyboard.addKey(Phaser.Keyboard.ONE)

        this.pauseButton = this.game.input.keyboard.addKey(Phaser.Keyboard.THREE)

        // For Debug Purpose Only
        this.pauseButton.onDown.add(function() {
            // if (this.canPause) {
            //   // console.log("Pause the game");
            //   if (!this.game.paused) {
            //     this.game.paused = true;
            //     this.pauseIcon.visible = false;
            //     this.pauseMenuGroup.visible = true;
            //     this.setPauseMenuButtons(this.pauseButtonIndex);
            //   }
            // }
        }, this);

        this.upKey.onDown.add(function() {
            if (this.game.paused) {
                if (this.pauseButtonIndex === 0) {
                    this.pauseButtonIndex = 1;
                } else if (this.pauseButtonIndex === 1) {
                    this.pauseButtonIndex = 0;
                }
                this.setPauseMenuButtons(this.pauseButtonIndex);
            }
        }, this)

        this.downKey.onDown.add(function() {
            if (this.game.paused) {
                if (this.pauseButtonIndex === 0) {
                    this.pauseButtonIndex = 1;
                } else if (this.pauseButtonIndex === 1) {
                    this.pauseButtonIndex = 0;
                }
                this.setPauseMenuButtons(this.pauseButtonIndex);
            }
        }, this)

        this.enterKey.onDown.add(function() {
            if (this.game.paused) {
                if (this.pauseButtonIndex === 0) {
                    this.pauseButtonIndex = 0;
                    this.game.paused = false;
                    this.pauseMenuGroup.visible = false;
                    this.pauseIcon.visible = true;
                }
                if (this.pauseButtonIndex === 1) {
                    this.game.paused = false;
                    this.gameStart = false;
                    if (!isFreeTrialMode) {
                        this.state.start('MainMenu');
                    } else {
                        window.parent.unloadIframe();
                        // this.state.start('TNBMenu');
                    }
                }
            }
        }, this);

        this.game.input.keyboard.addCallbacks(this, function(event) {
            // if (event.key === 'SoftLeft') {

            // }

            if (event.key === 'SoftRight') {
                if (this.canPause) {
                    // console.log("Pause the game");
                    if (!this.game.paused) {
                        this.game.paused = true;
                        this.pauseIcon.visible = false;
                        this.pauseMenuGroup.visible = true;
                        this.setPauseMenuButtons(this.pauseButtonIndex);
                    }
                }
            }
        });
    },

    addKeyUpConfiguration: function(e) {
        if (this.gameStart) {
            if (e.keyCode === 37 || e.keyCode === 52) {
                this.leftKeyDown = false;
                this.doodler.body.velocity.x = 0;
            } else if (e.keyCode === 39 || e.keyCode === 54) {
                this.rightKeyDown = false;
                this.doodler.body.velocity.x = 0;
            }
        }

        if (e.key == "Backspace") {
            e.preventDefault();
        }
    },

    addKeyDownConfiguration: function(e) {
        if (this.gameStart) {
            if (e.keyCode === 38) {
                this.movePlayerUp();
            } else if (e.keyCode === 37 || e.keyCode === 52) {
                if (!this.leftKeyDown) {
                    this.accumulator = 0;
                    this.currentTimeValue = this.game.time.time;
                }
                this.leftKeyDown = true;
                this.movePlayerLeft();
            } else if (e.keyCode === 39 || e.keyCode === 54) {
                if (!this.rightKeyDown) {
                    this.accumulator = 0;
                    this.currentTimeValue = this.game.time.time;
                }
                this.rightKeyDown = true;
                this.movePlayerRight();
            } else if (e.keyCode === 83) {
                this.canJump = false;
            }
        }

        if (e.key == "Backspace") {
            e.preventDefault();
        }
    },

    movePlayerUp: function() {
        if (this.doodler.body.touching.down && this.gameStart && this.canJump) {
            this.doodler.body.velocity.y = -350;
            this.jumpSFX.play();
        }
    },

    movePlayerLeft: function() {
        if (this.gameStart) {
            this.doodleFacingLeft = true;
            if (G_CurrentLevel == 0) {
                this.doodler.anchor.setTo(0.5, 0.5);
                this.doodler.body.setSize(28, 46, 8, 0);
                this.booster.x = 20;
            } else if (G_CurrentLevel == 1) {
                this.doodler.anchor.setTo(0.5, 0.5);
                this.doodler.body.setSize(31, 53, 5, 0);
                this.booster.x = 20;
            } else if (G_CurrentLevel == 2) {
                this.doodler.anchor.setTo(0.5, 0.5);
                this.doodler.body.setSize(35, 50, 1.8, 0);
                this.booster.x = 20;
            }
            this.doodler.scale.x = 1;
        }
    },

    movePlayerRight: function(value) {
        if (this.gameStart) {
            if (this.doodler.alive) {
                this.doodleFacingLeft = false;
                if (G_CurrentLevel == 0) {
                    this.doodler.anchor.setTo(0.85, 0.5);
                    this.doodler.body.setSize(28, 46, 18, 0);
                    this.booster.x = 5;
                } else if (G_CurrentLevel == 1) {
                    this.doodler.anchor.setTo(0.61, 0.5);
                    this.doodler.body.setSize(31, 53, 5, 0);
                    this.booster.x = 14;
                } else if (G_CurrentLevel == 2) {
                    this.doodler.anchor.setTo(0.53, 0.5);
                    this.doodler.body.setSize(35, 50, 1.2, 0);
                    this.booster.x = 18;
                }
                this.doodler.scale.x = -1;
            }
        }
    },

    jetPackPowerUp: function() {
        //// console.log("Colliding with Pack");
        this.jetpack.reset(-50, this.doodler.y);
        this.jetpack.enableBody = false;
        this.jetpack.visible = false;
        this.jetpackCollected = true;
        this.jetpack.fixedToCamera = true;
        this.doodler.body.checkCollision.down = false;

        if (this.doodleFacingLeft) {
            this.booster.x = 20;
        } else {
            this.booster.x = 5;
        }
        this.booster.visible = true;
        this.game.time.events.add(1000, this.enableGreenPlatformCreation, this);
        this.game.time.events.add(2000, this.jetPackPowerDown, this);
        this.game.time.events.add(2000, this.disableGreenPlatformCreation, this);
        this.game.time.events.add(3000, this.returnPlayerToNormal, this);
    },


    jetPackPowerDown: function() {
        //this.jetpack.visible = true;
        this.jetpackCollected = false;
        this.booster.visible = false;
        this.numberOfPlatformsToPowerUp = 0;
        this.progressionScore = this.currentScore;
    },

    returnPlayerToNormal: function() {
        this.doodler.body.checkCollision.down = true;
    },

    overlappingPlatforms: function() {
        // console.log("Overlapping Platform");
    },

    updateScore: function(score) {
        this.currentScore = (((this.currentScore / 10000) + score - this.scoreOffset) * -1) * 0.1;
        this.text.setText(Math.round(this.currentScore, 0));
        //// console.log(this.currentScore);
    },

    update: function(game) {
        // this is where the main magic happens
        // the y offset and the height of the world are adjusted
        // to match the highest point the doodler has reached
        if (this.doodler.alive) {
            this.world.setBounds(0, -this.doodler.yChange, this.world.width, this.game.height + this.doodler.yChange);
        }
        // else{
        //   this.world.setBounds( 0, 0, this.world.width, this.game.height + 1000 );
        // }

        // the built in camera follow methods won't work for our needs
        // this is a custom follow style that will not ever move down, it only moves up
        if (this.doodler.alive) {
            this.cameraYMin = Math.min(this.cameraYMin, this.doodler.y - this.game.height + 130);
            this.camera.y = this.cameraYMin;
            //// console.log("Camera Position" + this.camera.y);
        }
        // else{ 

        // }

        // // console.log("Doodler Height " +  this.doodler.y);
        // // console.log("Current Doodler Height " +  this.currentDoodlerHeight);

        if (this.doodler.y < this.currentDoodlerHeight) {
            this.currentDoodlerHeight = this.doodler.y;
            this.updateScore(this.currentDoodlerHeight);
        }
        this.game.physics.arcade.overlap(this.doodler, this.jetpack, this.jetPackPowerUp, null, this);

        this.physics.arcade.collide(this.doodler, this.platforms, (sprite1, sprite2) => {

            if (sprite2.name == "enemy") {
                if (sprite2.body.touching.up) {
                    this.doodler.body.checkCollision.up = false;
                    this.doodler.body.checkCollision.left = false;
                    this.doodler.body.checkCollision.right = false;
                    this.movePlayerUp();
                } else {
                    if (this.doodler.alive) {
                        this.fallingSFX.play();
                        this.canPause = this.jetpackCollected = false;
                        this.gameOverText.visible = true;
                        this.doodler.alive = false;
                        this.doodler.body.gravity.y = 500;
                        this.game.time.events.add(2000, this.gameOverCondition, this);
                    }
                    //this.state.start('MainMenu');
                }
            }

            if (sprite2.name == "green" || sprite2.name == "horizontal" || sprite2.name == "vertical") {
                this.movePlayerUp();
            }
            if (sprite2.name == "broken") {
                this.platformBreakSFX.play();
                sprite2.body.gravity.y = 5000;
            }
        }, null, this);

        this.game.physics.arcade.overlap(this.doodler, this.platforms, (sprite1, sprite2) => {
            if (sprite2.name == "enemy" && this.doodler.alive) {
                //// console.log("Colliding with Enemy");
                this.doodler.body.checkCollision.up = true;
                this.doodler.body.checkCollision.left = true;
                this.doodler.body.checkCollision.right = true;
                this.doodler.body.checkCollision.down = false;
                //this.camera.y = this.cameraYMin + 1000;
            }
        }, null, this);

        //   this.physics.arcade.collide( this.doodler, this.platforms, function(player, platformContainer) {
        //     this.movePlayerUp();
        // }, );
        this.doodlerMove();

        if (this.gameStart) {
            if (this.leftKeyDown) {
                //// console.log(game);
                this.dtValue = (this.game.time.physicsElapsed);
                //// console.log(this.dtValue);
                this.doodler.body.velocity.x = -5000 * this.dtValue;
                this.currentTimeValue = game.time.time;
            } else if (this.rightKeyDown) {
                //// console.log(game);
                this.dtValue = (this.game.time.physicsElapsed);
                //// console.log(this.dtValue);
                this.doodler.body.velocity.x = 5000 * this.dtValue;
                this.currentTimeValue = game.time.time;
            }
        }

        var dtValueRef = this.dtValue;

        if ((this.currentScore >= this.progressionScore + this.scoreToIncreaseProgression) && (this.progressionMultipler < this.maxProgressionMultiplier) && !this.jetpackCollected) {
            this.progressionMultipler += 1;
            //// console.log("Increasing Platform Height" + this.progressionMultipler);
            this.progressionScore = this.currentScore;
        }
        // for each plat form, find out which is the highest
        // if one goes below the camera view, then create a new one at a distance from the highest one
        // these are pooled so they are very performant
        this.platforms.forEachAlive(function(elem) {

            if (elem.name == "horizontal" || elem.name == "enemy") {
                elem.x += 20 * dtValueRef * elem.customDirection;
                if (elem.x > 184) {
                    elem.customDirection = -1
                }
                if (elem.x < 4) {
                    elem.customDirection = 1;
                }
            }
            if (elem.name == "vertical") {
                elem.y += 20 * dtValueRef * elem.customDirection;
                if (elem.y > (elem.yValue + 30)) {
                    elem.customDirection = -1;
                }
                if (elem.y < (elem.yValue - 20)) {
                    elem.customDirection = 1;
                }
            }
            this.platformYMin = Math.min(this.platformYMin, elem.y);

            if (elem.name == "vertical") {
                if (elem.y > (this.camera.y + this.game.height + 50)) {
                    elem.kill();
                    this.platformsCreateOne(this.rnd.integerInRange(0, this.world.width - 50), this.platformYMin - this.progressionMultipler, 50);
                }
            } else {
                if (elem.y > this.camera.y + this.game.height) {
                    elem.kill();
                    this.platformsCreateOne(this.rnd.integerInRange(0, this.world.width - 50), this.platformYMin - this.progressionMultipler, 50);
                }
            }
        }, this);

        //this.tempValue = tempValue;
    },

    shutdown: function() {
        // reset everything, or the world will be messed up
        this.world.setBounds(0, 0, this.game.width, this.game.height);
        this.cursor = null;
        this.doodler.destroy();
        this.doodler = null;
        this.platforms.destroy();
        this.platforms = null;
    },

    enableGreenPlatformCreation: function() {
        this.enforceGreenPlatformCreation = true;
    },

    disableGreenPlatformCreation: function() {
        this.enforceGreenPlatformCreation = false;
    },

    platformsCreate: function() {
        // platform basic setup
        this.platforms = this.add.group();
        this.platforms.enableBody = true;
        this.platforms.createMultiple(20, 'greenPlatform');

        this.movingPlatforms = this.add.group();
        this.movingPlatforms.enableBody = true;


        // create the base platform, with buffer on either side so that the doodler doesn't fall through
        //this.platformsCreateOne( -16, this.world.height - 16, this.world.width + 16 );
        // create a batch of platforms that start to move up the level

        for (var i = 0; i < 19; i++) {
            this.randomIntegerValue = this.rnd.integerInRange(0, this.world.width - 50);
            this.platformsCreateOne(this.randomIntegerValue, this.world.height - (this.progressionMultipler * i), 50);
        }
    },

    platformsCreateOne: function(x, y, width) {
        if (y != this.currentPlatformYPosition) {
            this.currentPlatformYPosition = y;

            // this is a helper function since writing all of this out can get verbose elsewhere      
            // console.log("Progression Multiplier " + this.progressionMultipler);
            var platform = this.platforms.getFirstDead();

            this.platformXValue = (platform.width / 2) + (this.rnd.integerInRange(-28, 158));
            if (this.objectOnPreviousPlatform) {
                this.objectOnPreviousPlatform = false;
                platform.reset(this.platformXValue, y - 50);
            } else {
                platform.reset(this.platformXValue, y);
                if (this.isPreviousPlatformEnemy) {
                    this.isPreviousPlatformEnemy = false;
                }
            }
            platform.body.gravity.y = 0;
            //Determine if the next platform will be broken or not
            this.brokenPlatformValue = this.rnd.integerInRange(0, 8);
            this.movingPlatformValue = this.rnd.integerInRange(0, 100);

            if (this.enforceGreenPlatformCreation) {
                // console.log("Enforcing Green platform");
                platform.name = "green";
                platform.loadTexture("greenPlatform");
                platform.body.setSize(54, 14, 0, 0);
                platform.body.immovable = true;
                this.numberOfPlatformsToPowerUp += 1;
                this.numberOfPlatformsToEnemy += 1;
                if (this.progressionMultipler > 65 && this.isPreviousPlatformBroken) {
                    platform.reset(this.platformXValue, (y + 50));
                }
                this.isPreviousPlatformBroken = this.isPreviousPlatformEnemy = this.isPreviousPlatformMoving = false;
            } else {
                if (this.brokenPlatformValue == 0 && this.isPreviousPlatformBroken == false && this.isPreviousPlatformMoving == false && this.isPreviousPlatformEnemy == false && this.currentScore > 100) {
                    platform.name = "broken";
                    platform.loadTexture("brokenPlatform");
                    platform.body.setSize(54, 14, 0, 0);
                    platform.body.immovable = false;
                    this.isPreviousPlatformBroken = true;
                    this.isPreviousPlatformEnemy = false;
                    if (this.progressionMultipler > 65) {
                        platform.reset(this.platformXValue, (y + 35));
                    }
                } else if (this.currentScore > this.movingPlatformStartingScore && this.movingPlatformValue < (this.world.height / 400) && this.isPreviousPlatformBroken == false && this.isPreviousPlatformMoving == false) {
                    this.movingPlatformDecider = this.rnd.integerInRange(0, 2);
                    if (this.movingPlatformDecider == 0) {
                        platform.name = "horizontal";
                        platform.loadTexture("horizontal_platform");
                    } else if (this.movingPlatformDecider == 1) {
                        platform.name = "vertical";
                        platform.loadTexture("vertical_platform");
                        platform.reset(this.platformXValue, (y - 25));
                        platform.yValue = (y - 25);
                    }
                    platform.body.setSize(54, 14, 0, 0);
                    platform.body.immovable = true;
                    platform.customDirection = 1;
                    this.isPreviousPlatformMoving = true;
                    this.isPreviousPlatformEnemy = false;
                    this.isPreviousPlatformBroken = false;
                    //// console.log("Spawning " + platform.name + " moving platform" + platform.y);
                } else if (this.numberOfPlatformsToEnemy == this.enemyFrequency && !this.isPreviousPlatformEnemy) {
                    platform.name = "enemy";
                    if (G_CurrentLevel == 0) {
                        platform.loadTexture("enemy");
                    } else if (G_CurrentLevel == 1) {
                        platform.loadTexture("enemy_jungle");
                    } else if (G_CurrentLevel == 2) {
                        platform.loadTexture("enemy_space");
                    }
                    platform.reset(this.platformXValue, (y - 30));
                    platform.body.setSize(38, 51, 0, 0);
                    platform.body.checkCollision.up = true;
                    platform.body.checkCollision.left = true;
                    platform.body.checkCollision.right = true;
                    platform.customDirection = 1;
                    this.isPreviousPlatformEnemy = true;
                    this.isPreviousPlatformBroken = false;
                    this.isPreviousPlatformMoving = false;
                    this.numberOfPlatformsToEnemy = 0;
                    //// console.log("Spawning enemy" + platform.y);
                } else {
                    platform.name = "green";
                    platform.loadTexture("greenPlatform");
                    platform.body.setSize(54, 14, 0, 0);
                    platform.body.immovable = true;
                    this.numberOfPlatformsToPowerUp += 1;
                    this.numberOfPlatformsToEnemy += 1;
                    // // console.log(this.progressionMultipler);
                    // // console.log(this.isPreviousPlatformBroken);
                    if (this.progressionMultipler > 65 && this.isPreviousPlatformBroken) {
                        //// console.log("Spawning Closer");
                        platform.reset(this.platformXValue, (y + 50));
                    }
                    this.isPreviousPlatformBroken = this.isPreviousPlatformEnemy = this.isPreviousPlatformMoving = false;
                    //// console.log("Spawning " + platform.name + " platform" + platform.y);
                }
            }

            if (this.numberOfPlatformsToPowerUp == this.jetpackFrequency && !this.jetpackCollected && !this.isPreviousPlatformBroken && !this.isPreviousPlatformEnemy) {
                platform.addChild(this.jetpack);
                this.objectOnPreviousPlatform = this.jetpackSpawned = true;
                this.jetpack.reset(27, -14);
                //this.jetpack.reset(this.platformXValue + 27, y - 17);
                this.jetpack.enableBody = true;
                this.jetpack.visible = true;
                this.jetpack.fixedToCamera = false;
            }

            //.onComplete.add(this.tweenBack, this);
            //this.canSpawn = false;
            return platform;
        }
    },

    doodlerCreate: function() {
        // basic doodler setup
        this.doodler = this.game.add.sprite(this.world.centerX, this.world.height - 36, this.gameSettings.player[G_CurrentLevel]);
        this.doodler.anchor.setTo(0.5, 0.5);

        this.booster = this.game.add.sprite(20, -15, 'booster');
        this.doodler.addChild(this.booster);
        this.booster.visible = false;


        // track where the doodler started and how much the distance has changed from that point
        this.doodler.yOrig = this.doodler.y;
        this.doodler.yChange = 0;

        // doodler collision setup
        // disable all collisions except for down
        this.physics.arcade.enable(this.doodler);
        this.doodler.body.gravity.y = 0;
        this.doodler.body.checkCollision.up = false;
        this.doodler.body.checkCollision.left = false;
        this.doodler.body.checkCollision.right = false;
        this.doodler.body.checkCollision.down = true;
        if (G_CurrentLevel == 0) {
            this.doodler.body.setSize(28, 46, 8, 0);
        } else if (G_CurrentLevel == 1) {
            this.doodler.body.setSize(31, 53, 5, 0);
        } else if (G_CurrentLevel == 2) {
            this.doodler.body.setSize(35, 50, 1.8, 0);
        }
        this.currentDoodlerHeight = this.scoreOffset = this.doodler.y;
    },

    doodlerMove: function() {
        if (this.jetpackCollected == true) {
            this.doodler.body.velocity.y = -700;
        }
        // wrap world coordinated so that you can warp from left to right and right to left
        if (this.doodler.alive) {
            this.world.wrap(this.doodler, this.doodler.width / 8, false);
        }

        // track the maximum amount that the doodler has travelled
        this.doodler.yChange = Math.max(this.doodler.yChange, Math.abs(this.doodler.y - this.doodler.yOrig));

        // if the doodler falls below the camera view, gameover
        if (this.doodler.y > this.cameraYMin + this.game.height && this.doodler.alive) {
            //this.state.start( 'Game' );
            this.doodler.body.checkCollision.down = false;
            this.camera.y = this.cameraYMin + 1000;
            this.fallingSFX.play();
            this.canPause = false;
            this.gameOverText.visible = true;
            this.doodler.alive = false;
            this.game.time.events.add(2000, this.gameOverCondition, this);
            //this.cameraYMin += 2000;
        }
    },

    gameOverCondition: function() {
        this.checkHighScore(this.highScore, this.currentScore)
        window.removeEventListener('keydown', (e) => this.addKeyDownConfiguration(e));
        window.removeEventListener('keyup', (e) => this.addKeyUpConfiguration(e));
        this.gameStart = false;
        gameRestart = true;
        if (!isFreeTrialMode) {
            this.state.start('MainMenu');
        } else {
            window.parent.unloadIframe();
            // this.state.start('TNBMenu');
        }
        //// console.log("Game Over");
        //this.game.time.events.add(2000, this.jetPackPowerDown, this);
    },

    checkHighScore(previousHighScore, currentScore) {
        if (previousHighScore == null || currentScore > 0) { // previousHighScore[0]
            previousHighScore = Math.round(currentScore, 0);
            globalHighscoreboard.unshift(previousHighScore);
            globalHighscoreboard.pop();
            localStorage.setObj(highscoreKey, globalHighscoreboard)
                // console.log("HighScore: " + globalHighscoreboard);
        }
    },

    renderGroup: function(member) {
        this.game.debug.body(member);
    },

    render: function() {
        // this.game.debug.text(this.game.time.fps, 2, 14, "#00ff00");
        /* if(this.dummyObstacle != null){*/
        // if(this.jetpack.body.enable){
        //   this.game.debug.body(this.jetpack);
        // }
        // this.game.debug.body(this.doodler);
        // // this.game.debug.body(this.enemy);
        // this.platforms.forEachAlive(this.renderGroup, this);
    }
};
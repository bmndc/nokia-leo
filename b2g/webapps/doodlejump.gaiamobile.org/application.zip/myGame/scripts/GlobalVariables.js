Storage.prototype.setObj = function(key, obj) {
    return this.setItem(key, JSON.stringify(obj))
}
Storage.prototype.getObj = function(key) {
    return JSON.parse(this.getItem(key))
}

// Local Storage
var highscoreKey = "dj_highscore_02";
var levelKey = "dj_level";
var muteKey = "dj_mute"

// Global Variables
var highScore = 0;
var globalVolume = 1;
var isMute = false;
var setKeyListener = false;
var globalHighscoreboard = localStorage.getObj(highscoreKey);
var G_CurrentLevel = localStorage.getItem(levelKey);
var G_IsMute = localStorage.getItem(muteKey);
var gamePrice = null;
var transactionHistory = null;

var IMEI = null;
var validSimSlot = null;

var freeTrials = 3;
var isFreeTrialMode = window.parent.isFreeTrialMode;

var certifiedMode = false;
var gameRestart = false;

var daysLeft = 0;
var bought = false;

var lang = window.parent.tnb_lang;
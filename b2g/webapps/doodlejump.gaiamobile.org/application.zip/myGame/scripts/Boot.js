var DoodleJump = DoodleJump || {};

DoodleJump.Boot = function(){

};

//setting game configuration and loading the assets for the loading screen
DoodleJump.Boot.prototype = {
  preload: function() {
    //loading screen
  },

  create: function() {
    this.game.time.desiredFps = 30;  
    this.game.time.advancedTiming = true;
    
    //this.stage.backgroundColor = '#6bf';

    // scaling
    this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    this.scale.maxWidth = this.game.width;
    this.scale.maxHeight = this.game.height;
    this.scale.pageAlignHorizontally = true;
    this.scale.pageAlignVertically = true;
    this.scale.setScreenSize ( true );

    //physics system
    this.game.physics.startSystem(Phaser.Physics.ARCADE);

    //Prelaoding Assets
    this.state.start('Preload');
  }
};

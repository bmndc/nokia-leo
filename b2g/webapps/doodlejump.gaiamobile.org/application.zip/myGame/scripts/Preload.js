var DoodleJump = DoodleJump || {};

//loading the game assets
DoodleJump.Preload = function() {};

DoodleJump.Preload.prototype = {
    preload: function() {
        //show loading screen
        // this.gameLoadingText = this.game.add.bitmapText(this.game.world.centerX, this.game.world.centerY + 70, 'numbers', 'LOADING...', 30);
        // this.gameLoadingText.anchor.setTo(0.5);

        //Load Audio
        this.load.audio('jump', 'assets/audio/jump.mp3');
        this.load.audio('break', 'assets/audio/break.mp3');
        this.load.audio('falling', 'assets/audio/falling.mp3');

        //load game assets
        this.load.image('background', 'assets/sprites/background.png');
        this.load.image('background_jungle', 'assets/sprites/background_jungle.png');
        this.load.image('background_space', 'assets/sprites/background_space.png');
        this.load.image('booster', 'assets/sprites/booster.png');
        this.load.image('brokenPlatform', 'assets/sprites/brokenPlatform.png');
        this.load.image('enemy', 'assets/sprites/Enemy.png');
        this.load.image('enemy_jungle', 'assets/sprites/Enemy_jungle_320.png');
        this.load.image('enemy_space', 'assets/sprites/Enemy_space_320.png');
        this.load.image('greenPlatform', 'assets/sprites/greenPlatform.png');
        this.load.image('jetpack', 'assets/sprites/jetpack_320.png');
        this.load.image('TheAstornaute', 'assets/sprites/TheAstornaute.png');
        this.load.image('TheExplorer', 'assets/sprites/TheExplorer.png');
        this.load.image('TheDoodler', 'assets/sprites/TheDoodler.png');
        this.load.image('horizontal_platform', 'assets/sprites/platform_horizontal.png');
        this.load.image('vertical_platform', 'assets/sprites/platform_vertical.png');

        this.load.image('jump_button', 'assets/sprites/JumpButton.png');

        //main menu
        this.load.image('mainmenu', 'assets/sprites/mainmenu.png');
        this.load.image('bg-01', 'assets/sprites/bg-01.png');
        this.load.image('bg-02', 'assets/sprites/bg-02.png');
        this.load.image('bg-03', 'assets/sprites/bg-03.png');

        this.load.image('back', 'assets/sprites/back.png');
        this.load.image('select', 'assets/sprites/select.png');
        this.load.image('exit_1', 'assets/sprites/exit_1.png');
        this.load.image('exit_2', 'assets/sprites/exit_2.png');

        this.load.image('button-select', 'assets/sprites/button-select.png');
        this.load.image('button-unselect', 'assets/sprites/button-unselect.png');

        this.load.image('button_normal_1', 'assets/sprites/button_normal_1.png');
        this.load.image('button_normal_2', 'assets/sprites/button_normal_2.png');
        this.load.image('button_short_1', 'assets/sprites/button_short_1.png');
        this.load.image('button_short_2', 'assets/sprites/button_short_2.png');

        this.load.image('arrow_left', 'assets/sprites/arrow_left.png');
        this.load.image('arrow_right', 'assets/sprites/arrow_right.png');

        this.load.image('logo', 'assets/sprites/CR_logo.png');

        this.load.image('highScoreFrame', 'assets/sprites/highScoreFrame.png');
        this.load.image('scoreBoard_2', 'assets/sprites/scoreBoard_2.png');
        this.load.image('scoreBoard_1', 'assets/sprites/scoreBoard_1.png');
        this.load.image('bg', 'assets/sprites/bg.png');
        this.load.image('pause-icon', 'assets/sprites/pause-icon.png');

        this.load.image('SplashScreen', 'assets/sprites/DJ_splash.png');
    },

    create: function() {
        // this.logoScreen = this.add.sprite(0, 0, 'HammerplayLogo');
        // this.game.time.events.add(2000, this.SplashScreen, this);
        let loadingwheel = parent.document.getElementById('loadingwheel');
        // console.log(loadingwheel);
        if (typeof loadingwheel != "undefined" || loadingwheel != null) {
            loadingwheel.style.display = "none";
        }
        // this.loadGame();
        this.SplashScreen();
    },

    SplashScreen: function() {
        this.splashScreen = this.add.sprite(0, 0, 'SplashScreen');
        // if(this.skipTNB == true) {
        this.game.time.events.add(2000, this.loadGame, this);
        // }
    },

    loadGame: function() {
        // this.game.time.events.add(2000, function(){this.state.start('TNBMenu');}, this);
        this.state.start('MainMenu');
    }

    // FormatNumberLength: function (num, length) {
    //   var r = "" + num;
    //   while (r.length < length) {
    //     r = "0" + r;
    //   }
    //   return r;
    // }
};
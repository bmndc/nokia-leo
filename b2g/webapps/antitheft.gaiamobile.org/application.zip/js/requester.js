
const XHR_TIMEOUT_MS=60000;class Requester{constructor(timeout=XHR_TIMEOUT_MS){this._timeout=timeout;this._hawkCredentials=null;this._deviceInfo=null;this._timeOffset=null;this.hawk=hawk;}
setDeviceInfo(deviceInfo){this._deviceInfo={'ct':deviceInfo.ct,'dev_utc':deviceInfo.utc,'dev_utc_off':deviceInfo.utcOff,'dev_build_id':deviceInfo.buildID,'dev_build_number':(deviceInfo.buildNumber)?deviceInfo.buildNumber:null};}
_caculateOffset(dateGMTStr){let offset=0;if(dateGMTStr){let serverGMTMillisTime=Date.parse(this._getUTCTime(dateGMTStr));let localUTCMillisTime=Date.parse(new Date().toUTCString());offset=serverGMTMillisTime-localUTCMillisTime;}
return offset;}
_getUTCTime(dateStr){return new Date(Date.parse(dateStr)).toUTCString();}
_broadcast(prevOffest,nowOffset){const event=new CustomEvent("hawkrequester:offsetchange",{detail:{msg:'this._timeOffset in hawk-requester has been changed!',previous:prevOffest,current:nowOffset}});window.dispatchEvent(event);}
_send(options){return new Promise((resolve,reject)=>{const params=JSON.stringify(options.params);const paramsCompressed=options.paramsCompressed;const url=options.url;const method=options.method;const authorization=options.authorization;const extraHeaders=options.extraHeaders;const xhr=new XMLHttpRequest({mozSystem:true});xhr.open(method,url,true);xhr.timeout=this._timeout;xhr.setRequestHeader('Content-Type','application/json');xhr.withCredentials=true;xhr.responseType='';if(extraHeaders){Object.keys(extraHeaders).forEach(function(key){let val=extraHeaders[key];xhr.setRequestHeader(key,val);});}
if(authorization){xhr.setRequestHeader('Authorization',authorization);}else if(this._hawkCredentials){let hawkHeader=this.getHawkHeader(params,url,method);xhr.setRequestHeader('Authorization',hawkHeader.field);}
if(this._deviceInfo){const deviceInfo=this._deviceInfo;Object.keys(deviceInfo).forEach(function(key){let val=deviceInfo[key];xhr.setRequestHeader(key,val);});}
xhr.onload=function fmdr_xhr_onload(){if(xhr.status>=200&&xhr.status<300){resolve(xhr.response);}else{reject({status:xhr.status,statusText:xhr.statusText,responseText:xhr.responseText,date:xhr.getResponseHeader('date')});}};xhr.onerror=function fmd_xhr_onerror(){reject({status:xhr.status,statusText:xhr.statusText,responseText:xhr.responseText,date:xhr.getResponseHeader('date')});};xhr.ontimeout=function fmd_xhr_ontimeout(){xhr.onerror();};let data=params;if(paramsCompressed){data=paramsCompressed;}
if(data){xhr.send(data);}else{xhr.send(null);}});}
setHawkCredentials(kid,macKey){this._hawkCredentials={id:kid,key:convertKey(macKey),algorithm:'sha256'};}
send(options){return new Promise((resolve,reject)=>{this._send(options).then(result=>{resolve(result);},error=>{if(error.status===401){const prevOffset=this._timeOffset;this._timeOffset=this._caculateOffset(error.date);this._broadcast(prevOffset,this._timeOffset);this._send(options).then(result=>{resolve(result);},error=>{reject(error);});}else{reject(error);}});});}
getHawkHeader(params,url,method){let credentials={credentials:this._hawkCredentials};if(this._timeOffset){credentials['timestamp']=Math.floor((Date.now()+this._timeOffset)/1000)}
if(params){credentials.payload=params;credentials.contentType='application/json';}
let hawkHeader=hawk.client.header(url,method,credentials);return hawkHeader;}
get serverTimeOffset(){return this._timeOffset;}
set serverTimeOffset(value){this._timeOffset=value;}}
function convertKey(key){var key_bin=window.atob(key);var key_array=new ArrayBuffer(key_bin.length);var key_uint8=new Uint8Array(key_array);for(var i=0;i<key_uint8.length;i++){key_uint8[i]=key_bin.charCodeAt(i);}
return toHexString(key_uint8);}
function toHexString(uint8arr){if(!uint8arr){return'';}
var hexStr='';for(var i=0;i<uint8arr.length;i++){var hex=(uint8arr[i]&0xff).toString(16);hex=(hex.length===1)?'0'+hex:hex;hexStr+=hex;}
return hexStr.toUpperCase();}
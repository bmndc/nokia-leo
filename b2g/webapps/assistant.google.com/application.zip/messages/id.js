opa.Messages['id'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "Kontak tidak ditemukan."
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "Oke"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "Kontak tidak ditemukan."
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "Oke"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Mengirim SMS."
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "Perlu waktu lebih lama dari biasanya untuk mengirim pesan Anda. Coba lagi dalam beberapa menit."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "Saya tidak bisa temukan aplikasi itu."
  },
  "BUTTON_ACCEPT": {
    "message": "Setuju"
  },
  "BUTTON_AGREE": {
    "message": "Setuju"
  },
  "BUTTON_ALLOW": {
    "message": "Izinkan"
  },
  "BUTTON_BACK": {
    "message": "Kembali"
  },
  "BUTTON_CANCEL": {
    "message": "Batal"
  },
  "BUTTON_CONTINUE": {
    "message": "Lanjutkan"
  },
  "BUTTON_DENY": {
    "message": "Tidak"
  },
  "BUTTON_DISMISS": {
    "message": "Tutup"
  },
  "BUTTON_EXIT": {
    "message": "Keluar"
  },
  "BUTTON_EXPLORE": {
    "message": "Jelajahi"
  },
  "BUTTON_EXPLORE_NEW": {
    "message": "Temukan yang baru"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.com"
  },
  "BUTTON_HOME": {
    "message": "Beranda"
  },
  "BUTTON_NEXT": {
    "message": "Berikutnya"
  },
  "BUTTON_OK": {
    "message": "Oke"
  },
  "BUTTON_OPEN": {
    "message": "Buka"
  },
  "BUTTON_PLAY": {
    "message": "Putar"
  },
  "BUTTON_REFRESH": {
    "message": "Muat ulang"
  },
  "BUTTON_SEARCH": {
    "message": "Telusuri"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Telusuri di Google"
  },
  "BUTTON_SEE_MORE": {
    "message": "Lihat lainnya"
  },
  "BUTTON_SELECT": {
    "message": "Pilih"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Tampilkan lainnya..."
  },
  "BUTTON_SKIP": {
    "message": "Lewati"
  },
  "BUTTON_TOP": {
    "message": "Ke atas"
  },
  "BUTTON_TRY": {
    "message": "Bantuan"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Scroll"
  },
  "BUTTON_WATCH_NOW": {
    "message": "Tonton sekarang"
  },
  "CAMERA_RETAKE_PHOTO": {
    "message": "Ambil ulang"
  },
  "CAMERA_SAVE_PHOTO": {
    "message": "Simpan"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "Untuk memahami siapa yang mau Anda telepon atau kirimi SMS, Asisten perlu izin untuk mengirim kontak ke Google kapan pun Anda berbicara dengannya."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "Untuk memahami siapa yang mau Anda telepon atau kirimi SMS, Asisten perlu izin untuk sementara menyimpan kontak dengan Google."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Izinkan Asisten Google mengakses kontak Anda"
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Untuk mendapatkan pengalaman yang lebih baik, izinkan Asisten Google mengakses kontak Anda?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Telepon"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Cari restoran terdekat"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Ceritakan lelucon"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Kirim pesan"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "Buka kamera"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Putar lagu Bollywood"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "Buka YouTube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "rumah"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "utama"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "seluler"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "lainnya"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "kantor"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Terjadi masalah. Harap coba lagi."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "Gagal memperbarui bluetooth, harap aktifkan secara manual di Setelan."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "Gagal memperbarui setelan senter. Harap aktifkan secara manual."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "Gagal memperbarui geolokasi, harap aktifkan secara manual di Setelan."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "Mengecek status login..."
  },
  "HELP_EPISODE": {
    "message": "Episode"
  },
  "HELP_PAGE_SUBTITLE": {
    "message": "Tonton video ini untuk mempelajari Asisten lebih lanjut"
  },
  "HELP_TITLE": {
    "message": "Anda, saya, dan"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Tekan $MICROPHONE$ untuk bicara",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "INTERPRETER_HINT_TEXT": {
    "message": "Tekan tombol $NAV$ untuk berbicara dalam bahasa $LANG$",
    "placeholders": {
      "LANG": {
        "content": "$1"
      },
      "NAV": {
        "content": "$2"
      }
    }
  },
  "INVALID_COOKIE": {
    "message": "Terjadi masalah. Harap coba lagi."
  },
  "LISTENING": {
    "message": "Mendengarkan\u2026"
  },
  "LOCATION_CONSENT_BODY": {
    "message": "Untuk hasil lokal, seperti restoran di area Anda, Asisten perlu izin untuk mengirim lokasi Anda ke Google kapan pun Anda berbicara dengannya."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Izinkan Asisten Google mengakses lokasi Anda"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Untuk mendapatkan pengalaman yang lebih dipersonalisasi, izinkan Asisten Google mengakses lokasi Anda?"
  },
  "MY_GOOGLE": {
    "message": "Akun Google"
  },
  "MY_GOOGLE_BODY": {
    "message": "Akun Saya saat ini tidak didukung di perangkat ini. Untuk lihat atau perbarui info akun Anda, harap buka https://myaccount.google.com dari perangkat yang kompatibel."
  },
  "NETWORK_ERROR": {
    "message": "Tidak dapat tersambung ke Internet. Harap periksa koneksi Anda dan coba lagi."
  },
  "NOTIFICATIONS_CONSENT_BODY": {
    "message": "Untuk mendapatkan pengalaman yang lebih baik, Asisten memerlukan izin untuk menampilkan notifikasi."
  },
  "NOTIFICATIONS_CONSENT_TITLE": {
    "message": "Izinkan Asisten Google menampilkan notifikasi"
  },
  "NOTIFICATIONS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Untuk mendapatkan pengalaman yang lebih baik, izinkan Asisten Google menampilkan notifikasi?"
  },
  "NOTIFICATIONS_OPTION_CHANGE_NOTIFICATIONS_PERMISSION": {
    "message": "Izin notifikasi"
  },
  "OPEN_APP_SUCCESS": {
    "message": "Membuka aplikasi."
  },
  "PLAYER_TITLE_NEWS": {
    "message": "BERITA"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Pemutar Media"
  },
  "PLAY_TUTORIAL": {
    "message": "Putar Tutorial"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "Maaf, saya tidak bisa lakukan itu di perangkat ini. Coba ucapkan yang lain."
  },
  "SERVER_ERROR": {
    "message": "Kami mengalami beberapa masalah teknis. Harap coba lagi dalam beberapa menit."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "Anda mau gunakan bahasa apa?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Izin kontak"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Ubah bahasa"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Izin lokasi"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Hapus data pengguna"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "Kebijakan Privasi"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Persyaratan Layanan"
  },
  "SETTINGS_PROMPT": {
    "message": "Tekan $KEY$ untuk Setelan",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Setelan"
  },
  "SETTINGS_VERSION": {
    "message": "Versi:"
  },
  "SIGNIN": {
    "message": "Login"
  },
  "SIGNOUT": {
    "message": "Logout"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth dinonaktifkan."
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth diaktifkan."
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "Anda berhasil menghapus histori."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Preferensi bahasa disimpan."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "Saya tidak mengerti. Coba ucapkan lagi."
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Izin disimpan."
  },
  "SNACKBAR_SIGNED_IN_HISTORY_CLEARED": {
    "message": "Data lokal Anda telah dihapus. Buka myactivity.google.com untuk menghapus histori Asisten Anda."
  },
  "SNACKBAR_SOMETHING_WENT_WRONG": {
    "message": "Terjadi masalah."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Tekan $MICROPHONE$ lalu coba ucapkan...",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\"Bagaimana cuaca hari ini?\""
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "\"Aktifkan Bluetooth\""
  },
  "SUGGESTION_CALL": {
    "message": "\"Telepon Susan\""
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\"Telepon Ayu\""
  },
  "SUGGESTION_PICTURES": {
    "message": "\"Tampilkan foto Beyonc\u00e9\""
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\"Tampilkan foto Hamish Daud\""
  },
  "SUGGESTION_SMS": {
    "message": "\"Kirim SMS ke Joni\""
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\"Kirim SMS ke Budi\""
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\"Putar Lady Gaga di YouTube\""
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\"Putar video Via Vallen di YouTube\""
  },
  "TERMS_AND_CONDITIONS_AOG_DISCLOSURE": {
    "message": "Saat Anda menggunakan Asisten untuk berkomunikasi dengan sebuah layanan, informasi interaksi Anda dengan Asisten akan dibagikan Google kepada layanan tersebut untuk menyelesaikan permintaan Anda."
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Tekan 2 untuk membaca Kebijakan Privasi."
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Tekan 1 untuk membaca Persyaratan Layanan."
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Harap baca Persyaratan Layanan dan Kebijakan Privasi Google"
  },
  "TUTORIAL_VIDEOS": {
    "message": "Video Tutorial"
  },
  "UDC_ERROR_MESSAGE": {
    "message": "Terjadi masalah."
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "Tekan $INDEX$ untuk pelajari lebih lanjut",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "Kami mengalami beberapa masalah teknis."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "Versi aplikasi sudah lama. Harap hubungi penyedia Anda untuk update ke versi terbaru."
  },
  "VIDEOS_NOTIFICATION_TEXT": {
    "message": "Tonton video ini untuk mempelajari Asisten lebih lanjut."
  },
  "VIDEOS_TOOLTIP_TEXT": {
    "message": "Informasi tentang Asisten"
  },
  "VIDEO_NOT_FINISHED": {
    "message": "Video belum selesai"
  }
};

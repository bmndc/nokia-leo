opa.Messages['pt-BR'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "Nenhum contato encontrado."
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "Nenhum contato encontrado."
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Enviando mensagem."
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "O envio est\u00e1 demorando mais que o normal. Tente novamente em alguns minutos."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "N\u00e3o consegui encontrar esse app."
  },
  "BUTTON_ACCEPT": {
    "message": "Aceitar"
  },
  "BUTTON_AGREE": {
    "message": "Concordo"
  },
  "BUTTON_ALLOW": {
    "message": "Permitir"
  },
  "BUTTON_BACK": {
    "message": "Voltar"
  },
  "BUTTON_CANCEL": {
    "message": "Cancelar"
  },
  "BUTTON_CONTINUE": {
    "message": "Continuar"
  },
  "BUTTON_DENY": {
    "message": "N\u00e3o"
  },
  "BUTTON_DISMISS": {
    "message": "Ignorar"
  },
  "BUTTON_EXIT": {
    "message": "Sair"
  },
  "BUTTON_EXPLORE": {
    "message": "Explorar"
  },
  "BUTTON_EXPLORE_NEW": {
    "message": "Descubra as novidades"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.com.br"
  },
  "BUTTON_HOME": {
    "message": "In\u00edcio"
  },
  "BUTTON_NEXT": {
    "message": "Pr\u00f3xima"
  },
  "BUTTON_OK": {
    "message": "OK"
  },
  "BUTTON_OPEN": {
    "message": "Abrir"
  },
  "BUTTON_PLAY": {
    "message": "Assistir"
  },
  "BUTTON_REFRESH": {
    "message": "Atualizar"
  },
  "BUTTON_SEARCH": {
    "message": "Pesquisar"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Pesquisar no Google"
  },
  "BUTTON_SEE_MORE": {
    "message": "Ver mais"
  },
  "BUTTON_SELECT": {
    "message": "Selecionar"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Mostrar mais..."
  },
  "BUTTON_SKIP": {
    "message": "Pular"
  },
  "BUTTON_TOP": {
    "message": "In\u00edcio"
  },
  "BUTTON_TRY": {
    "message": "Ajuda"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Rolagem"
  },
  "BUTTON_WATCH_NOW": {
    "message": "Assistir agora"
  },
  "CAMERA_RETAKE_PHOTO": {
    "message": "Tirar outra foto"
  },
  "CAMERA_SAVE_PHOTO": {
    "message": "Salvar"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "Para entender para quem voc\u00ea quer ligar ou enviar uma mensagem de texto, seu Assistente precisa de permiss\u00e3o para enviar seus contatos para o Google sempre que voc\u00ea falar com ele."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "Para entender para quem voc\u00ea quer ligar ou enviar uma mensagem de texto, o Assistente precisa de permiss\u00e3o para armazenar temporariamente seus contatos com o Google."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Permita que o Google Assistente acesse seus contatos."
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Para uma experi\u00eancia ainda melhor, voc\u00ea permite que o Google Assistente acesse seus contatos?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Fazer uma chamada telef\u00f4nica"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Encontre restaurantes perto de mim"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Conte uma piada"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Envie uma mensagem"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "Abra a c\u00e2mera"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Toque m\u00fasicas de Bollywood"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "Abra o YouTube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "p\u00e1gina inicial"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "principal"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "dispositivo m\u00f3vel"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "outro"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "trabalho"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Algo deu errado. Tente novamente."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "Falha ao atualizar o Bluetooth. Favor ativar manualmente em Configura\u00e7\u00f5es."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "N\u00e3o foi poss\u00edvel atualizar a lanterna, ligue-a manualmente."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "Falha ao atualizar a geolocaliza\u00e7\u00e3o. Favor ativar manualmente em Configura\u00e7\u00f5es."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "Verificando para fazer login..."
  },
  "HELP_EPISODE": {
    "message": "Epis\u00f3dio"
  },
  "HELP_PAGE_SUBTITLE": {
    "message": "Confira esses v\u00eddeos para saber mais sobre o Assistente"
  },
  "HELP_TITLE": {
    "message": "Eu, voc\u00ea e"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Pressione $MICROPHONE$ para falar",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "INTERPRETER_HINT_TEXT": {
    "message": "Pressione a tecla $NAV$ para falar em $LANG$",
    "placeholders": {
      "LANG": {
        "content": "$1"
      },
      "NAV": {
        "content": "$2"
      }
    }
  },
  "INVALID_COOKIE": {
    "message": "Algo deu errado. Tente novamente."
  },
  "LISTENING": {
    "message": "Ouvindo..."
  },
  "LOCATION_CONSENT_BODY": {
    "message": "Para ver resultados em sua \u00e1rea, como restaurantes, seu Assistente precisa de permiss\u00e3o para enviar sua localiza\u00e7\u00e3o para o Google sempre que voc\u00ea falar com ele."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Permitir que o Google Assistente acesse seu local"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Para uma experi\u00eancia mais personalizada, voc\u00ea permite que o Google Assistente acesse seu local?"
  },
  "MY_GOOGLE": {
    "message": "Conta do Google"
  },
  "MY_GOOGLE_BODY": {
    "message": "A op\u00e7\u00e3o \"Minha conta\" n\u00e3o est\u00e1 dispon\u00edvel neste dispositivo no momento. Para ver ou atualizar as informa\u00e7\u00f5es da sua conta, acesse https://myaccount.google.com/ com um dispositivo compat\u00edvel."
  },
  "NETWORK_ERROR": {
    "message": "N\u00e3o \u00e9 poss\u00edvel se conectar \u00e0 internet. Verifique sua conex\u00e3o e tente novamente."
  },
  "NOTIFICATIONS_CONSENT_BODY": {
    "message": "Para uma experi\u00eancia ainda melhor, o Assistente precisa de permiss\u00e3o para mostrar notifica\u00e7\u00f5es."
  },
  "NOTIFICATIONS_CONSENT_TITLE": {
    "message": "Permitir que o Google Assistente mostre notifica\u00e7\u00f5es"
  },
  "NOTIFICATIONS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "Para uma experi\u00eancia ainda melhor, voc\u00ea permite que o Google Assistente mostre notifica\u00e7\u00f5es?"
  },
  "NOTIFICATIONS_OPTION_CHANGE_NOTIFICATIONS_PERMISSION": {
    "message": "Permiss\u00e3o de notifica\u00e7\u00f5es"
  },
  "OPEN_APP_SUCCESS": {
    "message": "Abrindo aplicativo."
  },
  "PLAYER_TITLE_NEWS": {
    "message": "NOT\u00cdCIAS"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Player de m\u00eddia"
  },
  "PLAY_TUTORIAL": {
    "message": "Abrir tutorial"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "Desculpe, n\u00e3o posso fazer isso neste dispositivo. Tente pedir outra coisa."
  },
  "SERVER_ERROR": {
    "message": "Estamos com alguns problemas t\u00e9cnicos. Tente novamente daqui alguns minutos."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "Em que idioma voc\u00ea prefere falar?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Permiss\u00e3o de contatos"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Alterar idioma"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Permiss\u00e3o de acesso ao local"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Limpar dados do usu\u00e1rio"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "Pol\u00edtica de Privacidade"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Termos de Servi\u00e7o"
  },
  "SETTINGS_PROMPT": {
    "message": "Pressione $KEY$ para acessar as configura\u00e7\u00f5es",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Configura\u00e7\u00f5es"
  },
  "SETTINGS_VERSION": {
    "message": "Vers\u00e3o:"
  },
  "SIGNIN": {
    "message": "Fazer login"
  },
  "SIGNOUT": {
    "message": "Sair"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth desativado."
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth ativado."
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "Voc\u00ea limpou seu hist\u00f3rico com sucesso."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Prefer\u00eancia de idioma salva."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "N\u00e3o entendi. Fale novamente."
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Permiss\u00e3o salva."
  },
  "SNACKBAR_SIGNED_IN_HISTORY_CLEARED": {
    "message": "Seus dados locais foram exclu\u00eddos. Acesse myactivity.google.com para limpar seu hist\u00f3rico com o Assistente."
  },
  "SNACKBAR_SOMETHING_WENT_WRONG": {
    "message": "Algo deu errado."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Pressione $MICROPHONE$ e fale...",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\"Qual a previs\u00e3o do tempo?\""
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "\"Ativar Bluetooth\""
  },
  "SUGGESTION_CALL": {
    "message": "\"Ligue para Sophia\""
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\"Ligar para M\u00f4nica\""
  },
  "SUGGESTION_PICTURES": {
    "message": "\"Mostre fotos da Beyonc\u00e9\""
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\"Mostre fotos de Neymar\""
  },
  "SUGGESTION_SMS": {
    "message": "\"Envie uma mensagem para o Jo\u00e3o\""
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\"Enviar mensagem para Andr\u00e9\""
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\"Toque Lady Gaga no YouTube\""
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\"Toque Despacito no YouTube\""
  },
  "TERMS_AND_CONDITIONS_AOG_DISCLOSURE": {
    "message": "Quando voc\u00ea usa o Assistente para falar com um servi\u00e7o, o Google compartilha informa\u00e7\u00f5es com esse servi\u00e7o sobre suas intera\u00e7\u00f5es com o Assistente, para poder atender \u00e0 sua solicita\u00e7\u00e3o."
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Pressione 2 para ler a Pol\u00edtica de Privacidade."
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Pressione 1 para ler os Termos de Servi\u00e7o."
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Leia os Termos de Servi\u00e7o e a Pol\u00edtica de Privacidade do Google"
  },
  "TUTORIAL_VIDEOS": {
    "message": "V\u00eddeos de tutoriais"
  },
  "UDC_ERROR_MESSAGE": {
    "message": "Algo deu errado."
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "Pressione $INDEX$ para saber mais",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "Estamos enfrentando problemas t\u00e9cnicos."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "O aplicativo est\u00e1 desatualizado. Entre em contato com o fabricante para atualizar para a vers\u00e3o mais recente."
  },
  "VIDEOS_NOTIFICATION_TEXT": {
    "message": "Confira esses v\u00eddeos para saber mais sobre o Assistente."
  },
  "VIDEOS_TOOLTIP_TEXT": {
    "message": "Saiba mais sobre o Assistente"
  },
  "VIDEO_NOT_FINISHED": {
    "message": "O v\u00eddeo n\u00e3o acabou"
  }
};

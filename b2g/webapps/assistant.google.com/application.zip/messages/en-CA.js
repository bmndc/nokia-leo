opa.Messages['en-CA'] = {
  "ACTION_TEXT_RESPONSE_NO_CONTACTS": {
    "message": "No contacts found."
  },
  "ACTION_TEXT_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_NO_CONTACTS": {
    "message": "No contacts found."
  },
  "ACTION_VOCAL_RESPONSE_OK": {
    "message": "OK"
  },
  "ACTION_VOCAL_RESPONSE_SENDING_MESSAGE": {
    "message": "Sending message."
  },
  "ACTION_VOCAL_RESPONSE_SMS_TIMEOUT": {
    "message": "It\u2019s taking longer than usual to send your message. Try again in a few minutes."
  },
  "APP_NOT_FOUND_ERROR": {
    "message": "I couldn't find that app."
  },
  "BUTTON_ACCEPT": {
    "message": "Accept"
  },
  "BUTTON_AGREE": {
    "message": "Agree"
  },
  "BUTTON_ALLOW": {
    "message": "Allow"
  },
  "BUTTON_BACK": {
    "message": "Back"
  },
  "BUTTON_CANCEL": {
    "message": "Cancel"
  },
  "BUTTON_CONTINUE": {
    "message": "Continue"
  },
  "BUTTON_DENY": {
    "message": "No thanks"
  },
  "BUTTON_DISMISS": {
    "message": "Dismiss"
  },
  "BUTTON_EXIT": {
    "message": "Exit"
  },
  "BUTTON_EXPLORE": {
    "message": "Explore"
  },
  "BUTTON_EXPLORE_NEW": {
    "message": "Explore what's new"
  },
  "BUTTON_GOOGLE_DOT_COM": {
    "message": "Google.co.uk"
  },
  "BUTTON_HOME": {
    "message": "Home"
  },
  "BUTTON_NEXT": {
    "message": "Next"
  },
  "BUTTON_OK": {
    "message": "OK"
  },
  "BUTTON_OPEN": {
    "message": "Open"
  },
  "BUTTON_PLAY": {
    "message": "Play"
  },
  "BUTTON_REFRESH": {
    "message": "Refresh"
  },
  "BUTTON_SEARCH": {
    "message": "Search"
  },
  "BUTTON_SEARCH_ON_GOOGLE": {
    "message": "Search on Google"
  },
  "BUTTON_SEE_MORE": {
    "message": "See more"
  },
  "BUTTON_SELECT": {
    "message": "Select"
  },
  "BUTTON_SHOW_MORE": {
    "message": "Show more..."
  },
  "BUTTON_SKIP": {
    "message": "Skip"
  },
  "BUTTON_TOP": {
    "message": "Top"
  },
  "BUTTON_TRY": {
    "message": "Help"
  },
  "BUTTON_UDC_SCROLL": {
    "message": "Scroll"
  },
  "BUTTON_WATCH_NOW": {
    "message": "Watch now"
  },
  "CAMERA_RETAKE_PHOTO": {
    "message": "Retake"
  },
  "CAMERA_SAVE_PHOTO": {
    "message": "Save"
  },
  "CONTACTS_CONSENT_BODY": {
    "message": "To understand who you want to call or text, your Assistant needs permission to send your contacts to Google whenever you talk to it."
  },
  "CONTACTS_CONSENT_BODY_V02": {
    "message": "To understand who you want to call or text, your Assistant needs permission to temporarily store your contacts with Google."
  },
  "CONTACTS_CONSENT_TITLE": {
    "message": "Allow the Google Assistant to access your contacts"
  },
  "CONTACTS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "For an even better experience, would you allow the Google Assistant to access your contacts?"
  },
  "CONVERSATION_STARTER_CALL": {
    "message": "Make a phone call"
  },
  "CONVERSATION_STARTER_FIND_RESTAURANTS": {
    "message": "Find restaurants near me"
  },
  "CONVERSATION_STARTER_JOKE": {
    "message": "Tell me a joke"
  },
  "CONVERSATION_STARTER_MESSAGE": {
    "message": "Send a message"
  },
  "CONVERSATION_STARTER_OPEN_APP": {
    "message": "Open camera"
  },
  "CONVERSATION_STARTER_PLAY_SONGS": {
    "message": "Play Bollywood songs"
  },
  "CONVERSATION_STARTER_YOUTUBE": {
    "message": "Open Youtube"
  },
  "ENDPOINT_TYPE_HOME": {
    "message": "home"
  },
  "ENDPOINT_TYPE_MAIN": {
    "message": "main"
  },
  "ENDPOINT_TYPE_MOBILE": {
    "message": "mobile"
  },
  "ENDPOINT_TYPE_OTHER": {
    "message": "other"
  },
  "ENDPOINT_TYPE_WORK": {
    "message": "work"
  },
  "EXPLORE_FAILURE_ERROR": {
    "message": "Something went wrong. Try again."
  },
  "FAIL_UPDATE_BLUETOOTH": {
    "message": "Failed to update Bluetooth. Please manually turn it on in Settings."
  },
  "FAIL_UPDATE_FLASHLIGHT": {
    "message": "Failed to update torch. Please manually turn it on."
  },
  "FAIL_UPDATE_GEOLOCATION": {
    "message": "Failed to update geolocation. Please manually turn it on in Settings."
  },
  "FETCHING_ACCOUNT_STATUS": {
    "message": "Checking for sign-in\u2026"
  },
  "HELP_EPISODE": {
    "message": "Episode"
  },
  "HELP_PAGE_SUBTITLE": {
    "message": "Check out these videos to know about your Assistant"
  },
  "HELP_TITLE": {
    "message": "You, me and"
  },
  "INITIAL_PROMPT_MIC": {
    "message": "Press $MICROPHONE$ to speak",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "INTERPRETER_HINT_TEXT": {
    "message": "Press $NAV$ key to speak in $LANG$",
    "placeholders": {
      "LANG": {
        "content": "$1"
      },
      "NAV": {
        "content": "$2"
      }
    }
  },
  "INVALID_COOKIE": {
    "message": "Something went wrong. Please try again."
  },
  "LISTENING": {
    "message": "Listening..."
  },
  "LOCATION_CONSENT_BODY": {
    "message": "For local results, such as restaurants in your area, your Assistant needs permission to send your location to Google whenever you talk to it."
  },
  "LOCATION_CONSENT_TITLE": {
    "message": "Allow the Google Assistant to access your location"
  },
  "LOCATION_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "For a more personalised experience, would you allow the Google Assistant to access your location?"
  },
  "MY_GOOGLE": {
    "message": "Google Account"
  },
  "MY_GOOGLE_BODY": {
    "message": "My account is currently not supported on this device. In order to view or update your account information, please visit https://myaccount.google.com/ from a compatible device."
  },
  "NETWORK_ERROR": {
    "message": "Cannot connect to the Internet. Please check your connection and try again."
  },
  "NOTIFICATIONS_CONSENT_BODY": {
    "message": "For a better experience, your Assistant needs permission to show notifications."
  },
  "NOTIFICATIONS_CONSENT_TITLE": {
    "message": "Allow the Google Assistant to show notifications"
  },
  "NOTIFICATIONS_CONSENT_TITLE_FOR_REACCEPT": {
    "message": "For a better experience, would you allow Google Assistant to show notifications?"
  },
  "NOTIFICATIONS_OPTION_CHANGE_NOTIFICATIONS_PERMISSION": {
    "message": "Notifications permission"
  },
  "OPEN_APP_SUCCESS": {
    "message": "Opening app."
  },
  "PLAYER_TITLE_NEWS": {
    "message": "NEWS"
  },
  "PLAYER_TITLE_PLACEHOLDER": {
    "message": "Media Player"
  },
  "PLAY_TUTORIAL": {
    "message": "Play tutorial"
  },
  "PUNT_FEATURE_NOT_SUPPORTED": {
    "message": "Sorry, I can't do that on this device. Try asking something else."
  },
  "SERVER_ERROR": {
    "message": "We are experiencing some technical issues. Please try again in a couple of minutes."
  },
  "SETTINGS_LANGUAGE_TITLE": {
    "message": "What language do you prefer to speak in?"
  },
  "SETTINGS_OPTION_CHANGE_CONTACTS_PERMISSION": {
    "message": "Contacts permission"
  },
  "SETTINGS_OPTION_CHANGE_LANGUAGE": {
    "message": "Change language"
  },
  "SETTINGS_OPTION_CHANGE_LOCATION_PERMISSION": {
    "message": "Location permission"
  },
  "SETTINGS_OPTION_CLEAR_DATA": {
    "message": "Clear user data"
  },
  "SETTINGS_OPTION_PRIVACY_POLICY": {
    "message": "Privacy Policy"
  },
  "SETTINGS_OPTION_TERMS_OF_SERVICE": {
    "message": "Terms of Service"
  },
  "SETTINGS_PROMPT": {
    "message": "Press $KEY$ for Settings",
    "placeholders": {
      "KEY": {
        "content": "$1"
      }
    }
  },
  "SETTINGS_TITLE": {
    "message": "Settings"
  },
  "SETTINGS_VERSION": {
    "message": "Version:"
  },
  "SIGNIN": {
    "message": "Sign in"
  },
  "SIGNOUT": {
    "message": "Sign out"
  },
  "SNACKBAR_BLUETOOTH_DISABLED": {
    "message": "Bluetooth disabled."
  },
  "SNACKBAR_BLUETOOTH_ENABLED": {
    "message": "Bluetooth enabled."
  },
  "SNACKBAR_HISTORY_CLEARED": {
    "message": "You have successfully cleared your history."
  },
  "SNACKBAR_LANGUAGE_PREFERENCE_SAVED": {
    "message": "Language preference saved."
  },
  "SNACKBAR_NOINPUT_HELP": {
    "message": "Didn't catch that. Try speaking again."
  },
  "SNACKBAR_PERMISSION_SAVED": {
    "message": "Permission saved."
  },
  "SNACKBAR_SIGNED_IN_HISTORY_CLEARED": {
    "message": "Your local data has been cleared. Visit myactivity.google.com to clear your Assistant history."
  },
  "SNACKBAR_SOMETHING_WENT_WRONG": {
    "message": "Something went wrong."
  },
  "SUGGESTIONS_PROMPT_MIC": {
    "message": "Press $MICROPHONE$ and try saying\u2026",
    "placeholders": {
      "MICROPHONE": {
        "content": "$1"
      }
    }
  },
  "SUGGESTION_ANSWER": {
    "message": "\"What's the weather like?\""
  },
  "SUGGESTION_BLUETOOTH": {
    "message": "'Turn on Bluetooth'"
  },
  "SUGGESTION_CALL": {
    "message": "\"Call Sophia\""
  },
  "SUGGESTION_CALL_EN_IN": {
    "message": "\"Call Anjali\""
  },
  "SUGGESTION_PICTURES": {
    "message": "\"Show me pictures of Beyonc\u00e9\""
  },
  "SUGGESTION_PICTURES_EN_IN": {
    "message": "\"Show me pictures of Shah Rukh Khan\""
  },
  "SUGGESTION_SMS": {
    "message": "\"Message John\""
  },
  "SUGGESTION_SMS_EN_IN": {
    "message": "\"Message Akshay\""
  },
  "SUGGESTION_YOUTUBE": {
    "message": "\"Play Lady Gaga on YouTube\""
  },
  "SUGGESTION_YOUTUBE_EN_IN": {
    "message": "\"Play Kala Chashma on YouTube\""
  },
  "TERMS_AND_CONDITIONS_AOG_DISCLOSURE": {
    "message": "When you use your Assistant to talk to a service, Google shares information about your interactions with the Assistant with that service so that it can fulfil your request."
  },
  "TERMS_AND_CONDITIONS_BODY_PRIVACY": {
    "message": "Press 2 to read the Privacy Policy."
  },
  "TERMS_AND_CONDITIONS_BODY_TERMS": {
    "message": "Press 1 to read the Terms of Service."
  },
  "TERMS_AND_CONDITIONS_TITLE": {
    "message": "Please read Google Terms of Service and Privacy Policy"
  },
  "TUTORIAL_VIDEOS": {
    "message": "Tutorial videos"
  },
  "UDC_ERROR_MESSAGE": {
    "message": "Something went wrong."
  },
  "UDC_SETTINGS_LEARN_MORE_PROMPT": {
    "message": "Press $INDEX$ to learn more",
    "placeholders": {
      "INDEX": {
        "content": "$1"
      }
    }
  },
  "UNKNOWN_CONNECTION_ERROR": {
    "message": "We are experiencing some technical issues."
  },
  "VERSION_EXPIRED_ERROR": {
    "message": "Application is out of date. Please contact your provider to update to the latest version."
  },
  "VIDEOS_NOTIFICATION_TEXT": {
    "message": "Check out these videos to know about your Assistant."
  },
  "VIDEOS_TOOLTIP_TEXT": {
    "message": "Know about Assistant"
  },
  "VIDEO_NOT_FINISHED": {
    "message": "Video has not finished"
  }
};

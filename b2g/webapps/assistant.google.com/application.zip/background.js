// Setting the background conditionally according to the window location.
// The location's search string is defined in the manifest.
const SPEECH_TO_TEXT_HREF_PARAMS = '?activity=voice-input';

if (window.location.search == SPEECH_TO_TEXT_HREF_PARAMS) {
  document.body.classList.add('transparent_background');
}

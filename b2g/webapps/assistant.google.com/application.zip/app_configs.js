


PlatformConfigs.SUPPORTED_TCLOCALES = ['de', 'en-AU', 'en-CA', 'en-GB', 'en-IN', 'en-SG', 'en-US', 'es', 'es-MX', 'es-US', 'fr', 'fr-CA', 'hi', 'id', 'it', 'pt-BR', 'th', 'bn', 'mr', 'ta', 'te', 'gu', 'kn'];


PlatformConfigs.CONFIG_VERSION = PlatformConfigs.APP_VERSION;


PlatformConfigs.HASHED_CONFIG_VERSION = '';


PlatformConfigs.CONFIG_SERVICE_API_KEY =
    'AIzaSyBNfZbyCqL4tkgFhso-ncnIpz0S7NsO9vk';





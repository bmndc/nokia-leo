## v2.0.2 ##

* use international news when fetch content is empty.


## v2.0.3 ##

*   Integration with new opera news openAPI

## v2.0.5 ##

*   Correct language code for Norweigian News app (no-NO->nb-NO)

## v2.0.7 ##

*   Update Czech and Italiano license terms

## v2.1.0 ##
*   Add extra country which opera new api did not support

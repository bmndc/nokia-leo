/* global NavigationHelper */
'use strict';

(function(exports) {
  let NavigationMap = {
    currentActivatedLength: 0,
    NAV_TOP: 50,
    NAV_BOTTOM: 40,

    init: function() {
      window.addEventListener('panelready', this.panelReadyHandler.bind(this));
    },

    setFocus: function (element) {
      if (!element) {
        return;
      }
      let focused = document.querySelectorAll('.focus');
      if (focused.length) {
        focused[0].classList.remove('focus');
      }
      element.setAttribute('tabindex', 1);
      element.classList.add('focus');
      element.focus();
    },

    registerPanelNavigation: function (navInfo) {
      let noSetfocus = navInfo.noSetfocus || navInfo.noFocusWindow;
      let bootFocusElement = NavigationHelper.reset(
          navInfo.navigator,
          navInfo.controls,
          navInfo.defaultFocusIndex,
          navInfo.curViewId,
          noSetfocus
      );
      if (noSetfocus && navInfo.noFocusWindow) {
        this.setFocus(bootFocusElement);
      }
      return bootFocusElement;
    },

    scrollToElement: function (element, event) {
      if(!this.elementIsVisible(element, this.NAV_TOP, this.NAV_BOTTOM)) {
        if (event.key === 'ArrowUp') {
          element.scrollIntoView(true);
        } else if (event.key === 'ArrowDown') {
          element.scrollIntoView(false);
        }
      }
    },

    elementIsVisible: function(element, top, bottom) {
      let visible = true;
      if (element.offsetWidth === 0 || element.offsetHeight === 0) {
        return visible;
      }
      let rects = element.getClientRects();
      for (let rect of rects) {
        if (rect.bottom + bottom > window.innerHeight || rect.top < top) {
          visible = false;
          break;
        }
      }
      return visible;
    },

    panelReadyHandler: function (event) {
      const navInfo = event.detail;
      const panel = navInfo.panel;
      this.focusedElement = this.registerPanelNavigation(navInfo);
      if (this.focusedElement) {
        if (panel.CLASS_NAME !== 'BasePanel') {
          panel.ready = true;
        }
      }
    }
  };

  exports.NavigationMap = NavigationMap;
}(window));

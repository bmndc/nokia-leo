## v1.4.40

* Add timeout for ads loading

### v1.4.50
* Add ads-sdk v3

### v1.4.60
* Add related logic when scanning a text code

### v1.4.70
* bug fixed

### v1.4.80
* bug fixed

### v1.5.00
* Add scripts to compile next version on master branch.

### v1.5.01
* Bug fixed

### v1.5.02
* Bug fixed

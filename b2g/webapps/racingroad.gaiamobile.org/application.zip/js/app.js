var _LANG = tnb_lang;
var cost = '0.2 EUR';
var flag = true;
var payment = 'pending';
var trialsLeft = true;
var noOfTrialsLeft = null;
var isSimPresent = false;
var isValidCode = false;
var currentNode = null;
var canShowVat = false;
var canShowSMS = false;
var noOfSMS = 0;
var shortcode = null;
var gameUnlocked = null;
var startGameEvent = new CustomEvent('startOEMGameRA', () => { console.log('start Game Event Created') });
var retunToTNBEvent = new CustomEvent('returnToTNBRA', () => { console.log('Return to TNB Event Created') });
var isLoading = false;
var tier = null;
var disclaimer = null;
var isTrialOver = false;

// Debug Params
var isDebugMode = false;
var debugTrials = 2;
var isManualUnlockMode = false;

// Download Variables
var showDownlaod = false;
var contentLength = 0;
var progressPercentage = 0;
var isUpdateModule = false;

var isFreeTrialMode = false;

window.onload = (event) => {
    document.getElementById('loadingwheel').style.display = "block";

    _LANG = tnb_lang;
    // console.log('The page has fully loaded');
    document.addEventListener('keydown', logKey);
    isLoading = true;

    noOfTrialsLeft = window.TNBManager.checkFreeTrials();
    if (noOfTrialsLeft > 0) {
        trialsLeft = true;
    } else {
        trialsLeft = false;
    }

    if (!isDebugMode) {

        // Init TNB Manager
        window.TNBManager.init();

        // Setting Update Callback
        setUpdateCallBack();

        // On TNB Load callback
        startTNBScreens = (e) => {
            isLoading = false;
            // console.log("Start TNB Screens :" + e);
            getTNBBillingData();
            loadButtonData();
            document.getElementById('splash').style.display = "none";
            document.getElementById('loadingwheel').style.display = "none";


            if (isManualUnlockMode) {
                openManualMode();
            } else {
                welcomeScreen();
            }
        };
    } else {
        isLoading = false;
        getDebugBillingData();
        loadButtonData();
        document.getElementById('splash').style.display = "none";
        document.getElementById('loadingwheel').style.display = "none";

        if (isManualUnlockMode) {
            openManualMode();
        } else if (showDownlaod) {
            //console.log("show downlaod");
            showStatusUpdate();
        } else {
            welcomeScreen();
        }
    }

    document.addEventListener('returnToTNBRA', function(e) {

        document.getElementById('game').style.display = 'none';

        document.getElementById('container-fluid').style.display = 'block';

        if (isUpdateModule) {
            // console.log("Is Update Mode");

            document.getElementById('no-internet').style.display = "none";

            document.getElementById('download-update').style.display = "none";


            document.getElementById('update-like-game').style.display = "block";

            var c = document.getElementById('update-like-game').children;
            c[1].focus();

            document.getElementById('footer1').style.display = 'block';
            document.getElementById('footer2').style.display = 'none';
            document.getElementById('footer3').style.display = 'none';
            document.getElementById('footer4').style.display = 'none';
            return;
        }

        noOfTrialsLeft = window.TNBManager.checkFreeTrials();
        if (noOfTrialsLeft > 0) {
            trialsLeft = true;
        } else {
            trialsLeft = false;
        }

        if (!isDebugMode) {
            getTNBBillingData();
        } else {
            getDebugBillingData();
        }

        loadButtonData();
        // Show the welcome screen
        if (isManualUnlockMode) {
            openManualMode();
        } else {
            endDemoScreen();
        }

        setTimeout(() => {
            document.addEventListener('keydown', logKey);
        }, 100);
    });
};


function setUpdateCallBack() {
    var _this = this;

    noOfTrialsLeft = window.TNBManager.checkFreeTrials();
    if (noOfTrialsLeft > 0) {
        trialsLeft = true;
    } else {
        trialsLeft = false;
    }

    Array.prototype.forEach.call(document.querySelectorAll("#playNowTrails"), btn => {
        btn.value = replaceString(TNBTEXTS.TXT_BTN_PLAY_NOW_TRIALS_REMAINING[_LANG], noOfTrialsLeft);
    });

    document.getElementById("downlaod-update").innerHTML = (TNBTEXTS.TXT_DOWNLOADING_UPDATE[_LANG]).toUpperCase();

    document.getElementById("internet_msg").innerHTML = (TNBTEXTS.TXT_NETWORK_REQUIRED[_LANG]).toUpperCase();

    document.getElementById("no-internet-msg").innerHTML = "ERROR: " + (TNBTEXTS.TXT_NETWORK_REQUIRED[_LANG]).toUpperCase() + "</br></br>";


    Array.prototype.forEach.call(document.querySelectorAll("#cancel"), btn => {
        btn.value = (TNBTEXTS.TXT_BTN_CANCEL[_LANG]).toUpperCase();
    });

    Array.prototype.forEach.call(document.querySelectorAll("#back"), btn => {
        btn.value = (TNBTEXTS.TXT_BACK[_LANG]).toUpperCase();
    });

    Array.prototype.forEach.call(document.querySelectorAll("#like-game"), txt => {
        txt.innerHTML = TNBTEXTS.TXT_ON_SESSION_EXPIRED[_LANG] + "</br></br>";
    });

    updateModuleCallBack = (status) => {
        switch (status) {
            case 'started':
                //console.log("Update Started");
                document.getElementById('loadingwheel').style.display = "none";
                showStatusUpdate();
                break;

            case 'successful':

                hideStatusUpdate();
                //console.log("Update Successful");
                break;
            case 'failure':

                cancelUpdate();
                // console.log("Update Failure");
                break;
        }
    };
}

function getTNBBillingData() {
    // Set the values
    gameUnlocked = TNBManager.billingData.unlocked;

    if (gameUnlocked) {
        isFreeTrialMode = false;
        document.getElementById('splash').style.display = "none";
        document.getElementById('loadingwheel').style.display = "none";
        // console.log("Play Game In Purchase Mode");
        document.removeEventListener('keydown', logKey);
        document.getElementById('container-fluid').style.display = 'none';
        document.dispatchEvent(startGameEvent);
        document.getElementById('loadingwheel').style.display = "block";
        return;
    }

    isManualUnlockMode = window.TNBManager.isManualUnlockMode;
    tier = window.TNBManager.billingData.paymentOptions.payment_tier;
    cost = window.TNBManager.billingData.priceOptions.formatted_price;
    isSimPresent = (window.TNBManager.billingData.validSimSlot != null) ? true : false;
    shortcode = window.TNBManager.billingData.priceOptions.shortcode;
    canShowVat = window.TNBManager.billingData.priceOptions.vat;
    canShowSMS = window.TNBManager.billingData.priceOptions["Display number of SMS"];

    if (isSimPresent) {
        var r = /\d+/;
        disclaimer = window.TNBManager.billingData.priceOptions.disclaimer;
        noOfSMS = 1;
    }

    noOfTrialsLeft = window.TNBManager.checkFreeTrials();
    if (noOfTrialsLeft > 0) {
        trialsLeft = true;
    } else {
        trialsLeft = false;
    }

    // console.log("Data fetched from TNB Manager!");
}

// For Debug purpose
function getDebugBillingData() {
    // To Test the game in unlocked mode
    gameUnlocked = false;

    // If the game is unlocked we hide the container-fluid div and start the game 
    if (gameUnlocked) {
        isFreeTrialMode = false;
        document.getElementById('splash').style.display = "none";
        // console.log("Play Game In Purchase Mode");
        document.removeEventListener('keydown', logKey);
        document.getElementById('container-fluid').style.display = 'none';
        document.dispatchEvent(startGameEvent);
        document.getElementById('loadingwheel').style.display = "block";
        return;
    }

    tier = 9;
    // To check if the sim is inserted
    isSimPresent = true;
    noOfTrialsLeft = 2;
    // To check the no of trials flow
    noOfTrialsLeft = debugTrials;
    if (noOfTrialsLeft > 0) {
        trialsLeft = true;
    } else {
        trialsLeft = false;
    }

    // Short code to be display in the Terms and condition screen
    shortcode = "+123456789"

    canShowVat = true;
    canShowSMS = true;

}

function welcomeScreen() {
    hideCurrentDiv();
    document.getElementById('welcome').style.display = 'block';
    // Show the select and back and exit button
    document.getElementById('footer1').style.display = 'block';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';

    var c = document.getElementById('welcome').children;
    if (trialsLeft) {
        c[0].style.display = 'none';
        c[1].style.display = 'none';
        c[2].style.display = 'block';
        c[3].style.display = 'block';
    } else {
        c[0].style.display = 'block';
        c[1].style.display = 'none';

        c[3].style.display = 'none';
    }
    c[2].style.display = 'block';

    document.getElementById('buttonBuy').focus();
}

function endDemoScreen() {
    hideCurrentDiv();
    document.getElementById('welcome-end-demo').style.display = 'block';
    // Show the select and back and exit button
    document.getElementById('footer1').style.display = 'block';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';

    var c = document.getElementById('welcome-end-demo').children;
    c[1].focus();

    // document.getElementById('buttonBuy').focus();
}

function loadButtonData() {
    Array.prototype.forEach.call(document.querySelectorAll("#buttonBuy"), btn => {
        if (isSimPresent) {
            btn.value = (TNBTEXTS.TXT_BTN_BUY_THE_GAME[_LANG]).toUpperCase() + " " + ((tier == 9) ? TNBTEXTS.OD_TEXT_RENTAL[_LANG] : " ") + "\n " + cost + " " + (canShowVat ? TNBTEXTS.TXT_BTN_BUY_THE_GAME_VAT[_LANG] : " ") + (canShowSMS ? "\n " + replaceString(TNBTEXTS.TXT_BTN_BUY_THE_GAME_SMS_COUNT[_LANG], noOfSMS) : ''); // TNBTEXTS.TXT_BTN_BUY_THE_GAME_SMS_COUNT[_LANG]
        } else {
            btn.value = (TNBTEXTS.TXT_BTN_BUY_THE_GAME[_LANG]).toUpperCase();
        }
    });

    Array.prototype.forEach.call(document.querySelectorAll("#playNowTrails"), btn => {
        btn.value = replaceString(TNBTEXTS.TXT_BTN_PLAY_NOW_TRIALS_REMAINING[_LANG], noOfTrialsLeft);
    });

    Array.prototype.forEach.call(document.querySelectorAll("#back"), btn => {
        btn.value = (TNBTEXTS.TXT_BACK[_LANG]).toUpperCase();
        btn.text = (TNBTEXTS.TXT_BACK[_LANG]).toUpperCase();
    });

    Array.prototype.forEach.call(document.querySelectorAll("#playNow"), btn => {
        btn.value = (TNBTEXTS.TXT_BTN_PLAY_NOW[_LANG]).toUpperCase();
    });


    Array.prototype.forEach.call(document.querySelectorAll("#trail-msg"), txt => {
        txt.innerHTML = (TNBTEXTS.TXT_ON_SESSIONS_LIMIT_REACHED[_LANG]).toUpperCase() + "</br></br></br>";
    });


    document.getElementById("no-sim-text").innerHTML = (TNBTEXTS.TXT_ERROR_MCC[_LANG]).toUpperCase();

    document.getElementById("buy-now").value = (TNBTEXTS.TXT_BTN_BUY_NOW[_LANG]).toUpperCase();

    if (tier == 9) {
        document.getElementById("buy-now").style.marginBottom = "5px";
        document.getElementById("terms").style.marginBottom = "5px";
    }
    document.getElementById("confirm-purchase").innerHTML = (TNBTEXTS.TXT_PURCHASE_CONFIRMATION[_LANG]).toUpperCase();

    document.getElementById("price").innerHTML = (TNBTEXTS.TXT_PRICE[_LANG]).toUpperCase() + ((tier == 9) ? TNBTEXTS.OD_TEXT_RENTAL[_LANG] : " ") + ' :' + "</br>" + cost + " " + (canShowVat ? TNBTEXTS.TXT_BTN_BUY_THE_GAME_VAT[_LANG] : "") + (canShowSMS ? "</br> " + replaceString(TNBTEXTS.TXT_BTN_BUY_THE_GAME_SMS_COUNT[_LANG], noOfSMS) : "") + ((tier == 9) ? "</br>" + TNBTEXTS.TXT_DISCLAIMER[_LANG] : " ");

    document.getElementById("terms").value = TNBTEXTS.TXT_BTN_SUPPORT[_LANG] + "\n" + TNBTEXTS.TXT_BTN_TERMS[_LANG];

    document.getElementById("termstxt").innerHTML = (TNBTEXTS.OD_GAME_GDPR[_LANG]);

    document.getElementById("termsFull").innerHTML = (TNBTEXTS.OD_GAME_GDPR[_LANG]) + "</br></br>";
    document.getElementById("disclaimer").innerHTML = disclaimer;
    document.getElementById("loading").innerHTML = (TNBTEXTS.TXT_PLEASE_WAIT[_LANG]).toUpperCase();

    document.getElementById("terms-conds").innerHTML = (TNBTEXTS.TXT_BTN_TERMS[_LANG] + ":</br>" + ((tier != 9) ? TNBTEXTS.TXT_PURCHASE[_LANG] : "GAME COST ") + " " +
        cost + (canShowSMS ? replaceString(TNBTEXTS.TXT_BTN_BUY_THE_GAME_SMS_COUNT[_LANG], noOfSMS) : "") + "</br>" + ((tier == 9) ? TNBTEXTS.TXT_DISCLAIMER[_LANG] : "") + "</br></br>" + replaceString(TNBTEXTS.TXT_TERMS[_LANG], shortcode)).toUpperCase() + "<br><br>" + (TNBTEXTS.TXT_SUPPORT[_LANG]).toUpperCase() + ":</br>" + (TNBTEXTS.TXT_SUPPORT_CONTACT[_LANG]).toUpperCase();

    document.getElementById("payment-error-txt").innerHTML = (TNBTEXTS.TXT_ERROR_SENDING_SMS[_LANG]).toUpperCase();

    document.getElementById("payment-pending-txt").innerHTML = (TNBTEXTS.TXT_HELP_COMMON[_LANG]).toUpperCase() + "</br></br>" + (TNBTEXTS.TXT_CREDITS_WARNING[_LANG]).toUpperCase();

    document.getElementById("payment-success-txt").innerHTML = (TNBTEXTS.TXT_UNLOCK_SUCCESSFUL[_LANG]).toUpperCase();

    document.getElementById("exit").value = (TNBTEXTS.TXT_EXIT[_LANG]).toUpperCase();

    document.getElementById("unlock-trail-msg").innerHTML = (TNBTEXTS.TXT_ON_SESSIONS_LIMIT_REACHED[_LANG]).toUpperCase();


    Array.prototype.forEach.call(document.querySelectorAll("#enter-code"), btn => {
        btn.value = (TNBTEXTS.TXT_BTN_ENTER_CODE[_LANG]).toUpperCase();
    });

    document.getElementById("code-trail").innerHTML = (TNBTEXTS.TXT_ENTER_PIN[_LANG]).toUpperCase() + "</br></br>";

    document.getElementById("code-help").value = (TNBTEXTS.TXT_BTN_HELP[_LANG]).toUpperCase();

    document.getElementById("helpMessage").innerHTML = (TNBTEXTS.TXT_CREDITS_WARNING[_LANG]).toUpperCase() + "</br></br>" + (TNBTEXTS.TXT_SUPPORT[_LANG]).toUpperCase() + "</br>" + (TNBTEXTS.TXT_SUPPORT_CONTACT[_LANG]).toUpperCase() + "</br></br>";

    document.getElementById("purchase-order").innerHTML = (TNBTEXTS.TXT_HELP[_LANG]).toUpperCase() + "</br></br>";

    document.getElementById("buy-code").value = (TNBTEXTS.TXT_BTN_HELP_RETRY_MO[_LANG]).toUpperCase();
    document.getElementById("error-code").innerHTML = (TNBTEXTS.TXT_ERROR_WRONG_CODE[_LANG]).toUpperCase();

    document.getElementById("success-code").innerHTML = (TNBTEXTS.TXT_UNLOCK_SUCCESSFUL[_LANG]).toUpperCase() + "</br></br>";

    Array.prototype.forEach.call(document.querySelectorAll("#select"), link => {
        link.text = (TNBTEXTS.TXT_SELECT[_LANG]).toUpperCase();
    });

    Array.prototype.forEach.call(document.querySelectorAll("#exit"), link => {
        link.text = (TNBTEXTS.TXT_EXIT[_LANG]).toUpperCase();
    });

}

function updateGame() {
    var element = document.getElementById("myprogressBar");
    var kbData = document.getElementById("kb-downloaded");
    var percentData = document.getElementById("percent-downloaded");
    var width = 1;

    function scene() {
        if (width >= 100) {
            clearInterval(identity);
        } else {
            width++;
            element.style.width = width + '%';
            element.innerHTML = width * 1 + '%';
            percentData.innerHTML = width * 1 + '%';
            kbData.innerHTML = width * 1 + 'kb';
        }
    }
}

function cancelUpdate() {
    isLoading = false;
    isUpdateModule = true;
    // console.log("Download Abort or Error");
    //hideCurrentDiv();
    document.getElementById('download-update').style.display = 'none';
    document.getElementById('loadingwheel').style.display = "none";
    document.getElementById('no-internet').style.display = 'block';
    var c = document.getElementById('no-internet').children;

    if (trialsLeft) {
        c[0].style.display = 'block';
        c[1].style.display = 'block';
        c[2].style.display = 'block';
        c[1].focus();
    } else {
        c[0].style.display = 'block';
        c[1].style.display = 'none';
        c[2].style.display = 'block';
        c[2].focus();
    }

    c[1].focus();

    document.getElementById('footer1').style.display = 'block';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';
    document.getElementById('footer4').style.display = 'none';
}

function showStatusUpdate() {
    isUpdateModule = true;
    isLoading = true;
    hideCurrentDiv();

    document.getElementById('download-update').style.display = 'block';
    document.getElementById('cancel').style.display = 'none';

    document.getElementById('footer1').style.display = 'none';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';
    document.getElementById('footer4').style.display = 'none';
}

function hideStatusUpdate() {
    isUpdateModule = false;
    isLoading = true;
    hideCurrentDiv();
    document.getElementById('splash').style.display = "none";
    document.getElementById('loadingwheel').style.display = "block";
    document.getElementById('footer1').style.display = 'none';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';
    document.getElementById('footer4').style.display = 'none';
}

function retryUpdate() {
    isLoading = true;
    // console.log("Retry Download!");

    hideCurrentDiv();
    document.getElementById('download-update').style.display = 'none';

    document.getElementById('splash').style.display = "none";
    document.getElementById('loadingwheel').style.display = "block";
    window.TNBManager.updateSDK();
}

function replaceString(str, value) {
    return str.replace(/%.*%/, value);
}

function help() {
    hideCurrentDiv();
    document.getElementById('footer1').style.display = 'none';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'block';
    document.getElementById('helpScreen').style.display = 'block';
    var c = document.getElementById('helpScreen').children;
    // console.log(c[1]);
    c[1].focus();
}

function downArrow() {
    hideCurrentDiv();
    document.getElementById('footer1').style.display = 'block';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';
    document.getElementById('fullTerms').style.display = 'block';
    document.getElementById('arrow-up').focus();
}

function upArrow() {
    buyGame();
}

function buyGame() {
    // console.log("buygame");
    hideCurrentDiv();
    var divId;
    if (isSimPresent) {
        divId = 'puchase';
        document.getElementById(divId).style.display = 'block';
        document.getElementById('buy-now').focus();
    } else {
        divId = 'no-sim';
        document.getElementById(divId).style.display = 'block';
        document.getElementById('back').focus();
    }

    document.getElementById('footer1').style.display = 'none';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'block';
}

function unlockGame(code) {
    hideCurrentDiv();
    document.getElementById('loading').style.display = 'block';

    document.getElementById('footer1').style.display = 'none';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';

    isLoading = true;

    transactionCallback = (status) => {
        isLoading = false;
        document.getElementById('loading').style.display = 'none';
        validateUnlockScreen(status);
    };
    // if (!isDebugMode) {}
    isValidCode = window.TNBManager.validateUnlockCode(code);

    // console.log("Unlock Game code entered :" + code);
    // console.log("The entered code is :" + isValidCode);

    if (!isValidCode) {
        isLoading = false;
        document.getElementById('loading').style.display = 'none';
        document.getElementById('code-error').style.display = 'block';
        (document.getElementById('code-error').children)[1].focus();
    }
}

function validateUnlockScreen(status) {
    switch (status) {
        case 'successful':
            gameUnlocked = true;
            document.getElementById('code-success').style.display = 'block';
            (document.getElementById('code-success').children)[1].focus();
            break;
        default:
            document.getElementById('code-error').style.display = 'block';
            (document.getElementById('code-error').children)[1].focus();
            break;
    }
}

function buyNow() {
    hideCurrentDiv();
    document.getElementById('loading').style.display = 'block';

    document.getElementById('footer1').style.display = 'none';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';

    isLoading = true;

    // setTimeout(() => {
    //     document.getElementById('loading').style.display = 'none';
    //     loadPaymentScreen("successful");
    // }, 200);

    window.TNBManager.createTransaction();
    transactionCallback = (status) => {
        document.getElementById('loading').style.display = 'none';
        loadPaymentScreen(status);
    };
}

function loadPaymentScreen(payment) {
    isLoading = false;
    switch (payment) {
        case 'successful':
            gameUnlocked = true;
            document.getElementById('payment-success').style.display = 'block';
            document.getElementById('footer1').style.display = 'none';
            document.getElementById('playNow').focus();
            document.getElementById('footer1').style.display = 'block';
            break;
        case 'failed':
            document.getElementById('payment-pending').style.display = 'block';
            document.getElementById('footer1').style.display = 'none';
            document.getElementById('exit').focus();
            document.getElementById('footer1').style.display = 'block';
            break;
        case 'pending':
            document.getElementById('payment-pending').style.display = 'block';
            document.getElementById('footer1').style.display = 'none';
            document.getElementById('exit').focus();
            document.getElementById('footer1').style.display = 'block';
            break;
        default:
            document.getElementById('payment-pending').style.display = 'block';
            document.getElementById('footer1').style.display = 'none';
            document.getElementById('exit').focus();
            document.getElementById('footer1').style.display = 'block';
            break;
    }
}

function playNow() {
    if (gameUnlocked) {
        isFreeTrialMode = false;
        // console.log("Play Game In Purchase Mode");
        document.removeEventListener('keydown', logKey);
        document.getElementById('container-fluid').style.display = 'none';
        document.dispatchEvent(startGameEvent);
        document.getElementById('loadingwheel').style.display = "block";
        return;
    }

    if (trialsLeft) {
        // console.log("Play Free Trial Game");
        document.removeEventListener('keydown', logKey);
        document.getElementById('container-fluid').style.display = 'none';
        isFreeTrialMode = true;

        isTrialOver = true;
        if (!isDebugMode) {
            window.TNBManager.decreaseFreeTrials();
        } else {
            debugTrials--;
        }
        document.dispatchEvent(startGameEvent);
        document.getElementById('welcome').style.display = 'none';
        document.getElementById('loadingwheel').style.display = "block";
    } else {
        var c = document.getElementById('welcome').children;

        c[0].style.display = 'none';
        c[1].style.display = 'block';
        c[3].style.display = 'none';

        c[2].style.display = 'block';
        c[2].focus();
    }

}

function back() {
    hideCurrentDiv();
    document.getElementById('puchase').style.display = 'block';
    document.getElementById('terms-conditions').style.display = 'block';
    var backLink = document.getElementById('footer').children;
    document.getElementById(backLink[0].id).style.display = 'block';
    document.getElementById(backLink[2].id).style.display = 'block';
    document.getElementById(backLink[1].id).style.display = 'none';
}

function exit() {
    window.close();
}

function openManualMode() {

    // console.log("Start Unlock Mode!");
    document.getElementById('unlock').style.display = 'block';
    var c = document.getElementById('unlock').children;
    if (!trialsLeft) {

        c[0].style.display = 'block';
        c[2].style.display = 'block';
        c[3].style.display = 'none';
    } else {
        c[0].style.display = 'none';
        c[2].style.display = 'block';
        c[3].style.display = 'block';
    }

    document.getElementById('enter-code').focus();
    document.getElementById('footer1').style.display = 'block';
    document.getElementById('footer2').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';
}

function suppTerms() {
    hideCurrentDiv();
    document.getElementById('terms-conditions').style.display = 'block';
    document.getElementById('footer1').style.display = 'none';
    document.getElementById('footer3').style.display = 'none';
    document.getElementById('footer2').style.display = 'block';
}

function isHidden(el) {
    var style = window.getComputedStyle(el);
    return ((style.display === 'none') || (style.visibility === 'hidden'))
}

function getCurrentDivId() {
    var all = document.getElementsByTagName("div");
    var current_div = [];
    for (var i = 0, max = all.length; i < max; i++) {
        if (!isHidden(all[i])) {
            // console.log("visible current_div:" + all[i].id);
            current_div.push(all[i].id);
        }
    }

    // console.log("visible current_div:" + current_div.length);

    return current_div[1];
}

function hideCurrentDiv() {

    current_div_id = getCurrentDivId();

    if (current_div_id != null)
        document.getElementById(current_div_id).style.display = 'none';
}

function goBackToEnterCode() {
    enterCode();
}

function enterCode() {
    hideCurrentDiv();
    // console.log("Enter code screen");
    document.getElementById('code').style.display = 'block';
    document.getElementById('partitioned').value = "";
    document.getElementById('partitioned').focus();
    document.getElementById('footer1').style.display = 'none';
    document.getElementById('footer3').style.display = 'block';
    document.getElementById('footer2').style.display = 'none';
    var input = document.getElementById("partitioned");
    input.onfocus = function() {
        setTimeout(function() {
            input.setSelectionRange(0, 0);
        }, 0);
    };
}

function commonBack() {
    currentNode = getCurrentDivId();
    // console.log(currentNode);
    hideCurrentDiv();

    switch (currentNode) {
        case 'puchase':
            if (!isTrialOver) {
                welcomeScreen();
            } else {
                endDemoScreen();
            }
            break;
        case 'terms-conditions':
            buyGame();
            break;
        case 'payment-error':
            buyGame();
            break;
        case 'no-sim':
            if (!isTrialOver) {
                welcomeScreen();
            } else {
                endDemoScreen();
            }
            break;
        case 'code-error':
            openManualMode();
            break;
        case 'helpScreen':
            enterCode();
            break;
        case 'code':
            openManualMode();
            break;
        case 'download-update':
            break;
        case 'no-internet':
            retryUpdate();
            break;
        case 'update-like-game':
            exit();
            break;
    }
}

function getNextSiblings(el, filter) {
    var siblings = [];
    while (el = el.nextSibling) { if (!filter || filter(el)) siblings.push(el); }
    return siblings;
}

function getPreviousSiblings(el, filter) {
    var siblings = [];
    while (el = el.previousSibling) { if (!filter || filter(el)) siblings.push(el); }
    return siblings;
}

function logKey(e) {
    var node = document.activeElement;
    if (!isLoading) {
        if (e.keyCode == 13 || e.key == 'SoftLeft') {
            // console.log(node.getAttribute('onclick'));
            document.getElementById("buttonBuy").click();
            switch (node.id) {
                case 'buttonBuy':
                    buyGame();
                    break;
                case 'playNowTrails':
                    playNow();
                    break;
                case 'buy-now':
                    buyNow();
                    break;
                case 'terms':
                    suppTerms();
                    break;
                case 'arrow-down':
                    downArrow();
                    break;
                case 'arrow-up':
                    upArrow();
                    break;
                case 'playNow':
                    playNow();
                    break;
                case 'back':
                    commonBack();
                    break;
                case 'enter-code':
                    enterCode();
                    break;
                case 'partitioned':
                    // console.log(document.getElementById('partitioned').value);
                    unlockGame(document.getElementById('partitioned').value);
                    break;
                case 'code-help':
                    help();
                    break;
                case 'buy-code':
                    welcomeScreen();
                    localStorage.setItem(window.TNBManager.manualActivationtInfoKey, '');
                    break;
                case 'exit':
                    exit();
                    break;
                case 'cancel':
                    cancelUpdate();
                    break;
            }
        }
        if (e.key == 'SoftRight') {
            // console.log(e.key);
            if (document.getElementById('footer1').style.display == 'block') {
                exit();
            } else {
                commonBack();
            }
        }


        var nextSibling;
        var prevSiblings;

        if (e.keyCode == 40) {
            nextSibling = getNextSiblings(node);
            if (nextSibling != null) {
                for (var i = 0; i < nextSibling.length; i++) {
                    node = nextSibling[i];
                    if (node.tagName == 'INPUT') {

                        node.focus();
                        break;
                    }
                }
            }
        }
        if (e.keyCode == 38) {
            prevSiblings = getPreviousSiblings(node);
            if (prevSiblings != null) {
                for (var i = 0; i < prevSiblings.length; i++) {
                    node = prevSiblings[i];
                    if (node.tagName == 'INPUT') {

                        node.focus();
                        break;
                    }
                }
            }
        }
    }
}
var TNBManager = {
    billingData: {
        freeTrials: null,
        unlocked: false,
        UUID: null,
        IMEI: null,
        certified: false,
        profilesUpdated: false,
        simData: [{
                inserted: false,
                online: false,
            },
            {
                inserted: false,
                online: false,
            }
        ],
        validSimSlot: null,
        online: false,
        paymentOptions: {
            payment_tier: null,
            payment_name: null,
            continue_availble: false
        },
        priceOptions: {
            price: null,
            formatted_price: null,
            currency_code: null,
            disclaimer: null,
            shortcode: null,
            vat: false,
            "Display number of SMS": false,
        },
        transactionHistory: null
    },

    paymentData: {
        tier: null,
        buyDate: null,
    },

    manualActivationData: {
        tier: null,
        status: null
    },

    simID: {
        slotOne: 0,
        slotTwo: 1
    },

    updateData: {
        loaded: null,
        total: null
    },

    isManualUnlockMode: false,

    imeiKey: "tnb_imei",
    uuidKey: "tnb_uuid",
    trialsKey: "racingattack_trials_left",
    gamePaymentInfoKey: "racingattack_payment_info",
    manualActivationtInfoKey: "racingattack_manual_activation_info",
    productID: "racing-attack-25",
    deviceName: "Nokia Leo",
    isUpdated: false,

    isChinaFlag: null,

    startTNBScreens: Function,
    transactionCallback: Function,
    updateModuleCallBack: Function,

    init: function() {

        // console.log = function() {}
        // localStorage.clear();
        // For testing
        // localStorage.setItem(this.trialsKey, 3)

        // Check for update module
        // console.log("Check for update Module");
        // this.updateSDK();

        // console.log("Init TNB Manager");
        this.billingData.unlocked = this.checkTNBStatus();
        // console.log("Game Status: " + this.billingData.unlocked);
        this.billingData.freeTrials = this.checkFreeTrials();
        if (this.billingData.unlocked === false) {
            this.getSDKVariables();
            this.setTransactionCallBacks();
        } else {
            if (this.paymentData.tier == 9) {
                let today = new Date();
                let buyDate = new Date(this.paymentData.buyDate);
                let daysPassed = Math.floor((Math.abs(today - buyDate) / (1000 * 60 * 60 * 24)));
                if (daysPassed <= 30) {
                    this.getSDKVariables();
                    this.setTransactionCallBacks();
                    localStorage.setItem(this.gamePaymentInfoKey, "");
                } else {
                    // start Game Rental Mode
                    // console.log("Start Game");
                    this.startGame('start-rental', 2000);
                }
            } else if (this.paymentData.tier == 10) {
                // start Game 
                // console.log("Start Game");
                this.startGame('start-unlocked', 2000);
            } else if (this.paymentData.tier == 8) {
                // start Game 
                // console.log("Start Game");
                this.startGame('start-free', 2000);
            }
        }
        return true;
    },

    getSDKVariables: function() {
        // console.log("Getting SDK params");

        // Check if the app is certified
        this.checkIfCertifiedApp();

        if (this.billingData.certified) {
            // console.log("Get sim details");

            // Get Sim Data
            this.billingData.simData = this.getSimData();

            if (this.billingData.simData == null) {
                // console.log("Unable to fetch sim details");
                return;
            }

            if (navigator.mozMobileConnections.length == 1) {
                if (!this.billingData.simData[this.simID.slotOne].inserted) {
                    this.startGame('no-sim', 2000);
                    return;
                }
            }

            // Check if any sim is inserted
            if (!this.billingData.simData[this.simID.slotOne].inserted && !this.billingData.simData[this.simID.slotTwo].inserted) {
                //No Sim Mode
                // console.log("No Sim Mode");
                this.startGame('no-sim', 2000);
            } else {
                // console.log("Sim Mode");
                // Get the UUID number
                this.billingData.UUID = localStorage.getItem(this.uuidKey);

                // console.log("Old UUID :" + this.billingData.UUID)

                if (this.billingData.UUID == null || typeof this.billingData.UUID == undefined) {
                    this.generateUUID();
                }

                // Get the IMEI number
                // console.log("Checking IMEI");
                this.billingData.IMEI = JSON.parse(localStorage.getItem(this.imeiKey));
                // console.log(this.billingData.IMEI);


                // Check sim slots
                let connections = navigator.mozMobileConnections.length;
                // console.log("Total Sim Slots :" + connections);

                if (this.billingData.IMEI == null || typeof this.billingData.IMEI == undefined) {
                    // console.log("Get IMEI");
                    switch (connections) {
                        case 1:
                            this.getSingleSimIMEI();
                            break;
                        case 2:
                            this.getDualSimIMEI();
                            break;
                    }
                } else {
                    setTimeout(() => {
                        localStorage.setItem(this.imeiKey, JSON.stringify(this.billingData.IMEI));
                        this.initODSDK(this.billingData.UUID, this.billingData.IMEI);
                    }, 1500);
                }
            }
        } else {
            console.log("The App is not Certified!");
        }
    },


    generateUUID: function() { // Public Domain/MIT
        var d = new Date().getTime(); //Timestamp
        var d2 = (performance && performance.now && (performance.now() * 1000)) || 0; //Time in microseconds since page-load or 0 if unsupported
        this.billingData.UUID = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.random() * 16; //random number between 0 and 16
            if (d > 0) { //Use timestamp until depleted
                r = (d + r) % 16 | 0;
                d = Math.floor(d / 16);
            } else { //Use microseconds since page-load if supported
                r = (d2 + r) % 16 | 0;
                d2 = Math.floor(d2 / 16);
            }
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });

        // console.log("new UUID :" + this.billingData.UUID);
        localStorage.setItem(this.uuidKey, this.billingData.UUID);
    },

    // IMEI for DUAL Sim device
    getDualSimIMEI: function() {
        // console.log("Dual SIM IMEI");
        this.billingData.IMEI = {};
        // let tel = navigator.mozTelephony;
        // let _this = this;

        // Make IMEI
        this.billingData.IMEI[0] = this.makeid();
        this.billingData.IMEI[1] = this.makeid();

        // console.log(this.billingData.IMEI);

        localStorage.setItem(this.imeiKey, JSON.stringify(this.billingData.IMEI));

        setTimeout(() => {
            this.initODSDK(this.billingData.UUID, this.billingData.IMEI);
        }, 500);

        // tel.dial("*#06#", 0).then(function (call) {
        //     call.result.then(function (MMIResult) {
        //         _this.billingData.IMEI[0] = MMIResult.statusMessage;
        //      // console.log(_this.billingData.IMEI);
        //     });
        // });

        // tel.dial("*#06#", 1).then(function (call) {
        //     call.result.then(function (MMIResult) {
        //         //console.log(MMIResult.statusMessage);
        //         _this.billingData.IMEI[1] = MMIResult.statusMessage;
        //         localStorage.setItem(_this.imeiKey, JSON.stringify(_this.billingData.IMEI));
        //         _this.initODSDK(_this.billingData.UUID, _this.billingData.IMEI);
        //     });
        // });
    },

    makeid: function() {
        var text = "";
        var possible = "1234567890";

        for (var i = 0; i < 15; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }

        return text;
    },


    // IMEI for Single Sim device
    getSingleSimIMEI: function() {
        // console.log("Single SIM IMEI");
        this.billingData.IMEI = {};
        // let tel = navigator.mozTelephony;
        // let _this = this;

        // Make IMEI
        this.billingData.IMEI[0] = this.makeid();
        this.billingData.IMEI[1] = this.makeid();

        // console.log(this.billingData.IMEI);

        localStorage.setItem(this.imeiKey, JSON.stringify(this.billingData.IMEI));

        setTimeout(() => {
            this.initODSDK(this.billingData.UUID, this.billingData.IMEI);
        }, 500);
        // let tel = navigator.mozTelephony;
        // var _this = this;
        // tel.dial("*#06#", 0).then(function(call) {
        //     call.result.then(function(MMIResult) {
        //         _this.billingData.IMEI[0] = MMIResult.statusMessage;
        //      // console.log(_this.billingData.IMEI[0])
        //      // console.log(_this.billingData.IMEI);
        //         // _this.initODSDK(_this.billingData.UUID, _this.billingData.IMEI);
        //     });
        // });
    },

    // Inti ODSDK
    initODSDK: function(_uuid, _imei) {
        var _this = this;
        // console.log("Init ODSDK from TNB Flow");
        let _language = window.navigator.language.slice(0, 2);

        giveFreeGame = function() {
            _this.rewardFreeGame();
        };

        finishedInitialization = function() {
            _this.profileMatching();
        };

        ODSDK.init(_uuid, _imei, _language);
        // console.log("Online/Offline Init Completed");

        // setTimeout(() => {
        //     _this.profileMatching();
        // }, 3000);
    },

    checkChinaFlag: function() {
        if (this.billingData.simData != null || typeof this.billingData.simData != undefined) {
            if (this.billingData.simData[this.simID.slotOne].inserted) {
                this.isChinaFlag = false;
                this.isChinaFlag = this.isChinaFlag && navigator.mozMobileConnections[this.simID.slotOne].voice.network.mcc == 460;
                // console.log("Sim one is China sim :" + this.isChinaFlag + " MCC :" + navigator.mozMobileConnections[this.simID.slotOne].voice.network.mcc);
                if (this.isChinaFlag) {
                    this.rewardFreeGame();
                    return;
                }
            }

            if (navigator.mozMobileConnections.length == 2) {
                if (this.billingData.simData[this.simID.slotTwo].inserted) {
                    this.isChinaFlag = false;
                    this.isChinaFlag = this.isChinaFlag && navigator.mozMobileConnections[this.simID.slotTwo].voice.network.mcc == 460;
                    // console.log("Sim two is China sim  :" + this.isChinaFlag + " MCC :" + navigator.mozMobileConnections[this.simID.slotTwo].voice.network.mcc);
                    if (this.isChinaFlag) {
                        this.rewardFreeGame();
                        return;
                    }
                }
            }
        }
    },

    getPayOptions: function(payOption) {
        this.billingData.paymentOptions = payOption;
        // console.log("Payment Tire :" + this.billingData.paymentOptions.payment_tier);
        // console.log("Payment Name :" + this.billingData.paymentOptions.payment_name);
        // console.log("Payment Continue Available :" + this.billingData.paymentOptions.continue_availble);

        // if tier = 8, give the game for free, 100 free trials
        // if tier = 9, rent flow
        // if tier = 10, buy flow

        if (this.billingData.paymentOptions != false && this.billingData.paymentOptions.payment_tier != 0) {
            switch (this.billingData.paymentOptions.payment_tier) {
                case 8:
                    // Free Mode
                    // console.log("Start Free Mode");
                    // Start the game
                    this.billingData.unlocked = true;
                    this.startGame('start-free', 500);
                    break;
                case 9:
                    // Rental Mode
                    this.getPrice();
                    this.getPreviousTransaction();
                    // console.log("Init Rental Mode");
                    this.startGame('init-rental', 500);
                    break;
                case 10:
                    // Unlock Mode
                    this.getPrice();
                    this.getPreviousTransaction();
                    // console.log("Init Unlock Mode");
                    this.startGame('init-unlock', 500);
                    break;
                default:
                    // Free Mode
                    // console.log("Start Default Free Mode");
                    this.billingData.unlocked = true;
                    this.startGame('start-free', 500);
                    // start the game
                    break;
            }
        } else {
            // Error Mode
            // console.log("Error Mode");
            // this.startGame('error-mode', 2000);
        }
    },

    getPrice: function() {
        // To rent 9
        // To unlock 10
        if (this.billingData.certified == true && this.billingData.paymentOptions != false) {
            try {
                gamePrice = ODSDK.getPrice(this.billingData.paymentOptions.payment_tier, this.billingData.validSimSlot);
                this.billingData.priceOptions = gamePrice;
                // console.log(this.billingData.priceOptions);
                return true;
            } catch (e) {
                return false;
            }
        }
        return false
    },

    createTransaction: function() {
        // console.log("Init Transaction");
        if (this.billingData.certified == true) {
            // console.log("Start Transaction");
            ODSDK.createTransaction(Number(this.billingData.paymentOptions.payment_tier), String(this.productID), Number(this.billingData.validSimSlot), String(this.deviceName));
        }
    },


    setTransactionCallBacks: function() {
        let _this = this;
        // Transaction Success Callback
        onTransactionSuccess = function(data) {
            // console.log(data);
            /**
             * data {
             *  "tier":tier,
                "prodId":prodId,
                "srvId":srvId,
                "status":"successful",
                "transaction": currentTransaction
                }
             */
            // start game
            _this.unlockGame(data.tier);

            transactionCallback(data.status);
        }

        // Transaction Error Callback
        onTransactionError = function(data) {
            /**
             *data {
                "tier": tier,
                "prodId": prodId,
                "srvId": srvId,
                "status": "failed",
                "reason": "status" 
             }
             */
            // _this.setManualUnlock(data.tier, data.status)
            // console.log(data);
            transactionCallback(data.status);
        }
    },

    getPreviousTransaction: function() {
        if (this.billingData.certified == true) {
            this.billingData.transactionHistory = ODSDK.getTransactionsHistory();
            // console.log("Previous Transactions History");
            // console.log(JSON.stringify(this.billingData.transactionHistory));

            if (this.billingData.transactionHistory !== null && this.billingData.transactionHistory.length > 0) {
                let transactionStatus = this.billingData.transactionHistory[0].status;
                // console.log(this.billingData.transactionHistory[0].status);
                // console.log(this.billingData.transactionHistory[0].idTier)
                if (transactionStatus == 'failed' || transactionStatus == 'pending') {
                    this.isManualUnlockMode = true; //this.checkManualActivation();
                    this.setManualUnlock(this.billingData.transactionHistory[0].idTier, this.billingData.transactionHistory[0].status);
                } else if (transactionStatus == 'successful') {
                    if (!this.billingData.unlocked) {
                        this.unlockGame(this.billingData.transactionHistory[0].idTier);
                        this.billingData.unlocked = true;
                    }
                    // console.log("Last Transaction was " + transactionStatus);
                }
            }
        }
        // console.log("Got the Previous Transaction!");
    },

    checkIfCertifiedApp: function() {
        if (typeof navigator.mozTelephony != undefined && navigator.mozTelephony != null &&
            typeof navigator.mozMobileMessage != undefined && navigator.mozMobileMessage != null &&
            typeof navigator.mozMobileConnections != undefined && navigator.mozMobileConnections != null) {
            this.billingData.certified = true;
        } else {
            this.billingData.certified = false;
        }
    },

    checkTNBStatus: function() {
        let purchaseData = localStorage.getItem(this.gamePaymentInfoKey);
        if (typeof purchaseData !== undefined && purchaseData !== "" && purchaseData !== null) {
            //return JSON.parse(purchaseData);
            this.paymentData = JSON.parse(purchaseData);
            // console.log(this.paymentData);
            return true;
        } else {
            return false;
        }
    },

    checkFreeTrials: function() {
        let trials = localStorage.getItem(this.trialsKey);
        if (typeof trials !== undefined && trials !== "" && trials !== null) {
            return Number(trials);
        } else {
            trials = 3;
            localStorage.setItem(this.trialsKey, trials)
        }
        return false;
    },

    decreaseFreeTrials: function() {
        let trials = Number(localStorage.getItem(this.trialsKey));
        // console.log("Current Trials :" + trials);
        trials--;
        // console.log("Trials Left :" + trials);
        localStorage.setItem(this.trialsKey, trials)
    },

    profileMatching: function() {
        // console.log("Profile Matching");
        if (this.billingData.simData != null || typeof this.billingData.simData != undefined) {
            if (this.billingData.simData[this.simID.slotOne].inserted) {
                // console.log("Checking Sim Slot 0");
                let payOption = ODSDK.checkPayOptions(this.simID.slotOne)
                    // console.log(payOption);
                if (payOption && typeof payOption != undefined && typeof payOption.payment_tier != undefined && payOption.payment_tier != 0) {
                    this.billingData.validSimSlot = this.simID.slotOne;
                    // console.log("Valid Sim Slot :" + this.simID.slotOne);
                    this.getPayOptions(payOption);
                    return;
                }
            }

            if (navigator.mozMobileConnections.length == 2) {
                if (this.billingData.simData[this.simID.slotTwo].inserted) {
                    // console.log("Checking Sim Slot 1");
                    let payOption = ODSDK.checkPayOptions(this.simID.slotTwo)
                        // console.log(payOption);
                        // console.log("Checking Sim Slot 1");
                    if (payOption && typeof payOption != undefined && typeof payOption.payment_tier != undefined && payOption.payment_tier != 0) {
                        this.billingData.validSimSlot = this.simID.slotTwo;
                        // console.log("Valid Sim Slot :" + this.simID.slotTwo);
                        this.getPayOptions(payOption);
                        return;
                    }
                }
            }
            // console.log("Check for update module");

            if (this.billingData.validSimSlot == null || typeof this.billingData.validSimSlot == undefined) {
                // Go to update module
                if (!this.isUpdated) {
                    this.updateSDK();
                } else {
                    // Free Mode
                    this.rewardFreeGame();
                }
            }
        }
    },


    updateSDK: function() {
        let _this = this;
        //let connections = navigator.mozMobileConnections;
        let connection = navigator.onLine;
        // console.log("Internet :" + connection);

        if (connection) {
            // console.log("Internet :" + connection);

            finishedUpdate = function() {
                updateModuleCallBack('successful');
                _this.isUpdated = true;
                _this.profileMatching()
            };

            failedUpdate = function() {
                // console.log("An error occurred during the transaction");
                updateModuleCallBack('failure');
            };

            ODSDK.updateData();
            // console.log("Update Has Started");
            updateModuleCallBack('started');

            // Start Update Module
            // onUpdate = function (data) {
            // let request = data.request;
            // request.onerror = function () {
            //  // console.log("An error occurred during the transaction");
            //     updateModuleCallBack('failure');
            // };

            // request.onprogress = function (event) {
            //     updateModuleCallBack('update', event);
            // };


            // request.onreadystatechange = function (oEvent) {
            //     if (request.readyState === 4 && request.status === 200) {

            //     }
            // };
            //}

        } else {
            // console.log("No Internet connection");
            updateModuleCallBack('failure');
            // updateModuleCallBack('failure', null);
        }
    },

    rewardFreeGame: function() {
        // console.log("Start Free Mode");
        this.billingData.unlocked = true;
        this.startGame('start', 2000);
    },

    getSimData: function() {
        let simData = [];
        let connections = navigator.mozMobileConnections;
        // console.log(connections);
        if (typeof connections != "undefined") {
            for (let i = 0, length = connections.length; i < length; i++) {
                simData.push({
                    inserted: false,
                    online: false,
                });
                if (connections[i].data.network == null) {
                    simData[i].inserted = simData[i].inserted;
                    // console.log("Network : " + simData[i].inserted)
                } else if (connections[i].data.network.state == null) {
                    simData[i].inserted = simData[i].inserted;
                    // console.log("Sim " + i + " State : " + simData[i].inserted)
                } else {
                    simData[i].inserted = simData[i].inserted || connections[i].data.network.state == "connected";
                    // console.log("Valid Sim " + i + ": " + simData[i].inserted)
                }

                if (connections[i].data.connected == true) {
                    simData[i].online = true;
                    // console.log("Internet Connection: " + simData[i].online)
                }
            }
            return simData;
        } else {
            // console.log("Unable to get Sim data!");
            return null;
        }
    },

    setManualUnlock: function(tier, status) {
        this.manualActivationData.status = status;
        this.manualActivationData.tier = tier;
        // console.log(this.manualActivationData);
        // let info = {
        //     "tier": tier,
        //     "status": status
        // }
        // localStorage.setItem(this.manualActivationtInfoKey, JSON.stringify(info));
    },

    checkManualActivation: function() {
        let activationData = localStorage.getItem(this.manualActivationtInfoKey);
        if (typeof activationData !== undefined && activationData !== "" && activationData !== null) {
            //return JSON.parse(purchaseData);
            this.manualActivationData = JSON.parse(activationData);
            // console.log(this.activationData);
            return true;
        } else {
            return false;
        }
    },

    validateUnlockCode: function(code) {
        let isValid = ODSDK.validateUnlockCode(String(code));
        // if (isValid) {
        //     unlockGame(this.manualActivationData.tier);
        //     // localStorage.setItem(this.manualActivationtInfoKey, '');
        // }
        return isValid;
    },

    unlockGame: function(tier) {
        let buyDate = new Date();
        let info = {
                "tier": tier,
                "buy_date": buyDate.getFullYear() + "/" + (buyDate.getMonth() + 1) + "/" + buyDate.getDate()
            }
            // console.log(info);
        localStorage.setItem(this.gamePaymentInfoKey, JSON.stringify(info));
    },

    startGame: function(mode, delay) {
        setTimeout(() => {
            startTNBScreens(mode);
        }, delay);
    },

    resetPurchaseMode: function() {
        // console.log("Reset Purchase Data");
        localStorage.setItem(this.gamePaymentInfoKey, '');
        localStorage.setItem(this.manualActivationtInfoKey, '');
    },

    resetTrials: function() {
        // console.log("Reset Trials");
        localStorage.setItem(this.trialsKey, 3);
    }
}

window.TNBManager = TNBManager;
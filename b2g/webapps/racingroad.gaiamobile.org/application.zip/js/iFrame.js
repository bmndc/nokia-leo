window.screenMode = "portrait";

function startGame() {
    var gameURL = encodeURI("myGame/index.html");
    if (ODSDK.debugMode == true && typeof ODSDK.debugMode != undefined) {
        console.log("Trying to open : ", gameURL);
    }
    $("#game").append(
        '<iframe src=' + gameURL + ' class="iframeClass" frameborder="0" scrolling="no"></iframe>'
    );
    iframeOnloadListner();
}

function iframeOnloadListner() {
    document.querySelector("iframe").addEventListener('load', focusIframe, true);
}

// function enableFullScreen(arg) {
//     if (arg) {
//         $(".fullscreen").show();
//     } else {
//         if ($("#screenMode").data("status") == "enabled") {
//             $(".fullscreen").hide();
//         }
//     }
// }

function focusIframe() {
    if (ODSDK.debugMode == true && typeof ODSDK.debugMode != undefined) {
        console.log("iframe loaded");
    }
    // enableFullScreen();
    setTimeout(function() {
        if (ODSDK.debugMode == true && typeof ODSDK.debugMode != undefined) {
            console.log("focusing in iframe");
        }
        document.querySelector("iframe").focus();
    }, 500)
}

function unloadIframe() {
    if (ODSDK.debugMode == true && typeof ODSDK.debugMode != undefined) {
        console.log("Focus is in Shell banner");
    }
    if (document.querySelector("iframe")) {
        document.querySelector("iframe").removeEventListener('focus', focusIframe, true);
        document.querySelector("iframe").remove();
        //  enableFullScreen(true);
        document.dispatchEvent(retunToTNBEvent);
    }
}

document.addEventListener('startOEMGameRA', e => {
    startGame();
    document.getElementById('game').style.display = 'block';
});

document.addEventListener("focus", e => {
    if (ODSDK.debugMode == true && typeof ODSDK.debugMode != undefined) {
        console.log("focus : home page")
    }
    if (document.querySelector("iframe")) {
        if (ODSDK.debugMode == true && typeof ODSDK.debugMode != undefined) {
            console.log("focusing back : iframe")
        }
        document.querySelector("iframe").focus();
    }
});
/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */

'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [test_view.js] = ' + s + '\n');
    }
  }

  var TestView = {
    hash: '#test-view',

    curTest: '',
    curMode: '',

    init: function() {
      this.view = document.querySelector('#test-view');
      window.addEventListener('openTest', this.handleEvent.bind(this));
      window.addEventListener('closeTest', this.handleEvent.bind(this));
    },

    openTest: function(evt) {
      if (this.hash !== viewManager.currentPanel) {
        viewManager.currentPanel = '#test-view';
      }

      this.createTestContainer();

      this.curTest = evt.detail.testName;
      this.curMode = evt.detail.testMode;
      debug('open test name: ' + this.curTest + ' mode: ' + this.curMode);

      let test = 'js/tests/' + this.curTest + '.js';
      LazyLoader.load(test, () => {
        Test.init();
      });
    },

    closeTest: function(result) {
      // Clean Test Object every time to make sure it's new
      document.querySelector('script[src="'+ 'js/tests/' + this.curTest + '.js' + '"]').remove();
      delete LazyLoader._loaded['js/tests/' + this.curTest + '.js'];
      window.Test = null;
      this.removeTestContainer();

      if (this.curMode === 'manu') {
        viewManager.currentPanel = '#manu-view';
      }

      if (this.curMode === 'auto' && result === 'fail') {
        AutoView.state = 'next';
        viewManager.currentPanel = '#auto-view';
      }

      if (this.curMode === 'auto' && result === 'pass') {
        AutoView.next();
      }
    },

    createTestContainer: function() {
      let container = document.createElement('div');
      container.classList.add('test-iframe');
      container.setAttribute('tabindex', 1);
      this.view.appendChild(container);
    },

    removeTestContainer: function() {
      this.view.innerHTML = '';
    },

    handleEvent: function(ev) {
      let type = ev.type;
      switch (type) {
        case 'openTest':
          this.openTest(ev);
          break;
        case 'closeTest':
          let state = ev.detail.result;
          EventSender.emit('updateResult', {
            name: this.curTest,
            mode: this.curMode,
            value: state
          });

          this.closeTest(state);
          break;
        default:
          break;
      }
    },
  };

  exports.TestView = TestView;
}(window));

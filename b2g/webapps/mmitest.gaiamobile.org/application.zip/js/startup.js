/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */

'use strict';

const DEBUG = true;

const DEVICETYPESETTING = 'deviceinfo.product_model';
// A global value define the device chip type
var DEVICETYPE = '';
// A global value define the device model name
var DEVICEMODEL = '';

// Confirm device type ASAP, and we define what type present in MMI test APP.
function getDeviceType() {
  return new Promise(function(resolve, reject) {
    let req = navigator.mozSettings.createLock().get(DEVICETYPESETTING);
    req.onsuccess = () => {
      let result = req.result['deviceinfo.product_model'];
      DEVICEMODEL = result;
      switch (result) {
        case 'msm8909_512':
          DEVICETYPE = 'qcom';
          break;
        case 'F300B':
          DEVICETYPE = 'qcom';
          break;
        case 'F261F':
          DEVICETYPE = 'sprd';
          break;
        case 'sp9820e_2c10_native':
          DEVICETYPE = 'sprd';
          break;
        case 'sp9820e_2h10_native':
          DEVICETYPE = 'sprd';
          break;
        default:
          console.log('new device type ' + result +
            ' not support, set to qcom device type as default');
          DEVICETYPE = 'qcom';
          break;
      }

      resolve(DEVICETYPE);
    };

    req.onerror = () => {
      reject(new Error('Could not get device type by ' + DEVICETYPESETTING));
    }
  });
}

function loadConfig() {
  return new Promise((resolve, reject) => {
    let xhr = new XMLHttpRequest();
    xhr.overrideMimeType('application/json');
    xhr.open('GET', '../resource/config.json', true);
    xhr.send(null);
    xhr.onreadystatechange = () => {
      if (xhr.readyState !== 4) {
        return;
      }
      if (xhr.status === 0 || xhr.status === 200) {
        try {
          let obj = JSON.parse(xhr.responseText);
          resolve(obj);
        } catch (e) {
          reject(e);
        }
      }
    };
  });
}

window.onload = function() {
  function lazyload(deviceType, config) {
    if (deviceType === 'sprd') {
      navigator.engmodeExtension.setPropertyLE('engmoded', 'enable');

      LazyLoader.load('js/remote_helper.js', () => {
        window.remoteHelper = new RemoteHelper();
      });
    }

    LazyLoader.load('js/utils.js', () => {});

    LazyLoader.load('js/customization.js');

    LazyLoader.load('js/native/native_manager.js', () => {
      window.nativeManager = new NativeManager(deviceType);
      nativeManager.init();
    });

    LazyLoader.load('js/simple_navigation_helper.js', () => {});

    LazyLoader.load('js/view_manager.js', () => {
      window.viewManager = new ViewManager();
      viewManager.start();
    });

    LazyLoader.load('js/main_view.js', () => {
      MainView.init();
    });

    LazyLoader.load('js/auto_view.js', () => {
      AutoView.init(config)
    });

    LazyLoader.load('js/manu_view.js', () => {
      ManuView.init(config);
    });

    LazyLoader.load('js/result_manager.js', () => {
      ResultManager.init(config);
    });

    LazyLoader.load('js/test_view.js', () => {
      TestView.init();
    });

    LazyLoader.load('js/testitem.js', () => {});
  }

  Promise.all([getDeviceType(), loadConfig()]).then((reponse) => {
    let device = reponse[0];
    let config = reponse[1];
    lazyload(device, config);
  });

  // Dont let the phone go to sleep while in mmitest.
  // user must manually close it
  if (navigator.requestWakeLock) {
    navigator.requestWakeLock('screen');
  }

  // We will enable the NFC in the testing script file,
  // so we need to disable the NFC first.
  if (navigator.mozNfc && navigator.mozNfc.enabled) {
    navigator.mozSettings.createLock().set({'nfc.enabled': false});
  }

  // Disable airplaneMode in mmitest to avoid fm test init fail
  navigator.mozSettings.createLock().set({'airplaneMode.enabled': false});
};

window.addEventListener('beforeunload', () => {
  EventSender.emit('nativeRequest', {message: 'stopGps'});
  navigator.engmodeExtension.setPropertyLE('engmoded', 'disable');
});


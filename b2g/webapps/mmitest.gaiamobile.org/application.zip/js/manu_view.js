/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [manu_view.js] = ' + s + '\n');
    }
  }

  var ManuView = {
    hash: '#manu-view',

    init: function ut_init(config) {
      this.view = document.getElementById('manu-view');
      this.manuList = this.view.querySelector('#manuList');
      this.loadConfig(config);

      this.manuList.addEventListener('keydown', this.handleKeydown.bind(this));
      window.addEventListener('panelready', (e) => {
        if (e.detail.current === '#manu-view') {
          this.update();
        }
      });
    },

    update: function() {
      if (!this.navigator) {
        this.navigator = new SimpleNavigationHelper('.focusable', this.manuList);
      }

      this.manuList.focus();
    },

    loadConfig: function ut_loadConfig(obj) {
      this.config = obj[DEVICEMODEL] ? obj[DEVICEMODEL] : obj[DEVICETYPE];
      this.createList(this.config);
    },

    createList: function(config) {
      let container = this.manuList;
      let ul = document.createElement('ul');

      var createListItem = function (name, info) {
        let li = document.createElement('li');
        let p = document.createElement('p');
        p.textContent = info;
        li.setAttribute('data-name', name);
        li.appendChild(p);
        li.classList.add('focusable');
        li.tabIndex = 0;

        ul.appendChild(li);
      };

      if (config) {
        for (let i = 0, len = config.testItems.length; i < len; i++) {
          if ('true' === config.testItems[i].manuTest[0].testFlag) {
            createListItem(config.testItems[i].htmlName, config.testItems[i].itemInfo);
          }
        }
        container.appendChild(ul);
      } else {
        //xxx: Show error info
      }
    },

    openTest: function ut_openTest(name) {
      EventSender.emit('openTest', {
        testName: name,
        testMode: 'manu'
      });
    },

    handleKeydown: function ut_handleKeydown(evt) {
      if (this.hash !== viewManager.currentPanel) {
        return;
      }

      debug('handle event in manu view: ' + evt.key);
      evt.preventDefault();
      evt.stopPropagation();
      let target = evt.target;
      switch (evt.key) {
        case 'Backspace':
          viewManager.currentPanel = '#main-view';
          break;
        case 'Enter':
          if (target.dataset.name) {
            this.openTest(target.dataset.name);
          }
          break;
        default:
          break;
      }
    }
  };

  exports.ManuView = ManuView;
}(window));

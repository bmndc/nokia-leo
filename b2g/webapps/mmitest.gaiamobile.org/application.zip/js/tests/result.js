/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
/* global TestItem */
'use strict';

(function(exports) {
  const MMITESTRESULT = 'mmitest_result';

  var TestResult = new TestItem(render);

  TestResult.onInit = function() {
    this.mode = TestView.curMode;
    this.content = document.getElementById('test-result-content');
    this.content.focus();
    this.showTestResult();
  };

  TestResult.showTestResult = function() {
    asyncStorage.getItem(MMITESTRESULT, (value) => {
      let testResult = JSON.parse(value)[this.mode];
      let text = '';

      if (testResult) {
        for (let name in testResult) {
          let colorClass;
          if (testResult[name] === 'pass') {
            colorClass = 'result-pass';
          } else if (testResult[name] === 'fail') {
            colorClass = 'result-fail';
          } else {
            colorClass = 'result-notest';
          }
          text += '<p class="' + colorClass + '">'
            + name + ': ' + testResult[name] + '</p>' ;
        }

        this.content.innerHTML = text;
      }
    });
  };

  TestResult.onHandleEvent = function(evt) {
    return false;
  };

  function render() {
    return `
      <div id="title">TEST RESULT</div>
      <div id="content">
        <div id="test-result-content" tabindex="1">
        There is no test result
        </div>
      </div>`;
  }

  exports.Test = TestResult;
}(window));

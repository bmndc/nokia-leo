/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [accessories.js] = ' + s + '\n');
    }
  }

  var AccessoriesTest = new TestItem(render);

  AccessoriesTest.testIndex = 0;
  AccessoriesTest.testSteps = [
    'headset_detect',
    'headset_ear',
    'headset_mic',
    'headset_remove'
  ];

  AccessoriesTest.onInit = function() {
    this.testIndex = 0;
    this.plugFlag = false;
    this.audio = this.container.querySelector('#audio-element-id');
    this.centerText = this.container.querySelector('#centertext');

    this.acm = navigator.mozAudioChannelManager;
    if (this.acm) {
      this.acm.addEventListener('headphoneschange',
          this.onHeadsetStatusChanged.bind(this));
      this.doTest();
    } else {
      this.centerText.textContent = 'mozAudioChannelManager not supported';
    }
  };

  AccessoriesTest.onHeadsetStatusChanged = function() {
    debug('onHeadsetStatusChanged');
    if (this.acm.headphones) {
      this.centerText.textContent = 'Headset detected';
      this.plugFlag = true;
      this.testIndex = 0;
      this.passButton.disabled = '';
      this.failButton.disabled = '';
    } else {
      if (this.testSteps[this.testIndex] !== 'headset_remove') {
        this.plugFlag = false;
        this.centerText.textContent = 'Please plug in headset';
        this.passButton.disabled = 'disabled';
        this.failButton.disabled = '';
      } else {
        clearTimeout(this._timer);
        this.plugFlag = false;
        this.centerText.textContent = 'Accessories all pass';
        this.passButton.disabled = '';
        this.failButton.disabled = '';
      }
    }
  };

  AccessoriesTest.earTest = function() {
    this.audio.play();
  };

  AccessoriesTest.closeEarTest = function() {
    if (this.audio) {
      this.audio.pause();
    }
  };

  AccessoriesTest.earMicTest = function() {
    setTimeout(() => {
      this.centerText.textContent = 'headset mic test';
      EventSender.emit('nativeRequest', {message: 'headsetMicLoop'});
      setTimeout(this.timeoutCallback.bind(this), 1500);
    }, 500);
  };

  AccessoriesTest.closeMicTest = function() {
    debug('AccessoriesTest stop headset mic test.');
    EventSender.emit('nativeRequest', {message: 'resetHeadsetMicLoop'});
  };

  AccessoriesTest.timeoutCallback = function() {
    if (this.plugFlag) {
      this.passButton.disabled = '';
      this.failButton.disabled = '';
      this.passButton.style.visibility = 'visible';
      this.failButton.style.visibility = 'visible';
    } else {
      this.passButton.disabled = 'disabled';
      this.failButton.disabled = '';
      this.passButton.style.visibility = 'invisible';
      this.failButton.style.visibility = 'visible';
    }
  };

  AccessoriesTest.doTest = function() {
    debug('AudioTest.doTest');
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = 'disabled';
    switch (this.testSteps[this.testIndex]) {
      case 'headset_detect':
        debug('AccessoriesTest.doTest = headset detect');
        // Check if the headset plug in before enter test
        this.onHeadsetStatusChanged();
        break;

      case 'headset_ear':
        debug('AccessoriesTest.doTest = headset ear');
        this.centerText.textContent = 'headset test';
        this.earTest();
        this._timer = window.setTimeout(this.timeoutCallback.bind(this), 4000);
        break;

      case 'headset_mic':
        debug('AccessoriesTest.doTest = headset mic');
        this.closeEarTest();
        this.centerText.textContent = 'headset mic test';
        clearTimeout(this._timer);
        this._timer = window.setTimeout(this.timeoutCallback.bind(this), 4000);
        this.earMicTest();
        break;

      case 'headset_remove':
        debug('AccessoriesTest.doTest = headset remove');
        this.closeMicTest();
        this.centerText.innerHTML = 'Please remove headset';
        clearTimeout(this._timer);
        this._timer = window.setTimeout(this.timeoutCallback.bind(this), 4000);
        break;

      default:
        break;
    }
  };

  AccessoriesTest.onHandleEvent = function(evt) {
    if (evt.type === 'keydown') {
      switch (evt.key) {
        case 'SoftLeft':
          if (this.passButton.disabled) {
            return false;
          }

          this.testIndex++;
          if (this.testIndex < this.testSteps.length) {
            this.doTest();
            return true;
          }
          break;
        case 'SoftRight':
          if (this.failButton.disabled) {
            return false;
          }
          break;

        default:
          break;
      }
    }
    return false;
  };

  AccessoriesTest.onDeinit = function() {
    this.closeMicTest();
    this.closeEarTest();
  };

  AccessoriesTest.visibilityChange = function() {
    if (document.mozHidden) {
      this.onDeinit();
    }
  };
  
  
  function render() {
    return `
        <div id="title">Accessories</div>
        <div id="centertext">To Be Continued...</div>
        <audio id="audio-element-id" style="display: none;" loop="loop" src="../resource/112.wav"></audio>`;
  }

  exports.Test = AccessoriesTest;
}(window));

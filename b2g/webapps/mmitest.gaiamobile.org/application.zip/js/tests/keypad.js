/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
/* global TestItem */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [keypad.js] = ' + s + '\n');
    }
  }

  var KeyPadTest = new TestItem(render);

  KeyPadTest.result = {
    one: false,
    two: false,
    three: false,
    four: false,
    five: false,
    six: false,
    seven: false,
    eight: false,
    nine: false,
    star: false,
    zero: false,
    fourone: false,
    softleft: false,
    softright: false,
    arrowup: false,
    arrowdown: false,
    arrowleft: false,
    arrowright: false,
    backspace: false,
    enter: false,
    acacall: false
  };

  KeyPadTest.onHandleEvent = function (evt) {
    let keyId = '';
    evt.preventDefault();
    switch(evt.key) {
      // full key pad
      case 'w':
        keyId = 'one';
        break;
      case 'e':
        keyId = 'two';
        break;
      case 'r':
        keyId = 'three';
        break;
      case 's':
        keyId = 'four';
        break;
      case 'd':
        keyId = 'five';
        break;
      case 'f':
        keyId = 'six';
        break;
      case 'z':
        keyId = 'seven';
        break;
      case 'x':
        keyId = 'eight';
        break;
      case 'c':
        keyId = 'nine';
        break;
      case ',':
        keyId = 'zero';
        break;
      case 'a':
        keyId = 'star';
        break;
      case 'q':
        keyId = 'fourone';
        break;
      // generic
      case '1':
        keyId = 'one';
        break;
      case '2':
        keyId = 'two';
        break;
      case '3':
        keyId = 'three';
        break;
      case '4':
        keyId = 'four';
        break;
      case '5':
        keyId = 'five';
        break;
      case '6':
        keyId = 'six';
        break;
      case '7':
        keyId = 'seven';
        break;
      case '8':
        keyId = 'eight';
        break;
      case '9':
        keyId = 'nine';
        break;
      case '0':
        keyId = 'zero';
        break;
      case '*':
        keyId = 'star';
        break;
      case '#':
        keyId = 'fourone';
        break;
      case 'SoftLeft':
        keyId = 'softleft';
        break;
      case 'SoftRight':
        keyId = 'softright';
        this.failButton.disabled = '';
        break;
      case 'ArrowUp':
        keyId = 'arrowup';
        break;
      case 'ArrowDown':
        keyId = 'arrowdown';
        break;
      case 'ArrowLeft':
        keyId = 'arrowleft';
        break;
      case 'ArrowRight':
        keyId = 'arrowright';
        break;
      case 'Backspace':
        keyId = 'backspace';
        break;
      case 'Notification':
        keyId = 'message';
        break;
      case 'VolumeUp':
        keyId = 'volumeup';
        break;
      case 'VolumeDown':
        keyId = 'volumedown';
        break;
      case 'Enter':
        keyId = 'enter';
        break;
      case 'Call':
        keyId = 'acacall';
        break;
      case 'LaunchWebBrowser':
        keyId = 'browser';
        break;
      case 'Camera':
        keyId = 'camera';
        break;
      case 'EndCall':
        keyId = 'power';
        break;
      case 'Flip':
        keyId = 'clam';
        break;
    }

    let rskResult = this.result['softright'];
    if (keyId) {
      this.container.querySelector('#' + keyId).style.color = 'yellow';
      this.result[keyId] = true;
    }
    this.checkIfAllDone();
    return !((evt.key === 'SoftRight' || evt.key === 'SoftLeft') && rskResult);
  };

  KeyPadTest.checkIfAllDone = function() {
    var allDone = true;
    for (var i in KeyPadTest.result) {
      if (!KeyPadTest.result[i]) {
        allDone = false;
        break;
      }
    }
    if (allDone) {
      this.passButton.disabled = '';
      this.failButton.disabled = '';
    }
  };

  KeyPadTest.showClam = function() {
    navigator.getFlipManager && navigator.getFlipManager().then((fm) => {
      this._flipManager = fm;
      this._flipManager.addEventListener('flipchange', () => {
        document.getElementById('clam').style.color = 'yellow';
        this.result['clam'] = true;
        this.checkIfAllDone();
      });
    });
  };

  KeyPadTest.showBrowserKey = function() {
    navigator.hasFeature('device.capability.qwerty').then((isQwerty) => {
      if (isQwerty) {
        this.result['browser'] = false;
        document.getElementById('browser').classList.remove('hidden');
      }
    });
  };

  KeyPadTest.onInit = function() {
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = 'disabled';
    this.showClam();
    this.showBrowserKey();
  };

  KeyPadTest.onDeinit = function() {
  };

  function render() {
    return `
        <div id="title">Keypad</div>
        <div id="content">
          <label id="one" >1</label>
          <label id="two" >2</label>
          <label id="three" >3</label>
          <label id="four" >4</label>
          <label id="five" >5</label>
          <label id="six">6</label>
          <label id="seven" >7</label>
          <label id="eight">8</label>
          <label id="nine">9</label>
          <label id="star" >*</label>
          <label id="zero">0</label>
          <label id="fourone">#</label>
          <label id="softleft">SoftLeft</label>
          <label id="softright">SoftRight</label>
          <label id="arrowup">Up</label>
          <label id="arrowdown">Down</label>
          <label id="arrowleft">Left</label>
          <label id="arrowright">Right</label>
          <label id="backspace">Back</label>
          <label id="message" hidden>Message</label>
          <label id="volumeup" hidden>VolUp</label>
          <label id="volumedown" hidden>VolDown</label>
          <label id="enter">Enter</label>
          <label id="acacall">Call</label>
          <label id="browser" class="hidden">Browser</label>
          <label id="camera" hidden>Camera</label>
          <label id="power" hidden>Power</label>
          <label id="clam" hidden>CLAM</label>
        </div>`;
  }

  exports.Test = KeyPadTest;
}(window));

/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */

'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [vibrate.js] = ' + s + '\n');
    }
  }

  var VibrateTest = new TestItem(render);

  VibrateTest._vibrateInterval = null;

  VibrateTest.timeOutCallback = function() {
    this.centerText.textContent = 'Test finished.';
    this.passButton.disabled = '';
    this.failButton.disabled = '';
  };

  VibrateTest.startTest = function() {
    debug('Vibrate.startTest');
    this.centerText.textContent = 'Is vibrator on?';
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = 'disabled';

    this._vibrateInterval = setInterval(() => {
      navigator.vibrate(VIBRATE_DURATION);
      this.times += 1;

      if (this.times >= VIBRATE_TIMES && VIBRATE_TIMES !== 0) {
        clearInterval(this._vibrateInterval);
        this._vibrateInterval = null;
      }
    }, VIBRATE_DURATION + VIBRATE_REST);

    if ('vibrate' in navigator) {
      navigator.vibrate(VIBRATE_DURATION);
      this.times = 1;
    }

    setTimeout(this.timeOutCallback.bind(this), 2000);
  };

  VibrateTest.onInit = function() {
    debug('Vibrate.onInit');
    this.centerText = this.container.querySelector('#centertext');

    this.startTest();
  };


  VibrateTest.onDeinit = function(){
    if (this._vibrateInterval) {
      clearInterval(this._vibrateInterval);
      this._vibrateInterval = null;
    }
  };

  function render() {
    return `
        <div id="title">VIBRATOR</div>
        <div id="centertext"></div>`;
  }

  exports.Test = VibrateTest;
}(window));

/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [aov.js] = ' + s + '\n');
    }
  }

  var AOVTest = new TestItem(render);

  AOVTest.onInit = function() {
    debug('onInit');
    this.resultText = this.container.querySelector('#centertext');
    this.soundtrigger = navigator.soundTriggerManager;
    let modules = this.soundtrigger.getSupportList();
    // modules read only, cannot add other keywords.
    this.soundtrigger.set(modules[0]);

    this.soundtrigger.onstatechange = () => {
      this.resultText.textContent = 'Start detecting, please say "Hello Jio".';
    };
    this.soundtrigger.onrecognitionresult = () => {
      debug('Keyword recognition detected');
      this.resultText.textContent = 'Keyword detected';
      this.soundtrigger.onstatechange = null;
      this.passButton.disabled = '';
    };

    this.passButton.disabled = 'disabled';

    this.startTest();
  };

  AOVTest.startTest = function() {
    debug('start detecting keyword');
    this.soundtrigger.start(['Hello Jio']);
  };

  AOVTest.onDeinit = function() {
    this.soundtrigger.stop();
    this.soundtrigger = null;
  };

  AOVTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    return false;
  };

  function render() {
    return `
        <div id="title">Always On Voice</div>
        <div id="centertext">To Be Continued...</div>`;
  }

  exports.Test = AOVTest;
}(window));

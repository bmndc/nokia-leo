/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [audio.js] = ' + s + '\n');
    }
  }

  var AudioTest = new TestItem(render);

  AudioTest.isAudioPlaying = false;
  AudioTest.isAudioLoopProcessing = false;

  AudioTest.testIndex = 0;
  AudioTest.testSteps = [
    'receiver',
    'speaker',
    'mic',
    //'sub-mic'  // no sub mic
  ];

  AudioTest.setDefaultVolume = function() {
    // set to default volume to make sure we can test
    let settings = window.navigator.mozSettings;
    if (settings) {
      settings.createLock().set({'audio.volume.telephony': 5});
      settings.createLock().set({'audio.volume.content': 15});
    }
  };

  AudioTest.resumeVolume = function() {
    let settings = window.navigator.mozSettings;
    if (settings) {
      settings.createLock().set({'audio.volume.content': 8});
    }
  };

  AudioTest.checkStartAudio = function(speakerEnabled) {
    debug('AudioTest.checkStartAudio');
    this.checkStopAudioLoop();
    navigator.mozTelephony.speakerEnabled = speakerEnabled;

    if (!this.isAudioPlaying) {
      if (navigator.engmodeExtension) {
        navigator.engmodeExtension.startForceInCall();
      }
      debug('AudioTest: startForceInCall');
      try {
        this.audio.play();
        this.isAudioPlaying = true;
      } catch (e) {
        debug(e);
      }
    }
  };

  AudioTest.checkStopAudio = function() {
    debug('AudioTest.checkStopAudio');
    if (this.isAudioPlaying) {
      this.audio.pause();
      this.audio.removeAttribute('src');
      if (navigator.engmodeExtension) {
        navigator.engmodeExtension.stopForceInCall();
      }
      debug('AudioTest: stopForceInCall');
      this.isAudioPlaying = false;
    }
  };

  AudioTest.checkStartAudioLoop = function(type) {
    debug('AudioTest.checkStartAudioLoop');
    this.checkStopAudio();
    this.checkStopAudioLoop();
    this.isAudioLoopProcessing = true;
    window.setTimeout(function() {
      debug('AudioTest.checkStartAudioLoop.setTimeout');
      if (navigator.engmodeExtension) {
        navigator.engmodeExtension.startAudioLoopTest(type);
      }
    }, 3000);
  };

  AudioTest.checkStopAudioLoop = function() {
    debug('AudioTest.checkStopAudioLoop');
    if (this.isAudioLoopProcessing) {
      if (navigator.engmodeExtension) {
        navigator.engmodeExtension.startAudioLoopTest('stop-mic');
        navigator.engmodeExtension.startAudioLoopTest('stop-sub-mic');
        navigator.engmodeExtension.stopAudioLoopTest();
      }
      this.isAudioLoopProcessing = false;
    }
  };

  AudioTest.startMicTest = function() {
    EventSender.emit('nativeRequest', {message: 'micLoop'});
  };

  AudioTest.stopMicTest = function() {
    EventSender.emit('nativeRequest', {message: 'resetMicLoop'});
  };

  AudioTest.doTest = function() {
    debug('AudioTest.doTest');
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = 'disabled';
    switch (this.testSteps[this.testIndex]) {
      case 'receiver':
        debug('AudioTest.doTest = receiver');
        this._timer = window.setTimeout(this.timeoutCallback.bind(this), 4000);
        this.centerText.innerHTML = 'receiver test';
        this.checkStartAudio(false); //speakerEnabled false.
        break;

      case 'speaker':
        this._timer = window.setTimeout(this.timeoutCallback.bind(this), 4000);
        debug('AudioTest.doTest = speaker');
        this.centerText.innerHTML = 'speaker test';
        this.checkStartAudio(true); //speakerEnabled true.
        break;

      case 'mic':
        debug('AudioTest.doTest = mic');
        this.centerText.innerHTML = 'loop from MIC test';
        clearTimeout(this._timer);
        this._timer = window.setTimeout(this.timeoutCallback.bind(this), 5500);
        this.startMicTest();
        break;

      case 'sub-mic':
        debug('AudioTest.doTest = sub-mic');
        this.centerText.innerHTML = 'loop from Sub MIC test';
        clearTimeout(this._timer);
        this._timer = window.setTimeout(this.timeoutCallback.bind(this), 5500);
        this.checkStartAudioLoop('sub-mic');
        break;

      default:
        break;
    }
  };

  AudioTest.timeoutCallback = function() {
    this.passButton.disabled = '';
    this.failButton.disabled = '';
    this.passButton.style.visibility = 'visible';
    this.failButton.style.visibility = 'visible';
  };

  AudioTest.visibilityChange = function() {
    debug('AudioTest.visibilityChange');
    if (document.mozHidden) {
      debug('AudioTest: visibilityChange-hide');
      this.checkStopAudio();
      this.checkStopAudioLoop();
      this.stopMicTest();
    } else {
      debug('AudioTest: visibilityChange-visible');
      this.doTest();
    }
  };

  AudioTest.onInit = function() {
    debug('AudioTest.onInit');
    this.audio = this.container.querySelector('#audio-element-id');
    this.centerText = this.container.querySelector('#centertext');

    if (!navigator.engmodeExtension) {
      this.centerText.innerHTML = 'Device not support engmodeExtension';
      return;
    }

    this.setDefaultVolume();
    this.doTest();
  };

  AudioTest.onDeinit = function() {
    debug('AudioTest.onDeinit');
    this.stopMicTest();
    this.checkStopAudio();
    this.checkStopAudioLoop();
    this.resumeVolume();
  };

  AudioTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    debug('AudioTest.onHandleEvent');
    switch (evt.type) {
      case 'keydown':
        switch (evt.key) {
          case 'SoftLeft':
            if (this.passButton.disabled) {
              return;
            }
            this.handleMicOrSubMic();
            this.testIndex++;
            if (this.testIndex < this.testSteps.length) {
              this.doTest();
              return true;
            }
            break;
          default:
            break;
        }
        break;
      default:
        break;
    }
    return false;
  };

  AudioTest.handleMicOrSubMic = function() {
    let currentTestItem = this.testSteps[this.testIndex];
    if (currentTestItem === 'mic' || currentTestItem === 'sub-mic') {
      this.stopMicTest();
      this.checkStopAudio();
      this.checkStopAudioLoop();
    }
  };

  function render() {
    return `
        <div id="title">AUDIO</div>
        <div id="centertext"></div>
        <audio id="audio-element-id" loop="loop" src="../resource/112.wav" hidden></audio>`;
  }

  exports.Test = AudioTest;
}(window));


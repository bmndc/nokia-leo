/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  var RtcTest = new TestItem(render);

  RtcTest.timeoutCallback = function() {
    this.passButton.disabled = '';
    this.failButton.disabled = '';
    this.passButton.style.visibility = 'visible';
    this.failButton.style.visibility = 'visible';
  };

  RtcTest.updateTime = function() {
    let now = new Date();
    this.time.textContent = now.toTimeString();
  };

  RtcTest.onInit = function() {
    this.time = document.getElementById('rtc-time');
    this.passButton.style.visibility = 'hidden';
    this.failButton.style.visibility = 'hidden';
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = 'disabled';

    this.updateTime();
    this._intervalId = window.setInterval(this.updateTime.bind(this), 1000);
    this._timer = window.setTimeout(this.timeoutCallback.bind(this), 500);
  };

  RtcTest.onDeinit = function() {
    clearInterval(this._intervalId);
    clearTimeout(this._timer);
  };

  RtcTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    return false;
  };

  function render() {
    return `
        <div class="rtc-container">
          <div id="rtc-time">00:00:00</div>
        </div>`;
  }
  exports.Test = RtcTest;
}(window));


/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [camera.js] = ' + s + '\n');
    }
  }

  var CameraTest = new TestItem(render);

  var WHICH_CAMERA =  0; // 0 is back camera and 1 is front camera.

  let beInited = false;

  CameraTest.testFlag = true;
  CameraTest._cameras = null;
  CameraTest._cameraObj = null;

  CameraTest.setSource = function() {
    this.viewfinder.mozSrcObject = null;

    this._cameras = navigator.mozCameras.getListOfCameras();
    debug('cameras: ' + this._cameras.toString() + '-- index: ' + WHICH_CAMERA);

    navigator.mozCameras.getCamera(this._cameras[WHICH_CAMERA])
      .then(this.gotCamera.bind(this), this.gotCameraError.bind(this));};

  CameraTest.startPreview = function() {
    this.viewfinder.play();
    this.setSource();
  };

  CameraTest.stopPreview = function() {
    this.viewfinder.pause();
    this.viewfinder.mozSrcObject = null;
  };

  CameraTest.resumePreview = function() {
    this._cameraObj.resumePreview();
  };

  CameraTest.gotPreviewScreen = function(stream) {
    this.viewfinder.mozSrcObject = stream;
    this.viewfinder.play();
  };

  CameraTest.gotCamera = function(params) {
    var camera = this._cameraObj = params.camera;
    var config = {
      pictureSize: this.getProperPictureSize(camera.capabilities.pictureSizes)
    };
    camera.setConfiguration(config);

    var viewfinder = this.viewfinder;
    var style = viewfinder.style;

    var transform = '';
    if (WHICH_CAMERA === 1) {
      transform += ' scale(-1, 1)';
    }
    var angle = camera.sensorAngle;
    transform += 'rotate(' + angle + 'deg)';
    debug('transform ===================== ' + transform);

    style.MozTransform = transform;

    var width = document.body.clientWidth;
    var height = document.body.clientHeight;
    if (angle % 180 === 0) {
      style.top = 0;
      style.left = 0;
      style.width = width + 'px';
      style.height = height + 'px';
    } else {
      style.top = ((height / 2) - (width / 2)) + 'px';
      style.left = -((height / 2) - (width / 2)) + 'px';
      style.width = height + 'px';
      style.height = width + 'px';
    }
    viewfinder.mozSrcObject = camera;
    viewfinder.play();
  };

  CameraTest.getProperPictureSize = function (sizes) {
    var delta, ratio, gradual = 1, index = 0;
    var screenRatio = document.body.clientWidth/ document.body.clientHeight;

    // get a picture size that's the largest and mostly eaqual to screen ratio
    for (var i = 0, len = sizes.length; i < len; i++) {
      ratio = sizes[i].height / sizes[i].width;
      if (ratio > 1) {
        ratio = 1 / ratio;
      }
      delta = Math.abs(screenRatio - ratio);
      if (delta < gradual || (delta === gradual &&
        sizes[index].height * sizes[index].width < sizes[i].height * sizes[i].width)) {
        gradual = delta;
        index = i;
      }
    }
    return sizes[index];
  };

  CameraTest.gotCameraError = function() {
    this.centerText.innerHTML = 'got camera error';
    this.failButton.disabled = '';
    this.testFlag = false;
  };

  CameraTest.visibilityChange = function() {
    if (document.mozHidden) {
      this.stopPreview();
    } else {
      this.startPreview();
    }

    var self = this;
    if (this._cameraObj) {
      this._cameraObj.release().then(function() {
        self._cameraObj = null;
      }, function() {
        debug('fail to release camera');
      });
    }
  };

  CameraTest.startInit = function() {
    if (!navigator.mozCameras) {
      this.centerText.innerHTML = 'mozCameras does not exist';
      return;
    }

    if (beInited) {
      return;
    }
    beInited = true;

    this.setSource();

    this.passButton.disabled = 'disabled';
    this.failButton.disabled = 'disabled';
    var self = this;
    setTimeout(function() {
      if (self.testFlag) {
        self.passButton.disabled = '';
      }
      self.failButton.disabled = '';
    }, 3000);
  };

  //the following are inherit functions
  CameraTest.onInit = function() {
    this.viewfinder = this.container.querySelector('#viewfinder');
    this.centerText = this.container.querySelector('#centertext');

    this.startInit();
  };

  CameraTest.onDeinit = function() {
    this.stopPreview();

    if (this._cameraObj) {
      this._cameraObj.release().then(() => {
        this._cameraObj = null;
      }, function() {
        debug('fail to release camera');
      });
    }
  };

  CameraTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    return false;
  };

  function render() {
    return `
        <div id="camera_back"></div>
        <div id="title" style="z-index:26;">Camera</div>
        <video id="viewfinder" autoplay></video>
        <div id="centertext"></div>`;
  }
  exports.Test = CameraTest;
}(window));

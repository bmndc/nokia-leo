/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [call.js] = ' + s + '\n');
    }
  }

  var DialerTest = new TestItem(render);

  DialerTest._call = null;

  DialerTest.onInit = function() {
    this.centerText = this.container.querySelector('#centertext');

    this.centerText.innerHTML =
      'OUTGOING CALL' + '<br />' + 'Press "Dial" to start';
  };

  DialerTest.doTest = function() {
    let tel = navigator.mozTelephony;
    if (tel) {
      tel.dialEmergency('112', false).then(function() {
        // do nothing
      });
    }
  };

  DialerTest.onDeinit = function() {
  };

  DialerTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    if (evt.key === 'ArrowUp') {
      this.doTest();
    }
    return false;
  };

  function render() {
    return `
      <div id="title">CALL</div>
      <div id="centertext"></div>
      <button type="button" id="dialButton">Dial</button>`;
  }

  exports.Test = DialerTest;
}(window));

/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [battery.js] = ' + s + '\n');
    }
  }

  var BatteryTest = new TestItem(render);

  BatteryTest.onInit = function() {
    window.addEventListener('nativeResponse', this.handleNativeResponse.bind(this));

    this.tmpText = this.container.querySelector('#temp_current');
    this.contentText = this.container.querySelector('#content_current');
    this.voltageText = this.container.querySelector('#battery_voltage');
    this.presentText = this.container.querySelector('#battery_present');
    this.passButton.disabled = 'disabled';

    this.startTest();
  };

  BatteryTest.startTest = function() {
    EventSender.emit('nativeRequest', {message: 'getBatteryInfo'});
  };

  BatteryTest.handleNativeResponse = function(event) {
    if (event.type === 'nativeResponse' &&
      event.detail.message === 'getBatteryInfo') {
      this.update(event.detail.response);
    }
  };

  BatteryTest.update = function(info) {
    this.tmpText.textContent =
        info.temp ? 'Now: ' + info.temp + '°C' : 'unknown';
    this.contentText.textContent =
        info.content ? 'Now: ' + info.content + '%' : 'unknown';
    this.voltageText.textContent =
        info.voltage ? 'Voltage now: ' + info.voltage + 'V' : 'unknown';
    this.presentText.textContent = 'Battery present is: ' + info.present;

    this.passButton.disabled = (parseInt(info.present) === 1) ? '' : 'disabled';
  };

  BatteryTest.onDeinit = function() {
    window.removeEventListener('nativeResponse', this.handleNativeResponse);
  };

  BatteryTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    return false;
  };

  function render() {
    return `
        <div id="title">Battery</div>
        <div class="test-container">
          <p>Battery temperature need 20~50°C</p>
          <p id="temp_current">Now:</p>
          <p>Battery content need 30~80%</p>
          <p id="content_current">Now:</p>
          <p id="battery_voltage">Voltage now:</p>
          <p id="battery_present">Battery Present is:</p>
        </div>`;
  }

  exports.Test = BatteryTest;
}(window));

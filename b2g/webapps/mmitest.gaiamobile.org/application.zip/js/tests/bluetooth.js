/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [bluetooth.js] = ' + s + '\n');
    }
  }

  const DISCOVER_TIMER_DURATION = 30000;

  var BtTest = new TestItem(render);

  BtTest.discoverTimeout = null;

  BtTest.scan = function() {
    this.discoverTimeout = null;
    this.foundDevice = false;
    this.found = 0;

    this.btContainer.innerHTML = '';
    this.startDiscovery();
  };

  BtTest.discoverTimeoutCallback = function() {
    this.discoverTimeout = null;
    this.stopDiscovery();
  };

  BtTest.startDiscovery = function() {
    this.rescanBt.style.visibility = 'hidden';
    this.btContainer.innerHTML = 'searching...';

    this.passButton.disabled = 'disabled';
    this.failButton.disabled = 'disabled';

    if (!this.defaultAdapter) {
      return Promise.reject('default adapter is not existed!!');
    }

    return this.defaultAdapter.startDiscovery().then((handle) => {
      if (!this.discoverTimeout) {
        this.discoverTimeout = setTimeout(
          this.discoverTimeoutCallback.bind(this), DISCOVER_TIMER_DURATION);
      }
      handle.ondevicefound = this.onDeviceFound.bind(this);
    }, (reason) => {
      window.setTimeout(() => {
        this.failButton.disabled = '';
        this.rescanBt.style.visibility = 'visible';
      }, 3000);
      this.stopDiscovery();
      return Promise.reject(reason);
    });
  };

  BtTest.stopDiscovery = function() {
    if (!this.defaultAdapter) {
      return Promise.reject('default adapter is not existed!!');
    }

    if (this.discoverTimeout) {
      clearTimeout(this.discoverTimeout);
    }
    this.discoverTimeout = null;

    this.rescanBt.style.visibility = 'visible';
    this.failButton.disabled = '';

    return this.defaultAdapter.stopDiscovery().then(() => {
      if (!this.foundDevice) {
        this.btContainer.innerHTML = 'No Device found';
      }
    }, (reason) => {
      debug('stopDiscovery(): stopDiscovery failed: reason = ' + reason);
      return Promise.reject(reason);
    });
  };

  BtTest.onDeviceFound = function(evt) {
    this.foundDevice = true;
    this.found ++;

    if (this.found === 1) {
      this.btContainer.innerHTML = '';
    }

    // Only show three bt devices.
    if (this.found > 2) {
      debug('More than 2 devices had been found，change buttons state');
      this.passButton.disabled = '';

      // when found three devices, just stop.
      this.stopDiscovery();
    }

    this.createBluetoothList(evt.device.name, evt.device.address);
  };

  BtTest.createBluetoothList = function(name, address) {
    let div = document.createElement('div');
    let nameEl = document.createElement('span');
    let addressEl = document.createElement('span');

    if (!name) {
      name = 'UNKNOWN';
    }

    nameEl.textContent = name;
    addressEl.textContent = address;

    div.appendChild(nameEl);
    div.appendChild(addressEl);

    this.btContainer.appendChild(div);
  };

  BtTest.onInit = function() {
    this.bluetooth = navigator.mozBluetooth;

    this.rescanBt = this.container.querySelector('#retestButton');
    this.btContainer = this.container.querySelector('#bt-content');

    this.rescanBt.style.visibility = 'hidden';
    this.btContainer.innerHTML = '';
    this.passButton.disabled = 'disabled';
    this.failButton.disabled = '';

    debug('default adapter: ' + this.bluetooth.defaultAdapter);
    if (this.bluetooth.defaultAdapter) {
      this.defaultAdapter = this.bluetooth.defaultAdapter;
      this.startTest();
    }

    this.bluetooth.addEventListener('attributechanged', this.handleAttributeChanged.bind(this));
  };

  BtTest.startTest = function() {
    if (!this.defaultAdapter) {
      return;
    }
    if (this.defaultAdapter.state === 'enabled') {
      this.scan();
    } else {
      this.btContainer.innerHTML = 'Enabling Bluetooth...';
      this.defaultAdapter.enable().then(() => {
        this.scan();
      }, (reason) => {
        debug('setEnabled(): set enable failed: reason = ' + reason);
      });
    }
  };

  BtTest.onDeinit = function() {
    // this.bluetooth.removeEventListener('attributechanged', this.handleAttributeChanged);
    // we don't set bluetooth settings back when quit bt test,
    // to avoid a race condition that may cause fail to test bt
    // net time enter the menu.
  };

  BtTest.handleAttributeChanged = function(evt) {
    for (let i in evt.attrs) {
      switch (evt.attrs[i]) {
        case 'defaultAdapter':
          // Default adapter attribute change.
          // Usually, it means that we reach new default adapter.
          this.defaultAdapter = this.bluetooth.defaultAdapter;
          this.startTest();
          break;
        default:
          break;
      }
    }
  };

  BtTest.onHandleEvent = function(evt) {
    evt.preventDefault();
    switch (evt.type) {
      case 'keydown':
        if (evt.key === 'ArrowUp' && this.rescanBt.style.visibility !== 'hidden') {
          if (this.defaultAdapter && !this.defaultAdapter.discovering) {
            this.scan();
          }
        }
        break;
    }
    return false;
  };

  function render() {
    return `
        <div id="title">Bluetooth</div>
        <div id="bt-content">To Be Continued...</div>
        <button type="button" id="retestButton">Scan Retry</button>`;
  }

  exports.Test = BtTest;
}(window));

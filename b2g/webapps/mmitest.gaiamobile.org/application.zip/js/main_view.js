/* © 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved.
 * This file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */
'use strict';

(function(exports) {
  function debug(s) {
    if (DEBUG) {
      dump('<mmitest> ------: [main_view.js] = ' + s + '\n');
    }
  }

  var MainView = {
    hash: '#main-view',

    init: function() {
      this.view = document.getElementById('main-view');
      this.autoButton = this.view.querySelector('#autoButton');
      this.manuButton = this.view.querySelector('#manuButton');

      this.getVersions();

      window.addEventListener('keydown', this.handleKeydown.bind(this));
      window.addEventListener('panelready', (e) => {
        if (e.detail.current === '#main-view') {
          this.update();
        }
      });
    },

    update: function() {
      viewManager.currentPanel = '#main-view';

      setTimeout(() => {
        this.autoButton.disabled = '';
        this.manuButton.disabled = '';
        this.autoButton.addEventListener('click', this);
        this.manuButton.addEventListener('click', this);
      }, 2000);
    },

    getVersions: function() {
      let formatTime = function (buildId) {
        let dateTimeStr = '';
        let dateStr = buildId.substring(0, 8);
        dateTimeStr = dateStr.replace(/^(\d{4})(\d{2})(\d{2})$/, '$1-$2-$3');

        let timeStr = buildId.substring(8);
        dateTimeStr =
          dateTimeStr + ' ' + timeStr.replace(/^(\d{2})(\d{2})(\d{2})$/, '$1:$2:$3');

        return dateTimeStr;
      };

      let _lock = navigator.mozSettings.createLock();
      const VERSION_KEY = 'deviceinfo.build_number';
      const BUILD_TIME_KEY = 'deviceinfo.platform_build_id';

      Promise.all([
        _lock.get(VERSION_KEY),
        _lock.get(BUILD_TIME_KEY)
      ]).then((results) => {
        document.getElementById('version').textContent =
          results[0][VERSION_KEY];
        document.getElementById('build-time').textContent =
          formatTime(results[1][BUILD_TIME_KEY]);
      }).catch((error) => {
        console.log('Failed to get device info error: ' + error.name);
      });
    },

    handleEvent: function(evt) {
      switch (evt.type) {
        case 'click':
          switch (evt.target) {
            case this.autoButton:
              viewManager.currentPanel = '#auto-view';
              AutoView.state = 'start';
              break;

            case this.manuButton:
              viewManager.currentPanel = '#manu-view';
              break;
          }
          break;
      }
    },

    handleKeydown: function(event) {
      if (this.hash !== viewManager.currentPanel) {
        return;
      }

      debug('handle event in main view: ' + event.key);
      event.preventDefault();
      event.stopPropagation();
      switch (event.key){
        case 'SoftLeft':
          this.autoButton.click();
          break;
        case 'SoftRight':
          this.manuButton.click();
          break;
        case 'Backspace':
        case 'EndCall':
          window.close();
          break;
      }
    }
  };

  exports.MainView = MainView;
}(window));

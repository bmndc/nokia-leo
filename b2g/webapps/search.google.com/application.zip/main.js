'use strict';

function getClientID() {
  return new Promise((resolve, reject) => {
    var defaultID = 'kaios';
    var lock = navigator.mozSettings.createLock();
    var setting = lock.get('google.client_id');

    setting.onsuccess = function () {
      var clientID = setting.result['google.client_id'] || defaultID;
      console.log('google.client_id: ' + clientID);
      resolve(clientID);
    }

    setting.onerror = function () {
      console.warn('An error occured: ' + setting.error);
      reject(defaultID);
    }
  });
}

function openSearchPage(clientID) {
  // Opens the site in a blank browser frame, and close ourselves.
  window.setTimeout(() => {
    var url = 'https://www.google.com/search?client=' + clientID;
    window.open(url, '_blank');
    window.setTimeout(() => {
      window.close();
    }, 500);
  }, 1000);
}

getClientID().then((clientID) => {
  openSearchPage(clientID);
});

/* (c) 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved. This
 * file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */

'use strict';

$('menuItem-setting').addEventListener('click', () => {
  emSettings.init();
});

/* FIH modify network select type LTE/gsm for GCF test. begin */
$('menuItem-networkType').addEventListener('click', () => {
  emSettings.initEx();
});
/* FIH modify network select type LTE/gsm for GCF test. end */

var _mobileConnections;
var _mobileConnection;
var _settings;
var _self;

/* FIH modify network select type LTE/gsm for GCF test. begin */
var NETWORK_GSM_MAP = {
	'lte/wcdma/gsm': 'operator-networkType-prefer4G',
	'lte/wcdma': 'operator-networkType-prefer4G3G',
	'lte/gsm': 'operator-networkType-prefer4G2G',
	'wcdma/gsm': 'operator-networkType-prefer3G2G',
	'gsm': 'operator-networkType-2G',
	'wcdma': 'operator-networkType-3G',
	'lte': 'operator-networkType-4G',
	'wcdma/gsm-auto': 'operator-networkType-auto-gsmcdma'
};
/* FIH modify network select type LTE/gsm for GCF test. end */

var NETWORK_CDMA_MAP = {
	'cdma/evdo': 'operator-networkType-auto-evdocdma',
	'cdma': 'operator-networkType-CDMA',
	'evdo': 'operator-networkType-EVDO'
};

var NETWORK_DUALSTACK_MAP = {
	'wcdma/gsm': 'operator-networkType-preferWCDMA',
	'gsm': 'operator-networkType-GSM',
	'wcdma': 'operator-networkType-WCDMA',
	'wcdma/gsm-auto': 'operator-networkType-auto-gsmcdma',
	'cdma/evdo':'operator-networkType-auto-evdocdma',
	'cdma':'operator-networkType-CDMA',
	'evdo': 'operator-networkType-EVDO',
	'wcdma/gsm/cdma/evdo': 'operator-networkType-auto-globe'
};

var emSettings = {

  init: function init() {
    _self = this;
    _mobileConnections = navigator.mozMobileConnections;
    _settings = navigator.mozSettings;

    _mobileConnection = _mobileConnections[
      DsdsSettings.getIccCardIndexForCellAndDataSettings()
    ];

    if (_mobileConnection) {
      _self.initCallWaitingItem();
    }

    _self.initDebuggerItem();
    _self.initUsbStorageItem();
  },

/* FIH modify network select type LTE/gsm for GCF test. begin */
  initEx: function initEx() {
    _self = this;
    _mobileConnections = navigator.mozMobileConnections;
    _settings = navigator.mozSettings;

    _mobileConnection = _mobileConnections[
      DsdsSettings.getIccCardIndexForCellAndDataSettings()
    ];
	_self.addNetworkTypeListeners();
	Log('testbox-em_Settings: initEx()');
  },
/* FIH modify network select type LTE/gsm for GCF test. end */

  addListeners: function addListeners() {
    $('network-select').addEventListener('change', _self.selectNetwork.bind(_self), false);
    $('menuItem-networkSelect').onclick = function() {
      getSupportedNetworkInfo(_mobileConnection, function(result) {
	Log('testbox-em_Settings: getSupportedNetworkInfo support networkTypes:' + result.networkTypes);
        if (result.networkTypes) {
          _self.updateNetworkTypeSelector(result.networkTypes,
            result.gsm,
            result.cdma);
        }
      });
    };
  },

/* FIH modify network select type LTE/gsm for GCF test. begin */
  addNetworkTypeListeners: function addNetworkTypeListeners() {
    $('fihnetwork-select').addEventListener('change', _self.selectNetworkEx.bind(_self), false);
    getSupportedNetworkInfo(_mobileConnection, function(result) {
	  Log('testbox-em_Settings: getSupportedNetworkInfo support networkTypes:' + result.networkTypes);
      if (result.networkTypes) {
        _self.updateNetworkTypeSelectorEx(result.networkTypes,
          result.gsm,
          result.cdma);
      }
    });
  },
/* FIH modify network select type LTE/gsm for GCF test. end */

  initCallWaitingItem: function() {
    let item = $('callWaiting-input');
    // Set Call Waiting status default value as false.
    item.checked = false;

    _mobileConnection.getCallWaitingOption().then((result) => {
      item.checked = result;
    }, (error) => {
      debug('Failed to get the Call Waiting status: ' + error.name);
    });

    item.addEventListener('keydown', (evt) => {
      if ('Enter' === evt.key) {
        item.disabled = true;
        let state = item.checked;
        _mobileConnection.setCallWaitingOption(!state).then(() => {
          item.checked = !state;
          item.disabled = false;
        }).catch((error) => {
          item.checked = state;
          item.disabled = false;
          debug('Failed to set the Call Waiting status: ' + error.name);
        });
      }
    });
  },

  initDebuggerItem: function() {
    let item = $('debuging-input');
    // Set item default value as false
    item.checked = false;

    navigator.mozSettings.createLock().get(item.name).then((result) => {
      item.checked = ('adb-devtools' === result[item.name]);
    }, (error) => {
      debug('Failed to get the ' + item.name + ' value: ' + error.name);
    });

    item.addEventListener('keydown', (evt) => {
      if ('Enter' === evt.key) {
        item.disabled = true;
        let state = item.checked;
        let settings = {};
        settings[item.name] = state ? 'adb-only' : 'adb-devtools';
        navigator.mozSettings.createLock().set(settings).then(() => {
          item.checked = !state;
          item.disabled = false;
        }).catch((error) => {
          item.checked = state;
          item.disabled = false;
          debug('Failed to set the ' + item.name + ' value:' + error.name);
        });
      }
    });
  },

  initUsbStorageItem: function() {
    let item = $('sdcard-input');
    // Set item default value as false
    item.checked = false;

    navigator.mozSettings.createLock().get(item.name).then((result) => {
      item.checked = result[item.name];
    }, (error) => {
      debug('Failed to get the ' + item.name + ' value: ' + error.name);
    });

    item.addEventListener('keydown', (evt) => {
      if ('Enter' === evt.key) {
        item.disabled = true;
        let state = item.checked;
        let settings = {};
        settings[item.name] = !state;
        navigator.mozSettings.createLock().set(settings).then(() => {
          item.checked = !state;
          item.disabled = false;
        }).catch((error) => {
          item.checked = state;
          item.disabled = false;
          debug('Failed to set the ' + item.name + ' value:' + error.name);
        });
      }
    });
  },

/* FIH modify network select type LTE/gsm for GCF test. begin */
  updateNetworkTypeSelectorEx: function updateNetworkTypeSelectorEx(networkTypes, gsm, cdma) {
    Log('testbox-em_Settings : gsm = ' + gsm + '  cdma = ' + cdma + '\n');
    var request = _mobileConnection.getPreferredNetworkType();
    request.onsuccess = function onSuccessHandler() {
      var networkType = request.result;
      Log('testbox-em_Settings :  current networkType ' + networkType + '\n');
      if (networkType) {
        var selector = $('fihnetwork-select');
        // Clean up all option before updating again.
        while (selector.hasChildNodes()) {
          selector.removeChild(selector.lastChild);
        }
        networkTypes.forEach(function(type) {
          Log('testbox-em_Settings : networkTypes ' + type);
          var option = document.createElement('option');
          option.value = type;
          option.selected = (networkType === type);
          // show user friendly network mode names
          if (gsm && cdma) {
            if (type in NETWORK_DUALSTACK_MAP) {
              //localize(option, NETWORK_DUALSTACK_MAP[type]);
              option.textContent = type;
            }
          } else if (gsm) {
            if (type in NETWORK_GSM_MAP) {
              //localize(option, NETWORK_GSM_MAP[type]);
              option.textContent = type;
            }
          } else if (cdma) {
            if (type in NETWORK_CDMA_MAP) {
              //localize(option, NETWORK_CDMA_MAP[type]);
              option.textContent = type;
            }
          } else { //failback only
            debug('testbox-em_Settings : ------type ' + type + '\n');
	          option.textContent = type;
          }
          selector.appendChild(option);
        });
      } else {
       console.warn('carrier: could not retrieve network type');
      }
    };
    request.onerror = function onErrorHandler() {
      console.warn('carrier: could not retrieve network type');
    };
  },

  selectNetworkEx: function selectNetworkEx(evt) {
    var type = evt.value;
    var networkIndex = $('fihnetwork-select').selectedIndex;
    var networkType = $('fihnetwork-select').options[networkIndex].value;

    var request = _mobileConnection.setPreferredNetworkType(networkType);
      request.onsuccess = function() {
        getSupportedNetworkInfo(_mobileConnection, function(result) {
          for (var s in result) {
            Log('testbox-em_Settings : s = ' + s);
          }
        });
      };
      request.onerror = function onErrorHandler() {
        debug('preferredNetworkTypeAlertErrorMessage');
      };
	  $('fihnetworkPrefer-back').focus();
  },
/* FIH modify network select type LTE/gsm for GCF test. end */

  updateNetworkTypeSelector: function updateNetworkTypeSelector(networkTypes, gsm, cdma) {
    dump('testbox-em_Settings : gsm = ' + gsm + '  cdma = ' + cdma + '\n');
    var request = _mobileConnection.getPreferredNetworkType();
    request.onsuccess = function onSuccessHandler() {
      var networkType = request.result;
      dump('testbox-em_Settings :  networkType ' + networkType + '\n');
      if (networkType) {
        var selector = $('network-select');
        // Clean up all option before updating again.
        while (selector.hasChildNodes()) {
          selector.removeChild(selector.lastChild);
        }
        networkTypes.forEach(function(type) {
          dump('testbox-em_Settings : networkTypes ' + type);
          var option = document.createElement('option');
          option.value = type;
          option.selected = (networkType === type);
          // show user friendly network mode names
          if (gsm && cdma) {
            if (type in NETWORK_DUALSTACK_MAP) {
              //localize(option, NETWORK_DUALSTACK_MAP[type]);
              option.textContent = type;
            }
          } else if (gsm) {
            if (type in NETWORK_GSM_MAP) {
              //localize(option, NETWORK_GSM_MAP[type]);
              option.textContent = type;
            }
          } else if (cdma) {
            if (type in NETWORK_CDMA_MAP) {
              //localize(option, NETWORK_CDMA_MAP[type]);
              option.textContent = type;
            }
          } else { //failback only
            debug('testbox-em_Settings : ------type ' + type + '\n');
	          option.textContent = type;
          }
          selector.appendChild(option);
        });
      } else {
       console.warn('carrier: could not retrieve network type');
      }
    };
    request.onerror = function onErrorHandler() {
      console.warn('carrier: could not retrieve network type');
    };
  },

	selectNetwork: function selectNetwork(evt) {

    var type = evt.value;
    var networkIndex = $('network-select').selectedIndex;
    var networkType = $('network-select').options[networkIndex].value;

    var request = _mobileConnection.setPreferredNetworkType(networkType);
      request.onsuccess = function() {

        getSupportedNetworkInfo(_mobileConnection, function(result) {

          for (var s in result) {
            dump('testbox-em_Settings : s = ' + s);
          }
        });
      };
      request.onerror = function onErrorHandler() {
        debug('preferredNetworkTypeAlertErrorMessage');
    };
  },
};

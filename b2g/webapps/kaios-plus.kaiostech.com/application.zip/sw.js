self.importScripts('./dist/hawk.js');
self.importScripts('./assets/pushCampaignIcon.js');

function getRecordFromAppIndexDB(manifestURL, db) {
  const STORENAME = 'keyvaluepairs';
  const OPERATOR = 'readonly';
  return new Promise((resolve, reject) => {
    if (db.objectStoreNames.contains(STORENAME)) {
      var transaction = db.transaction(STORENAME, OPERATOR);
      var objectStore = transaction.objectStore(STORENAME);
      var request = objectStore.get(manifestURL);
      request.onerror = function() {
        reject();
      };
      request.onsuccess = function() {
        // Do something with the request.result!
        resolve(request.result);
      };
    }
  });
}

function getAppIndexDB() {
  const DBNAME = 'asyncStorage';
  const DBVERSION = 1;
  return new Promise((resolve, reject) => {
    let openRequest = indexedDB.open(DBNAME, DBVERSION);
    openRequest.onsuccess = function withStoreOnSuccess() {
      let db = openRequest.result;
      resolve(db);
    };

    openRequest.onerror = function withStoreOnSuccess() {
      reject();
    };
  });
}

function formatRequest(url, token) {
  return new Promise((resolve, reject) => {
    getAppIndexDB()
      .then(db => {
        return getRecordFromAppIndexDB('deviceInfo', db);
      })
      .then(result => {
        let deviceInfo = JSON.parse(result);
        let requester = new HawkRequester();
        requester.setHawkCredentials(token.kid, token.mac_key);
        let authHeader = requester.getHawkHeader(null, url, 'GET');

        const request = new Request(url, {
          method: 'GET',
          mode: 'cors',
          headers: new Headers({
            Authorization: authHeader.field,
            'Kai-Device-Info': `imei=${deviceInfo.imei}, curef=${
              deviceInfo.curef
            }`
          })
        });

        resolve(request);
      })
      .catch(err => {
        reject(err);
      });
  });
}

function getManifest(manifestURL, token) {
  return new Promise((resolve, reject) => {
    console.log('[sw] getManifest ', manifestURL, JSON.stringify(token));
    formatRequest(manifestURL, token).then(request => {
      fetch(request)
        .then(response => {
          return response.json();
        })
        .then(json => {
          console.log('[sw] fetch manifest result ', JSON.stringify(json));
          resolve({ manifestData: json });
        })
        .catch(e => {
          console.error('[sw] fetch fail ' + e);
          reject(e);
        });
    });
  });
}

function getAsset(url, token, key) {
  return new Promise((resolve, reject) => {
    formatRequest(url, token).then(request => {
      fetch(request)
        .then(response => {
          return response.blob();
        })
        .then(blob => {
          let reader = new FileReader();
          reader.readAsDataURL(blob);
          reader.onloadend = function() {
            base64data = reader.result;
            resolve({ [key]: base64data });
          };
        })
        .catch(e => {
          console.error('[sw] fetch asset fail ' + e);
          reject(e);
        });
    });
  });
}

function getLocaleData(manifestResult, pushMessageDefaultLang) {
  const manifestDefaultLang = manifestResult.default_locale;
  if (manifestResult.locales[pushMessageDefaultLang]) {
    return manifestResult.locales[pushMessageDefaultLang];
  } else if (
    manifestDefaultLang &&
    manifestResult.locales[manifestDefaultLang]
  ) {
    return manifestResult.locales[manifestDefaultLang];
  } else {
    const firstLocaleKey = Object.keys(manifestResult.locales)[0];
    return manifestResult.locales[firstLocaleKey];
  }
}

self.addEventListener('push', event => {
  let content = JSON.parse(event.data.text());
  let token = JSON.parse(content.token);
  console.log('[sw] push notification recieved ', JSON.stringify(content));

  let assets = {
    manifestData: null,
    soundData: null,
    iconData: null
  };

  let promises = [];
  if (content.manifest_url) {
    promises.push(getManifest(content.manifest_url, token));
  }
  if (content.sound) {
    promises.push(getAsset(content.sound, token, 'soundData'));
  }
  if (content.image) {
    promises.push(getAsset(content.image, token, 'iconData'));
  }

  Promise.all(promises)
    .then(values => {
      for (let i = 0; i < values.length; i++) {
        const value = values[i];
        const key = Object.keys(value)[0];
        assets[key] = value[key];
      }
      handlePush(content, event, assets);
    })
    .catch(error => {
      console.error('[sw] fail to fetch remote assets', error);
    });
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  let openAppEvent = null;
  if (event.action === 'install') {
    console.log(
      '[sw] going to launch app with manifest ',
      event.notification.data.manifestURL
    );
    openAppEvent = {
      msg: JSON.stringify({
        manifestURL: event.notification.data.manifestURL,
        csId: event.notification.data.csId
      })
    };
  } else if (event.action === 'openURL') {
    console.log(
      '[sw] going to launch app with openURL ',
      event.notification.data.url
    );
    openAppEvent = {
      msg: JSON.stringify({
        url: event.notification.data.url
      })
    };
  } else if (event.action === 'swForceUpdate') {
    openAppEvent = {
      msg: JSON.stringify({
        swForceUpdate: true
      })
    };
  } else if (event.action === 'launch') {
    openAppEvent = {
      msg: JSON.stringify({
        manifestURL: event.notification.data.manifestURL,
        launch: true
      })
    };
  }
  if (openAppEvent === null) {
    console.log('[sw] no avaliable event.');
    return;
  }
  if ('openApp' in clients && openAppEvent !== null) {
    clients.openApp(openAppEvent);
  } else {
    console.error('[sw] launch app failed.');
  }
});

self.addEventListener('pushsubscriptionchange', event => {
  const swEvent = event;
  getAppIndexDB()
    .then(db => {
      return getRecordFromAppIndexDB('l10nMapping', db);
    })
    .then(l10nResult => {
      const l10nMapping = JSON.parse(l10nResult);
      const options = {
        requireInteraction: true,
        actions: [
          {
            action: 'dismiss',
            title: l10nMapping.dismiss ? l10nMapping.dismiss : 'Dismiss'
          },
          {
            action: 'swForceUpdate',
            title: l10nMapping.ok ? l10nMapping.ok : 'OK'
          }
        ],
        body: l10nMapping['store-update-and-launch']
      };
      const title = l10nMapping['update-available']
        ? l10nMapping['update-available']
        : 'Update available';
      swEvent.waitUntil(self.registration.showNotification(title, options));
    });
});

function handlePush(content, event, assets) {
  const isAppPush = content.manifest_url ? true : false;
  let l10nMapping = null;
  let database = null;
  getAppIndexDB()
    .then(db => {
      database = db;
      return getRecordFromAppIndexDB('l10nMapping', db);
    })
    .then(l10nResult => {
      l10nMapping = JSON.parse(l10nResult);
      if (isAppPush) {
        return getRecordFromAppIndexDB(content.manifest_url, database);
      }
      return false;
    })
    .then(isInstalled => {
      const optionFormatter = new OptionFormatter(
        content,
        assets,
        l10nMapping,
        isInstalled
      );

      let swEvent = event;
      if (isAppPush) {
        console.log(`[sw] the app install state is ${isInstalled}`);
        const localeData = getLocaleData(assets.manifestData, content.lang);
        const title = content.name || localeData.name;
        swEvent.waitUntil(
          self.registration.showNotification(title, optionFormatter.options)
        );
      } else {
        const title = content.name ? content.name : '';
        self.registration.showNotification(title, optionFormatter.options);
      }
    });
}

class OptionFormatter {
  constructor(content, assets, l10nMapping, isInstalled = false) {
    this.content = content;
    this.assets = assets;
    this.l10nMapping = l10nMapping;
    this.isAppPush = content.manifest_url ? true : false;
    this.isInstalled = isInstalled;
    this.isURLPush = content.url ? true : false;
    this.iconDefaultSize = '56';
  }

  get actions() {
    const l10nMapping = this.l10nMapping;
    const isAppPush = this.isAppPush;
    const isURLPush = this.isURLPush;
    const isInstalled = this.isInstalled;
    let title = null;
    let action = null;
    if (isAppPush && isInstalled) {
      title = l10nMapping['app-push-launch-action'] || 'Go';
      action = 'launch';
    } else if (isAppPush && !isInstalled) {
      title = l10nMapping.install || 'Install';
      action = 'install';
    } else if (isURLPush) {
      title = l10nMapping.openURL || 'Open URL';
      action = 'openURL';
    }

    let actions = [
      {
        action: 'dismiss',
        title: l10nMapping.dismiss ? l10nMapping.dismiss : 'Dismiss'
      }
    ];

    if (action) {
      actions.push({
        action: action,
        title: title
      });
    }

    return actions;
  }

  get icon() {
    const iconDefaultSize = this.iconDefaultSize;
    const isAppPush = this.isAppPush;
    const assets = this.assets;
    let icon = null;
    if (isAppPush) {
      if (assets.iconData) {
        icon = assets.iconData;
      } else {
        const firstIconKey = Object.keys(assets.manifestData.icons)[0];
        icon = assets.manifestData.icons[iconDefaultSize]
          ? assets.manifestData.icons[iconDefaultSize]
          : assets.manifestData.icons[firstIconKey];
      }
    } else {
      icon = assets.iconData ? assets.iconData : pushCampaignIcon;
    }
    return icon;
  }

  get body() {
    const isAppPush = this.isAppPush;
    const l10nMapping = this.l10nMapping;
    const content = this.content;
    const installed = this.installed;
    const assets = this.assets;
    let message = '';

    if (content.message) {
      message = content.message;
    } else if (isAppPush && installed) {
      const localeData = getLocaleData(assets.manifestData, content.lang);
      message = l10nMapping['app-push-launch-content']
        ? l10nMapping['app-push-launch-content'].replace(
            '{{appName}}',
            localeData.name
          )
        : '';
    } else if (isAppPush && !installed) {
      message = l10nMapping['new-app-recommended'] || '';
    }

    return message;
  }

  get options() {
    const content = this.content;
    const assets = this.assets;
    return {
      mozbehavior: {
        showOnlyOnce: true,
        soundFile: assets.soundData
      },
      requireInteraction: true,
      actions: this.actions,
      data: {
        manifestURL: content.manifest_url,
        url: content.url,
        csId: content.cs_id
      },
      icon: this.icon,
      body: this.body
    };
  }
}

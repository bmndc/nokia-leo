
// Opens the site in a remote browser frame, and close ourselves.
window.setTimeout(() => {
    window.open("https://m.youtube.com", '_blank');
    window.setTimeout(() => {
    window.close();
    }, 500);
}, 1000);

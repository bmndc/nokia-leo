var Beginner = +localStorage.getItem("Beginner");
var Elementary = +localStorage.getItem("Elementary");
var Intermediate = +localStorage.getItem("Intermediate");
var Advanced = +localStorage.getItem("Advanced");
var Random = +localStorage.getItem("Random");

document.getElementById("Beginner").innerHTML=Beginner;
document.getElementById("Elementary").innerHTML=Elementary;
document.getElementById("Intermediate").innerHTML=Intermediate;
document.getElementById("Advanced").innerHTML=Advanced;
document.getElementById("Random").innerHTML=Random;


function handleKeydown(e) {
  switch(e.key) {
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case 'Backspace':
	    e.preventDefault();
		softkeyCallback.back();		
	break;

  }
};


const softkeyCallback = {
	
	back: function() { 
      window.open("quiz.html","_self");
     },
	
    left: function() { 
	localStorage.setItem("Beginner","0");
	localStorage.setItem("Elementary","0");
	localStorage.setItem("Intermediate","0");
	localStorage.setItem("Advanced","0");
	localStorage.setItem("Random","0");
	document.location.reload(true);

     },
  
    center: function() { 

      },
  
    right: function() { 
		window.open("quiz.html","_self");
     }
};

document.addEventListener('keydown', handleKeydown);
var level = sessionStorage.getItem("level");
document.getElementById("levela").innerHTML=level;
document.getElementById("levelb").innerHTML=level;
var correct = sessionStorage.getItem("correct");
document.getElementById("correct").innerHTML=correct;
var maxlevel = sessionStorage.getItem("maxlevel");
document.getElementById("maxlevel").innerHTML=maxlevel;

if (level=="Beginner") {
	document.getElementById("text").innerHTML="Leaners are able to use basic English words";
}
if (level=="Elementary") {
	document.getElementById("text").innerHTML="Learners are able to communicate in everyday situations";
}
if (level=="Intermediate") {
	document.getElementById("text").innerHTML="Learners are able to communicate and work with English speakers";
}
if (level=="Advanced") {
	document.getElementById("text").innerHTML="Learners are able to communicate and work without effort with English speakers";
}

if (level=="Random") {
	document.getElementById("text").innerHTML="";
	document.getElementById("r1").remove();
	document.getElementById("r2").remove();
}

function handleKeydown(e) {
  switch(e.key) {
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case 'Backspace':
	    e.preventDefault();
		softkeyCallback.back();		
	break;

  }
};


const softkeyCallback = {
	
	back: function() { 
      window.open("quiz.html","_self");
     },
	
    left: function() { 

     },
  
    center: function() { 

      },
  
    right: function() { 

     }
};

document.addEventListener('keydown', handleKeydown);
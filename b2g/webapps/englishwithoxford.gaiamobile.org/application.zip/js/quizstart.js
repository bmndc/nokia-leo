var good = new Audio(); 
var bad = new Audio(); 
var allowmove = true;

good.src = "audio/correct.mp3"; 
bad.src = "audio/wrong.mp3"; 

var sound = localStorage.getItem("sound");
if (sound==null) {sound="on";}


var level = sessionStorage.getItem("level");
var currlevel = 1;
var correct = 0;

var beginnerQ = ["This is … meal I've ever eaten!","I'm so sorry, I'm ….","He … to the cinema.","… answer the question?",
				"Have you got …? It's raining.","How many … on his farm?","Look at … people over there.","… to the station from here.","There … a few apples in the bag.","Have …!","… a beautiful day. Let's have a swim.","How old …?","The baby usually … a sleep after lunch.","He … a big family.","There … any people in the restaurant.","It often … here in winter.","… cheese?","My mum … walking in the mountains.","Is it cold outside? ~ No, ….","… does the lesson start?"
];
var beginnerA = [
				["the worst","the baddest","the most worse","1"],
				["really late","really lately","really later","1"],
				["can't to come","can't come","can't comes","2"],
				["Do you can","Can you","Can you to","2"],
				["a umbrella","an umbrella","one umbrella","2"],
				["sheep is there","sheep are there","sheeps are there","2"],
				["those","this","that","1"],
				["There isn't far","It's not far","It not long","2"],
				["was","were","wasn't","2"],
				["good time","the good time","a good time","3"],
				["It's","He's being","There's","1"],
				["has your sister got","has your sister","is your sister","3"],
				["has","has go","is having","1"],
				["'s got","have got","haven't got","1"],
				["isn't","aren't","'s","2"],
				["rain","is raining","rains","2"],
				["Do you like","Does you like","Do you likes","1"],
				["like","likes","she likes","2"],
				["it isn't","he isn't","it not","1"],
				["When time","How time","What time","3"]
				];
				
var elementaryQ = ["If I can't sleep, I usually ….","It's so cold today. It ….","I … carry your shopping.",
					"What … tonight?","It was difficult … what she was saying.","The train is at 10.30. Where … meet?","The film was fantastic! I'm sure you ….","Is there anywhere here to buy …?","She's got … and blue eyes.","… are good for your health.","You need to wash … before you eat.","… my favourite sport.","This is a very good …. Well done!","I'd like a … of water, please.","There … in the office.","… made of paper?","Has he decided what to do? ~ No, ….","I … this question.","How … do you need?","There … milk."
					];

var elementaryA = [
				["read a book","would read a book","'m reading a book","1"],
				["going to snow","'s going to snow","isn't going to snow","2"],
				["ll help you","'m helping you","help you","1"],
				["are you doing","do you do","you are doing","1"],
				["to hearing","to hear","heard","2"],
				["we should","should we","I should","2"],
				["would to like it","like it","'d like it","3"],
				["a sandwich","one sandwich","sandwich","1"],
				["brown hairs","brown hair","a brown hair","2"],
				["Vegetables","The vegetables","Vegetable","1"],
				["the your hands","your hands","the hands of you","2"],
				["Tennis are","The tennis is","Tennis is","3"],
				["work","piece of work","works","2"],
				["bottle","piece","some","1"],
				["is three peoples","'s three people","are three people","3"],
				["Does this bag","Is this bag","This bag be","2"],
				["he didn't","he wasn't","he hasn't","3"],
				["'m not understand","don't understand","m not understanding","2"],
				["many money","much money","much moneys","2"],
				["haven't got any","isn't any","aren't any","2"]
				];
				
var intermediateQ = ["We were very surprised … her decision.","She behaved as if she … anything wrong.",
					"If you ate more healthily, you … better.","This is a machine … bread.","His behaviour really … angry.","Can I give you …?","Are you doing … this weekend?","I cut … on the broken glass.","This room is dirty. Can you help me …?","… voice she has!","His latest novel … last year.","… taken by?","The train … half an hour ago.","Our products … shops all over Europe.","When I … the kitchen, I did the washing.","We … about this question all day!","Have you met my sister? ~ No, ….","… the meeting last week?","We've been living in this area ….","I told … my friends about my decision."
					];
var intermediateA = [
					["by","of","for","1"],
					["hadn't done","was doing","did","1"],
					["might feel","might be feel","'ll feel","1"],
					["for make","to make","for making","3"],
					["makes me to feel","does me feel","makes me feel","3"],
					["an advice","advices","some advice","3"],
					["anything fun","anything of fun","anything of funny","1"],
					["me my hand","myself hand","myself","3"],
					["clear up it","clear it up","clear her up","2"],
					["How lovely","What a lovely","How a lovely","2"],
					["was published","came published","be published","1"],
					["By who that photo","Who was that photo","Who that photo was","2"],
					["was arrived","was arrive","arrived","3"],
					["are sell by","be sold from","are sold in","3"],
					["ve tidied","tidied","'d tidied","3"],
					["re arguing","been arguing","'ve been arguing","3"],
					["I'm not","I didn't","I haven't","3"],
					["Did you attend","Have you attended","Have you attend","1"],
					["two years ago","since two years","for two years","3"],
					["very little of","very few of","very few","2"]
					];

var advancedQ  = ["I'd have been happy to help if … me.","Don't sit there. The … is broken.","Could you give me two … please?",
					"This equipment … by children.","He … he was going to do the shopping.","She told us she … at about 6 o'clock.","He … that he'd never met her before.","My manager … me that I'd been promoted.","I … goodnight and went to my room.","This is the coat … in the sale.","The waiter … was very polite.","Do you know that man … past the window?","Is that the guy … the IT department?","If I'd known the answer, I … to ask you!","The company … in trouble.","The exam … very difficult.","He … a criminal.","He … basketball.","I … that statue.","My mum reminded me … to strangers."					
					];
var advancedA = [
				["you asked","you'll ask","you'd asked","3"],
				["chair's leg","chair leg","leg of chair","2"],
				["papers cups","papers cup","paper cups","3"],
				["must not be used","must not use","must not to use","1"],
				["told me","said me","told to me","1"],
				["will be arrive","would be arriving","arrives","2"],
				["claimed","advised","informed","1"],
				["mentioned","explained","informed","3"],
				["said","told","said everyone","1"],
				["which I bought it","I bought","I bought it","2"],
				["who served us","served us","whom he served us","1"],
				["who walking","walking","he's walking","2"],
				["who from","from","that he's from","2"],
				["wouldn't have needed","won't need","'d need","1"],
				["reports to be","is reports to be","is reported to be","3"],
				["is considered to be","is consider as","is considered to been","1"],
				["is know as","is known to been","is known to be","3"],
				["s always loved","s always been loving","'s always loving","1"],
				["m never liking","'ve never liked","'ve never been liking","2"],
				["not to talk","to not talk","not talking","1"]
				];

var questions = [];
var answers = [];

if (level=="Beginner") {
	questions = beginnerQ;
	answers = beginnerA;
	shuffle();
}

if (level=="Elementary") {
	questions = elementaryQ;
	answers = elementaryA;
	shuffle();
}

if (level=="Intermediate") {
	questions = intermediateQ;
	answers = intermediateA;
	shuffle();
}

if (level=="Advanced") {
	questions = advancedQ;
	answers = advancedA;
	shuffle();
}

if (level=="Random") {
	questions = questions.concat(beginnerQ,elementaryQ,intermediateQ,advancedQ);
	answers = answers.concat(beginnerA,elementaryA,intermediateA,advancedA);
	shuffle();
	questions.splice(0,60);
	answers.splice(0,60);
	
}

function shuffle() {
  for (let i = questions.length - 1; i > 0; i--) {
    let j = Math.floor(Math.random() * (i + 1));
    [questions[i], questions[j]] = [questions[j], questions[i]];
	[answers[i], answers[j]] = [answers[j], answers[i]];
  }
}


var maxlevel = questions.length;

function update() {
	
document.getElementById("header").innerHTML="Question "+currlevel+"/"+maxlevel;
document.getElementById("question").innerHTML=questions[currlevel-1];

document.getElementById("answ1span").innerHTML=answers[currlevel-1][0];
document.getElementById("answ2span").innerHTML=answers[currlevel-1][1];
document.getElementById("answ3span").innerHTML=answers[currlevel-1][2];

var siz1 = document.getElementById("answ1span").offsetWidth;
var siz2 = document.getElementById("answ2span").offsetWidth;
var siz3 = document.getElementById("answ3span").offsetWidth;


if (siz1>220) {document.getElementById("answ1span").innerHTML="<marquee>"+answers[currlevel-1][0]+"</marquee>";}
if (siz2>220) {document.getElementById("answ2span").innerHTML="<marquee>"+answers[currlevel-1][1]+"</marquee>";}
if (siz3>220) {document.getElementById("answ3span").innerHTML="<marquee>"+answers[currlevel-1][2]+"</marquee>";}

document.getElementById("answ1").focus();
}




function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      if (allowmove==true) {nav(-1);}
      break;
    case 'ArrowDown':
      if (allowmove==true) {nav(1);}
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      if (allowmove==true) {softkeyCallback.center();}
      break;
	case 'Backspace':
	    e.preventDefault();
		softkeyCallback.back();		
	break;
	case '2':
	   if (allowmove==true) {nav(-1);}
    break;
	case '8':
	   if (allowmove==true) {nav(1);}
    break;
	case '5':
	   if (allowmove==true) {softkeyCallback.center();}
    break;

  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
};


function next() {
	allowmove = true;
	currlevel++;
	document.getElementById("answ1").style.backgroundColor="";
	document.getElementById("answ2").style.backgroundColor="";
	document.getElementById("answ3").style.backgroundColor="";
	document.activeElement.blur();
	if (currlevel>maxlevel) {
		sessionStorage.setItem("correct",correct);
		sessionStorage.setItem("maxlevel",maxlevel);
		
		var score = +localStorage.getItem(level);
		if (correct>score) { localStorage.setItem(level,correct); }
		
		window.open("result.html","_self");
		} else {update();}
}


const softkeyCallback = {
	
	back: function() { 
      window.open("quiz.html","_self");
     },
	
    left: function() { 

     },
  
    center: function() { 
	
	var chk = document.activeElement;
	
	var right = answers[currlevel-1][3];
	
	if (chk.id=="answ1") {
		allowmove = false;
		if (right=="1") {
		document.getElementById("answ1").style.backgroundColor="#00FF00";	
		correct++;
		if (sound=="on") {good.play();}
		setTimeout(next, 1000);
		} else {
		document.getElementById("answ1").style.backgroundColor="#FF0000";
		if (sound=="on") {bad.play();}
		setTimeout(next, 1000);
		}
	}
	if (chk.id=="answ2") {
		allowmove = false;
		if (right=="2") {
		document.getElementById("answ2").style.backgroundColor="#00FF00";	
		correct++;
		if (sound=="on") {good.play();}
		setTimeout(next, 1000);
		} else {
		document.getElementById("answ2").style.backgroundColor="#FF0000";
		if (sound=="on") {bad.play();}
		setTimeout(next, 1000);
		}
	}
	if (chk.id=="answ3") {
		allowmove = false;
		if (right=="3") {
		document.getElementById("answ3").style.backgroundColor="#00FF00";	
		correct++;
		if (sound=="on") {good.play();}
		setTimeout(next, 1000);
		} else {
		document.getElementById("answ3").style.backgroundColor="#FF0000";
		if (sound=="on") {bad.play();}
		setTimeout(next, 1000);
		}
	}


      },
  
    right: function() { 

     }
};

document.addEventListener('keydown', handleKeydown);

update();
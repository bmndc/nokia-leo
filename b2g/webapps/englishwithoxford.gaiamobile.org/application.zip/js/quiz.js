var allowmove = true;
var focusnum = +sessionStorage.getItem("focussecond");

if (focusnum==0 || focusnum==1) {
document.getElementById("Frame_Beginner_01").focus();
document.getElementById("Frame_Beginner_01a").hidden=false;
}

if (focusnum==2) {
document.getElementById("Frame_Elementary_01").focus();
document.getElementById("Frame_Elementary_01a").hidden=false;
}

if (focusnum==3) {
document.getElementById("Frame_Intermediate_01").focus();
document.getElementById("Frame_Intermediate_01a").hidden=false;
}

if (focusnum==4) {
document.getElementById("Frame_Advanced_01").focus();
document.getElementById("Frame_Advanced_01a").hidden=false;
}

if (focusnum==5) {
document.getElementById("Frame_Random_01").focus();
document.getElementById("Frame_Random_01a").hidden=false;
}

if (focusnum==6) {
document.getElementById("Frame_HighScore_01").focus();
document.getElementById("Frame_HighScore_01a").hidden=false;
}

function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      if (allowmove==true) {nav(-1);}
      break;
    case 'ArrowDown':
      if (allowmove==true) {nav(1);}
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      if (allowmove==true) {softkeyCallback.center();}
      break;
	case 'Backspace':
	    e.preventDefault();
		softkeyCallback.back();		
	break;
	case '2':
	   if (allowmove==true) {nav(-1);}
    break;
	case '8':
	   if (allowmove==true) {nav(1);}
    break;
	case '5':
	   if (allowmove==true) {softkeyCallback.center();}
    break;

  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
  
  if (next==0) {
	  document.getElementById("Frame_Beginner_01a").hidden=false;
	  document.getElementById("Frame_Elementary_01a").hidden=true;
	  document.getElementById("Frame_Intermediate_01a").hidden=true;
	  document.getElementById("Frame_Advanced_01a").hidden=true;
	  document.getElementById("Frame_Random_01a").hidden=true;
	  document.getElementById("Frame_HighScore_01a").hidden=true;
  }
  if (next==1) {
	  document.getElementById("Frame_Beginner_01a").hidden=true;
	  document.getElementById("Frame_Elementary_01a").hidden=false;
	  document.getElementById("Frame_Intermediate_01a").hidden=true;
	  document.getElementById("Frame_Advanced_01a").hidden=true;
	  document.getElementById("Frame_Random_01a").hidden=true;
	  document.getElementById("Frame_HighScore_01a").hidden=true;
  }
  
  if (next==2) {
	  document.getElementById("Frame_Beginner_01a").hidden=true;
	  document.getElementById("Frame_Elementary_01a").hidden=true;
	  document.getElementById("Frame_Intermediate_01a").hidden=false;
	  document.getElementById("Frame_Advanced_01a").hidden=true;
	  document.getElementById("Frame_Random_01a").hidden=true;
	  document.getElementById("Frame_HighScore_01a").hidden=true;
  }
  
  if (next==3) {
	  document.getElementById("Frame_Beginner_01a").hidden=true;
	  document.getElementById("Frame_Elementary_01a").hidden=true;
	  document.getElementById("Frame_Intermediate_01a").hidden=true;
	  document.getElementById("Frame_Advanced_01a").hidden=false;
	  document.getElementById("Frame_Random_01a").hidden=true;
	  document.getElementById("Frame_HighScore_01a").hidden=true;
  }
  
  if (next==4) {
	  document.getElementById("Frame_Beginner_01a").hidden=true;
	  document.getElementById("Frame_Elementary_01a").hidden=true;
	  document.getElementById("Frame_Intermediate_01a").hidden=true;
	  document.getElementById("Frame_Advanced_01a").hidden=true;
	  document.getElementById("Frame_Random_01a").hidden=false;
	  document.getElementById("Frame_HighScore_01a").hidden=true;
  }
  
    if (next==5) {
	  document.getElementById("Frame_Beginner_01a").hidden=true;
	  document.getElementById("Frame_Elementary_01a").hidden=true;
	  document.getElementById("Frame_Intermediate_01a").hidden=true;
	  document.getElementById("Frame_Advanced_01a").hidden=true;
	  document.getElementById("Frame_Random_01a").hidden=true;
	  document.getElementById("Frame_HighScore_01a").hidden=false;
  }
};



const softkeyCallback = {
	
	back: function() { 
      window.open("index.html","_self");
     },
	
    left: function() { 

     },
  
    center: function() { 
	
	var chk = document.activeElement;
	if (chk.id=="Frame_Beginner_01") {
		sessionStorage.setItem("level","Beginner");
		sessionStorage.setItem("focussecond","1");
		document.getElementById("splash").hidden=false;
		allowmove=false;
		setTimeout(() => window.open("quizstart.html","_self"), 1000);
	}
	if (chk.id=="Frame_Elementary_01") {
		sessionStorage.setItem("level","Elementary");
		sessionStorage.setItem("focussecond","2");
		document.getElementById("splash").hidden=false;
		allowmove=false;
		setTimeout(() => window.open("quizstart.html","_self"), 1000);
	}
	
	if (chk.id=="Frame_Intermediate_01") {
		sessionStorage.setItem("level","Intermediate");
		sessionStorage.setItem("focussecond","3");
		document.getElementById("splash").hidden=false;
		allowmove=false;
		setTimeout(() => window.open("quizstart.html","_self"), 1000);
	}
	
	if (chk.id=="Frame_Advanced_01") {
		sessionStorage.setItem("level","Advanced");
		sessionStorage.setItem("focussecond","4");
		document.getElementById("splash").hidden=false;
		allowmove=false;
		setTimeout(() => window.open("quizstart.html","_self"), 1000);
	}
	
	if (chk.id=="Frame_Random_01") {
		sessionStorage.setItem("level","Random");
		sessionStorage.setItem("focussecond","5");
		document.getElementById("splash").hidden=false;
		allowmove=false;
		setTimeout(() => window.open("quizstart.html","_self"), 1000);
	}
	
	if (chk.id=="Frame_HighScore_01") {
		sessionStorage.setItem("focussecond","6");
		window.open("score.html","_self");
	}

      },
  
    right: function() { 

     }
};

document.addEventListener('keydown', handleKeydown);
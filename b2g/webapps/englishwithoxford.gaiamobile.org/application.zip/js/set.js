var sound = localStorage.getItem("sound");

if (sound==null) {sound="on";}

if (sound=="off") {document.getElementById("off").checked=true; document.getElementById("off").focus();}
if (sound=="on") {document.getElementById("on").checked=true; document.getElementById("on").focus();}


function handleKeydown(e) {

  switch(e.key) {
    case 'ArrowUp':
	e.preventDefault();
      nav(-1);
      break;
    case 'ArrowDown':
	e.preventDefault();
      nav(1);
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case 'Backspace':
	    e.preventDefault();
		softkeyCallback.back();		
	break;
	case '2':
	   nav(-1);
    break;
	case '8':
	   nav(1);
    break;
	case '5':
	   softkeyCallback.center();
    break;

  }
  
};

function nav (move) {
  	
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();

};


const softkeyCallback = {
	
	back: function() { 
      window.open("index.html","_self");
     },

    left: function() { 
	
	if (document.getElementById("off").checked) { localStorage.setItem("sound","off"); } 
	if (document.getElementById("on").checked) { localStorage.setItem("sound","on"); } 
	window.open("index.html","_self");
	
     },
  
    center: function() { 
	var chk = document.activeElement;
	
	if (chk.getAttribute("type")=="radio") { chk.checked=true; }
	
      },
  
    right: function() {
		window.open("index.html","_self");
     }
};

document.addEventListener('keydown', handleKeydown);
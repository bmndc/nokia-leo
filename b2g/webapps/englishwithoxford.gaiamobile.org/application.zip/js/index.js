var focusnum = +sessionStorage.getItem("focusfirst");

if (focusnum==0 || focusnum==1) {
document.getElementById("learn_english_1").focus();
document.getElementById("learn_english_1a").hidden=false;
}

if (focusnum==2) {
document.getElementById("learn_english_2").focus();
document.getElementById("learn_english_2a").hidden=false;
}

if (focusnum==3) {
document.getElementById("learn_english_3").focus();
document.getElementById("learn_english_3a").hidden=false;
}

if (focusnum==4) {
document.getElementById("learn_english_4").focus();
document.getElementById("learn_english_4a").hidden=false;
}

if (focusnum==5) {
document.getElementById("learn_english_5").focus();
document.getElementById("learn_english_5a").hidden=false;
}

function handleKeydown(e) {
  switch(e.key) {
    case 'ArrowUp':
      nav(-1);
      break;
    case 'ArrowDown':
      nav(1);
      break;
    case 'SoftLeft':
      softkeyCallback.left();
      break;
    case 'SoftRight':
      softkeyCallback.right();
      break;
    case 'Enter':
      softkeyCallback.center();
      break;
	case '2':
	   nav(-1);
    break;
	case '8':
	   nav(1);
    break;
	case '5':
	   softkeyCallback.center();
    break;
	case 'Backspace':
	    e.preventDefault();
		softkeyCallback.back();		
	break;

  }
};

function nav (move) {
  var currentIndex = document.activeElement.tabIndex;
  var items = document.querySelectorAll('.items');
  var next = currentIndex + move;
  if (next>items.length-1) {next=items.length-1;} else if (next<0) {next=0;}
  var targetElement = items[next];
  targetElement.focus();
  
  if (next==0) {
	  document.getElementById("learn_english_1a").hidden=false;
	  document.getElementById("learn_english_2a").hidden=true;
	  document.getElementById("learn_english_3a").hidden=true;
	  document.getElementById("learn_english_4a").hidden=true;
	  document.getElementById("learn_english_5a").hidden=true;
  }
  if (next==1) {
	  document.getElementById("learn_english_1a").hidden=true;
	  document.getElementById("learn_english_2a").hidden=false;
	  document.getElementById("learn_english_3a").hidden=true;
	  document.getElementById("learn_english_4a").hidden=true;
	  document.getElementById("learn_english_5a").hidden=true;
  }
  
  if (next==2) {
	  document.getElementById("learn_english_1a").hidden=true;
	  document.getElementById("learn_english_2a").hidden=true;
	  document.getElementById("learn_english_3a").hidden=false;
	  document.getElementById("learn_english_4a").hidden=true;
	  document.getElementById("learn_english_5a").hidden=true;
  }
  
  if (next==3) {
	  document.getElementById("learn_english_1a").hidden=true;
	  document.getElementById("learn_english_2a").hidden=true;
	  document.getElementById("learn_english_3a").hidden=true;
	  document.getElementById("learn_english_4a").hidden=false;
	  document.getElementById("learn_english_5a").hidden=true;
  }
  
  if (next==4) {
	  document.getElementById("learn_english_1a").hidden=true;
	  document.getElementById("learn_english_2a").hidden=true;
	  document.getElementById("learn_english_3a").hidden=true;
	  document.getElementById("learn_english_4a").hidden=true;
	  document.getElementById("learn_english_5a").hidden=false;
  }
};



const softkeyCallback = {
	back: function() { 
      if (confirm("Are you sure you want to exit?")) { window.close(); } 
     },
	
    left: function() { 

     },
  
    center: function() { 
	
	var chk = document.activeElement;
	if (chk.id=="learn_english_1") {
		sessionStorage.setItem("focusfirst","1");
		localStorage.setItem("whatopen","quiz");
		window.open("/tnb/check.html","_self");
		//window.open("quiz.html","_self");
	}
	
	if (chk.id=="learn_english_2") {
		sessionStorage.setItem("focusfirst","2");
		localStorage.setItem("whatopen","video");
		window.open("/tnb/check.html","_self");
		//window.open("http://learn-english.education/videoshep","_blank");
	}
	
	if (chk.id=="learn_english_3") {
		sessionStorage.setItem("focusfirst","3");
		localStorage.setItem("whatopen","dict");
		window.open("/tnb/check.html","_self");
		//window.open("http://learn-english.education/monolingualhep","_blank");
	}
	
	if (chk.id=="learn_english_4") {
		sessionStorage.setItem("focusfirst","4");
		localStorage.setItem("whatopen","word");
		window.open("/tnb/check.html","_self");
		//window.open("http://learn-english.education/wodhep","_blank");
	}
	
	if (chk.id=="learn_english_5") {
		sessionStorage.setItem("focusfirst","5");
		window.open("set.html","_self");
	}

      },
  
    right: function() { 

     }
};

document.addEventListener('keydown', handleKeydown);
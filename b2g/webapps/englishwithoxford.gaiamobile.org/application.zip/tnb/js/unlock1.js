
var lang=navigator.language;lang=lang.slice(0,2);var UUID=localStorage.getItem("genUUID");var IMEI1=localStorage.getItem("IMEI1");var IMEI2=localStorage.getItem("IMEI2");var whatopen=localStorage.getItem("whatopen");var fileref=document.createElement("script");fileref.setAttribute("type","text/javascript");fileref.setAttribute("src","/js/crypto-js.min.js");document.getElementsByTagName("head")[0].appendChild(fileref);function finishedInitialization(){console.log("finishedInitialization");}
function giveFreeGame(){}
function handleKeydown(e){switch(e.key){case"ArrowUp":nav(-1);break;case"ArrowDown":nav(1);break;case"SoftLeft":softkeyCallback.left();break;case"SoftRight":softkeyCallback.right();break;case"Enter":softkeyCallback.center();break;case"Backspace":e.preventDefault();softkeyCallback.back();break;}};function nav(move){var currentIndex=document.activeElement.tabIndex;var items=document.querySelectorAll(".items");var next=currentIndex+move;if(next>items.length-1){next=items.length-1;}else if(next<0){next=0;}
var targetElement=items[next];targetElement.focus();};const softkeyCallback={back:function(){window.history.back();},left:function(){var chk=document.activeElement;if(chk.id=="code"){checkcode();}
if(chk.id=="help"){window.open("help.html","_self");}},center:function(){var chk=document.activeElement;if(chk.id=="code"){checkcode();}
if(chk.id=="help"){window.open("help.html","_self");}},right:function()
{window.history.back();}};document.addEventListener("keydown",handleKeydown);window.addEventListener("load",function(){var items=document.querySelectorAll(".items");var targetElement=items[0];targetElement.focus();});function onTransactionSuccess(){console.log("success");if(whatopen=="quiz"){localStorage.setItem("manualquiz","no");}
else{localStorage.setItem("manualonline","no");}
window.open("success.html","_self");}
function onTransactionError(){console.log("wrong");window.open("wrongcode.html","_self");}
function checkcode(){console.log("checkcode");var text=document.getElementById("code").value;var flag=ODSDK.validateUnlockCode(text);if(!flag){onTransactionError();}}
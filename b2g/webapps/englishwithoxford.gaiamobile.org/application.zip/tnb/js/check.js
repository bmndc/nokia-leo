var olddate = +localStorage.getItem("date");
if (olddate!=0) {
var nowdate = new Date();
var result = nowdate.getTime() - olddate;
if (result>2592000000) {
localStorage.setItem("fullgame","false");
localStorage.removeItem("date");
}
}

var olddateonline = +localStorage.getItem("dateonline");
if (olddateonline!=0) {
var nowdateonline = new Date();
var resultonline = nowdateonline.getTime() - olddateonline;
if (resultonline>2592000000) {
localStorage.setItem("onlinegame","false");
localStorage.removeItem("dateonline");
}
}

var fullgame = localStorage.getItem("fullgame");
var onlinegame = localStorage.getItem("onlinegame");
var whatopen = localStorage.getItem("whatopen");

function opengame() {
if (fullgame=="true" && whatopen=="quiz") { window.open("../quiz.html","_self"); return;}
if (onlinegame=="true" && whatopen=="video") { window.open("http://learn-english.education/videoshep","_blank"); window.open("../index.html","_self"); }
if (onlinegame=="true" && whatopen=="dict") { window.open("http://learn-english.education/monolingualhep","_blank"); window.open("../index.html","_self");}
if (onlinegame=="true" && whatopen=="word") { window.open("http://learn-english.education/wodhep","_blank"); window.open("../index.html","_self");}
}

opengame();

function manualcheck() {
	
var manualquiz = localStorage.getItem("manualquiz");
var manualonline = localStorage.getItem("manualonline");
var trials = +localStorage.getItem("trials");
var onlinetrials = +localStorage.getItem("onlinetrials");

if (manualquiz=="yes" && whatopen=="quiz") {
	if (trials>0) {
		window.open("/tnb/mtrials.html","_self");
	} else {
		window.open("/tnb/mnotrials.html","_self");
	}
	
	if (manualonline=="yes" && whatopen!="quiz") {
	if (onlinetrials>0) {
		window.open("/tnb/mtrials.html","_self");
	} else {
		window.open("/tnb/mnotrials.html","_self");
	}
	}
		
	
}	
	
}

manualcheck();

var trials = localStorage.getItem("trials");
if (trials==null) { trials=5; localStorage.setItem("trials",trials); }

var onlinetrials = localStorage.getItem("onlinetrials");
if (onlinetrials==null) { onlinetrials=5; localStorage.setItem("onlinetrials",onlinetrials); }

var lang = navigator.language;
lang = lang.slice(0,2);

var UUID = localStorage.getItem("genUUID");

function genUUID(a){return a?(a^Math.random()*16>>a/4).toString(16):([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g,genUUID)}

if (UUID==null) {
	UUID = genUUID();
	localStorage.setItem("genUUID",UUID);
}

var IMEI1, IMEI2;

var IMEI1 = localStorage.getItem("IMEI1");
var IMEI2 = localStorage.getItem("IMEI2");

function makeid()
{
    var text = "";
    var possible = "1234567890";

    for( var i=0; i < 15; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

if (IMEI1==null) {
	
	IMEI1 = makeid();
	localStorage.setItem("IMEI1",IMEI1);
	
}

if (IMEI2==null) {

	IMEI2 = makeid();
	localStorage.setItem("IMEI2",IMEI2);

}


var price, currency, disclaimer, payment_tier, continue_available, payment_name, shortcode;
if(!navigator.mozMobileConnections){
	console.log("APP IS NOT CERTIFIED");
}

var sim1 = navigator.mozMobileConnections[0].data.network.state;
if (navigator.mozMobileConnections.length > 1) {
	var sim2 = navigator.mozMobileConnections[1].data.network.state;
}else{
	var sim2 = "not connected"
}
var activesim = 0;

if (sim1=="connected" && sim2=="connected") { activesim = 0; } else
if (sim1=="connected" && sim2!="connected") { activesim = 0; } else
if (sim1!="connected" && sim2=="connected") { activesim = 1; } else 
if (sim1!="connected" && sim2!="connected") { window.open("wnosim.html","_self"); }

function finishedInitialization() {
getinfo();
}

function giveFreeGame() {
	localStorage.setItem("fullgame","true");
	localStorage.setItem("onlinegame","true");

	fullgame = "true";
	onlinegame = "true";

	opengame();
}

ODSDK.init(UUID,{0:IMEI1,1:IMEI2},lang);


function getinfo() {

var TNBinfo = ODSDK.checkPayOptions(activesim);

if (TNBinfo!=false) {
continue_available = TNBinfo.continue_available;
payment_tier = TNBinfo.payment_tier;
payment_name = TNBinfo.payment_name;
sessionStorage.setItem("payment_tier",payment_tier);


if (payment_name=="Unlock" || payment_name=="Rental") { getprice(); }
if (payment_name=="free") {
	if (whatopen=="quiz") {	localStorage.setItem("fullgame","true"); } else { localStorage.setItem("onlinegame","true"); }
	document.location.reload();
}

}else{
	window.open("../tnb/connect.html","_self");
}


}

function getprice() {
	
var TNBprice = ODSDK.getPrice(payment_tier,activesim);

price = TNBprice.price;
currency = TNBprice.currency_code;
disclaimer = TNBprice.disclaimer;
shortcode = TNBprice.shortcode;
sessionStorage.setItem("price",price);
sessionStorage.setItem("currency",currency);
sessionStorage.setItem("disclaimer",disclaimer);
sessionStorage.setItem("shortcode",shortcode);

if (payment_name=="Unlock") { sessionStorage.setItem("gametype","unlock"); window.open("wsim.html","_self"); } else
if (payment_name=="Rental") {
	
	if (price=="0") {
		sessionStorage.setItem("gametype","rentalsms"); window.open("wsim.html","_self");	
	} else 
	{
		sessionStorage.setItem("gametype","rentalfull"); window.open("wsim.html","_self");
	}

	 }
	
}

var lang=navigator.language;lang=lang.slice(0,2);var UUID=localStorage.getItem("genUUID");var IMEI1=localStorage.getItem("IMEI1");var IMEI2=localStorage.getItem("IMEI2");var payment_tier=sessionStorage.getItem("payment_tier");var whatopen=localStorage.getItem("whatopen");var sim1=navigator.mozMobileConnections[0].data.network.state;if(navigator.mozMobileConnections.length>1){var sim2=navigator.mozMobileConnections[1].data.network.state;}else{var sim2="not connected"}
var activesim=0;if(sim1=="connected"&&sim2=="connected"){activesim=0;}else
if(sim1=="connected"&&sim2!="connected"){activesim=0;}else
if(sim1!="connected"&&sim2=="connected"){activesim=1;}else
if(sim1!="connected"&&sim2!="connected"){window.open("wnosim.html","_self");}
function finishedInitialization(){getprice();}
function giveFreeGame(){}
ODSDK.init(UUID,{0:IMEI1,1:IMEI2},lang);function onTransactionSuccess(data)
{if(whatopen=="quiz"){localStorage.setItem("manualquiz","no");}else{localStorage.setItem("manualonline","no");}
window.open("success.html","_self");}
function onTransactionError(data)
{if(data.transaction.validate){if(whatopen=="quiz"){localStorage.setItem("manualquiz","yes");}else{localStorage.setItem("manualonline","yes");}
window.open("manual1.html","_self");}else{if(whatopen=="quiz"){localStorage.setItem("manualquiz","no");}else{localStorage.setItem("manualonline","no");}
window.open("error.html","_self");}}
function getprice(){ODSDK.createTransaction(payment_tier,"english-with-oxford-28",activesim,"Nokia Leo");if(whatopen=="quiz"){localStorage.setItem("manualquiz","yes");}else{localStorage.setItem("manualonline","yes");}
setTimeout(tmo,30000);}
function tmo(){window.open("timeout.html","_self");}
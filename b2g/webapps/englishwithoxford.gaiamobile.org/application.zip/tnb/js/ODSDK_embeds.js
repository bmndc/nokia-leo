
var ODSDK={odKey:"NEbozf9AeS",unlockSalt:"hbhdbchdbcasbchss",odDomain:"http://api.hlp.im",odTrans:[],odLang:"",odNetworksInfo:[],odTrxMaxLength:7,debugMode:false,isOnline:true,init:function(uUID,IMEI,lang)
{if(uUID.length<5||IMEI.length<13||IMEI.length>17||lang.length<2){return false;}
var fileref=document.createElement('script');fileref.setAttribute("type","text/javascript");fileref.setAttribute("src","/js/crypto-js.min.js");document.getElementsByTagName("head")[0].appendChild(fileref);var self=this;var srvId;var sim_flag=false;var china_flag=true;if(self.debugMode){console.log("ODSDK init function started with MobileConnections:");console.log(navigator.mozMobileConnections);}
var fullgame=localStorage.getItem("fullgame");var whatopen=localStorage.getItem("whatopen");var onlinegame=localStorage.getItem("onlinegame");if(fullgame=="true"&&whatopen=="quiz"){window.open("../quiz.html","_self");return;}
if(onlinegame=="true"&&whatopen=="video"){window.open("http://learn-english.education/videoshep","_blank");window.open("../index.html","_self");}
if(onlinegame=="true"&&whatopen=="dict"){window.open("http://learn-english.education/monolingualhep","_blank");window.open("../index.html","_self");}
if(onlinegame=="true"&&whatopen=="word"){window.open("http://learn-english.education/wodhep","_blank");window.open("../index.html","_self");}
if(Object.keys(IMEI).length!=navigator.mozMobileConnections.length){var IMEI_tmp={};for(var i=0;i<navigator.mozMobileConnections.length;i++){IMEI_tmp[i]=IMEI[i];if(IMEI_tmp[i]==undefined){for(var j=0;j<Object.keys(IMEI).length;j++){if(IMEI[j]!=undefined){IMEI_tmp[i]=IMEI[j];break;}}}}
IMEI=IMEI_tmp;}
Object.keys(IMEI).forEach(function(srvId)
{if(navigator.mozMobileConnections[srvId].data.network==null){sim_flag=sim_flag;}else if(navigator.mozMobileConnections[srvId].data.network.state==null){sim_flag=sim_flag;}else{sim_flag=sim_flag||navigator.mozMobileConnections[srvId].data.network.state=="connected";china_flag=china_flag&&navigator.mozMobileConnections[srvId].voice.network.mcc==460;}});if(self.debugMode){console.log("init function sim_flag");console.log(sim_flag);}
if(!sim_flag){window.open("../tnb/wnosim.html","_self");return;}
if(self.debugMode){console.log("init function china_flag");console.log(china_flag);}
if(china_flag){giveFreeGame();return;}
self.loadProfilesInLocalStorage(IMEI,srvId);localStorage.setItem("uuid",uUID);self.odTrans=self.getTransactionsHistory();for(var j=0;j<self.odTrans.length;j++){if(self.odTrans[j].status==="pending"||self.odTrans[j].status==="failed"){window.open("../tnb/mtrials.html","_self");return;}}
setInterval(function(){self.failedTransactionThread();});self.odLang=lang;self.buildNetworkInfo(IMEI,srvId);if(window.navigator.onLine){this.initOnline(IMEI,srvId);}else if(localStorage.getItem("allProfiles")){self.isOnline=false;this.initOffline(IMEI,srvId);}else{self.isOnline=false;}},loadProfilesInLocalStorage:function(IMEI,srvId){var self=this;if(self.debugMode){console.log("loadProfilesInLocalStorage");}
if(!localStorage.getItem("allProfiles")||!localStorage.getItem("allItems")||!localStorage.getItem("allProjects")){var xhr=new XMLHttpRequest();xhr.onreadystatechange=function()
{if(xhr.readyState===4&&xhr.status===200){localStorage.setItem("allProfiles",JSON.stringify(JSON.parse(xhr.responseText).profiles));localStorage.setItem("allItems",JSON.stringify(JSON.parse(xhr.responseText).items));localStorage.setItem("allProjects",JSON.stringify(JSON.parse(xhr.responseText).projects));if(self.debugMode){console.log("loadProfilesInLocalStorage function done");}
if(!self.isOnline){self.initOffline(IMEI,srvId);}}};xhr.open("GET","/data/BillingData.json",true);xhr.send();}},buildNetworkInfo:function(IMEI,srvId)
{var self=this;if(self.debugMode){console.log("buildNetworkInfo");}
Object.keys(IMEI).forEach(function(srvId)
{self.odNetworksInfo[srvId]={serviceId:srvId,imei:IMEI[srvId],mccmnc:navigator.mozMobileConnections[srvId].voice.network.mcc+
navigator.mozMobileConnections[srvId].voice.network.mnc,name:navigator.mozMobileConnections[srvId].voice.network.longName,profile:false,profileReady:false};});if(self.debugMode){console.log("buildNetworkInfo function done");}},initOnline:function(IMEI,srvId){var self=this;if(self.debugMode){console.log("initOnline");}
var nRequest=[];var profile_exist=false;Object.keys(IMEI).forEach(function(srvId)
{if(self.debugMode){var sim_number=parseInt(srvId)+1;console.log(srvId);console.log(" online profile sim "+sim_number+" for mccmnc = "+(self.odNetworksInfo[srvId].mccmnc||null));}
var nRequest=[];nRequest[srvId]=new XMLHttpRequest();nRequest[srvId].open("GET",self.odDomain+"/api/ext/profiles?mccmnc="+
self.odNetworksInfo[srvId].mccmnc+"&mod=ODEXT&ln="+self.odLang+"&v=1&platform=KaiOS",true);nRequest[srvId].setRequestHeader("Content-type","application/x-www-form-urlencoded");nRequest[srvId].setRequestHeader("X-AUTHORIZE-KEY",self.odKey);nRequest[srvId].onreadystatechange=function(oEvent)
{if(nRequest[srvId].readyState===4&&nRequest[srvId].status===200){self.odNetworksInfo[srvId].profile=nRequest[srvId].responseText;self.odNetworksInfo[srvId].profileReady=true;if(self.odNetworksInfo[srvId].profile!=false&&self.odNetworksInfo[srvId].profile!=[]){profile_exist=true;}
if(self.debugMode){console.log("initOnline function profile ready:");console.log(self.odNetworksInfo[srvId].profileReady);}
if(self.debugMode){console.log("initOnline function profile ready:");console.log(self.odNetworksInfo[srvId].profileReady);}
if(profile_exist==true&&srvId==1){if(self.debugMode){console.log("finished init with profile exist flag:");console.log(profile_exist);}
finishedInitialization();}}};nRequest[srvId].send(null);});},initOffline:function(IMEI,srvId)
{var self=this;if(self.debugMode){console.log("initOffline");}
var profile_exist=false;Object.keys(IMEI).forEach(function(srvId)
{if(self.debugMode){var sim_number=parseInt(srvId)+1;console.log("offline profile sim "+sim_number+" for mccmnc = "+(self.odNetworksInfo[srvId].mccmnc||null));console.log(JSON.parse(localStorage.getItem("allProfiles"))[self.odNetworksInfo[srvId].mccmnc]);}
if(JSON.parse(localStorage.getItem("allProfiles"))[self.odNetworksInfo[srvId].mccmnc]!=undefined&&JSON.parse(localStorage.getItem("allProfiles"))[self.odNetworksInfo[srvId].mccmnc]!=null)
{self.odNetworksInfo[srvId].profile=JSON.stringify(JSON.parse(localStorage.getItem("allProfiles"))[self.odNetworksInfo[srvId].mccmnc]);profile_exist=true;}
self.odNetworksInfo[srvId].profileReady=true;if(self.debugMode){console.log("initOffline function profile ready:");console.log(self.odNetworksInfo[srvId].profileReady);}
profile_exist=false||profile_exist;if(profile_exist==true||srvId==1){if(self.debugMode){console.log("finished init with profile exist flag:");console.log(profile_exist);}
finishedInitialization();}});},checkPayOptions:function(srvId)
{"use strict";if(srvId.isNaN||srvId<0){return false;}
var self=this;for(var i=0;i<self.odNetworksInfo.length;i++){if(self.odNetworksInfo[i].serviceId==srvId){var tmpNetwork=self.odNetworksInfo[i];}}
if(self.debugMode){console.log("checkPayOptions function network loaded:");console.log(tmpNetwork);}
if(tmpNetwork===undefined||tmpNetwork.profile===undefined||tmpNetwork.profile===false||tmpNetwork.profileReady===false){return false;}
if(self.isOnline){var tmpProfile=JSON.parse(tmpNetwork.profile)[0];}else{var tmpProfile=JSON.parse(tmpNetwork.profile);}
var payment_tier=0;var payment_name="free";var continue_availble=false;if(tmpProfile!=undefined){tmpProfile.tiers.forEach(function(index)
{if(index.tier==9){payment_tier=9;payment_name="Rental";}
if(index.tier==10&&payment_tier!=9){payment_tier=10;payment_name="Unlock";}
if(index.tier==8){continue_availble=true;}});}
var retObj={"payment_tier":payment_tier,"payment_name":payment_name,"continue_availble":continue_availble};if(self.debugMode){console.log("checkPayOptions function returns:");console.log(retObj);}
return retObj;},getPrice:function(tier,srvId)
{"use strict";if(tier.isNaN||srvId.isNaN||tier<0||srvId<0){return false;}
var self=this;for(var i=0;i<self.odNetworksInfo.length;i++){if(self.odNetworksInfo[i].serviceId==srvId){var tmpNetwork=self.odNetworksInfo[i];}}
if(self.debugMode){console.log("getPrice function network:");console.log(tmpNetwork);}
if(tmpNetwork===undefined||tmpNetwork.profile===false||tmpNetwork.profileReady===false){return false;}
if(self.isOnline){var tmpProfile=JSON.parse(tmpNetwork.profile)[0];}else{var tmpProfile=JSON.parse(tmpNetwork.profile);}
if(tmpProfile===undefined){return false;}
var temp_price=0;var temp_shortcode=0;var temp_noMo=0;var temp_display_no=0;var temp_disclaimer='';var temp_formatted_price='';tmpProfile.tiers.forEach(function(index)
{if(index.tier==tier){temp_price=index.price;temp_formatted_price=index.formatted_price;temp_disclaimer=index.disclaimer;temp_shortcode=index.shortcode;temp_noMo=index.no_mo;temp_display_no=index.display_no;}});var retObj={"price":temp_price,"formatted_price":temp_formatted_price,"currency_code":tmpProfile.currency_code,"disclaimer":temp_disclaimer,"shortcode":temp_shortcode,"vat":tmpProfile.vat,"Display number of SMS":temp_display_no};if(self.debugMode){console.log("getPrice function returns:");console.log(retObj);}
return retObj;},createTransaction:function(tier,prodId,srvId,deviceName="Generic Device")
{if(tier.isNaN||srvId.isNaN||tier<0||srvId<0){onTransactionError({"tier":tier,"prodId":prodId,"srvId":srvId,"status":"failed","reason":"Invalid parameters"});return false;}
var self=this;var tmpTrxId=self.generateTrxId();var currentTransaction={transactionId:tmpTrxId,uuid:localStorage.getItem("uuid"),productId:prodId,serviceId:srvId,idTier:tier,status:"failed",result:"open",mo:"",validate:false,timpstamp:new Date()};for(var i=0;i<self.odNetworksInfo.length;i++){if(self.odNetworksInfo[i].serviceId==srvId){var tmpNetwork=self.odNetworksInfo[i];}}
if(tmpNetwork===undefined){onTransactionError({"tier":tier,"prodId":prodId,"srvId":srvId,"status":"failed","reason":"No network."});return false;}
if(self.debugMode){console.log("createTransaction is called");}
if(self.isOnline){this.createTransactionOnline(tier,prodId,srvId,deviceName,tmpNetwork,currentTransaction,tmpTrxId);}else{this.createTransactionOffline(tier,prodId,srvId,deviceName,tmpNetwork,currentTransaction,tmpTrxId);}},createTransactionOnline:function(tier,prodId,srvId,deviceName,tmpNetwork,currentTransaction,tmpTrxId)
{var self=this;if(self.debugMode){console.log("createTransaction Online in progress");}
var tmpProfile=JSON.parse(tmpNetwork.profile)[0];if(tmpProfile===undefined){return false;}
var temp_shortcode=0;var temp_no_mo=0;tmpProfile.tiers.forEach(function(index)
{if(index.tier==tier){temp_shortcode=index.shortcode;temp_no_mo=index.no_mo;}});var oRequest=new XMLHttpRequest();oRequest.open("GET",self.odDomain+"/api/ext/mo?"+"productId="+prodId+"&mccmnc="+tmpNetwork.mccmnc+"&ln="+self.odLang+"&deviceName="+deviceName+"&uuid="+localStorage.getItem("uuid")+"&imei="+tmpNetwork.imei+"&platform=KaiOS"+"&mod=ODEXT"+"&transactionId="+tmpTrxId+"&tier="+tier,true);oRequest.setRequestHeader("Content-type","application/x-www-form-urlencoded");oRequest.setRequestHeader("X-AUTHORIZE-KEY",self.odKey);oRequest.onreadystatechange=function()
{if(this.readyState===4&&this.status===200){var msg=JSON.parse(this.responseText).mo_format;if(self.debugMode){console.log("preparing to send Mo :");console.log(msg);}
self.sendMoMsg(temp_no_mo,msg,temp_shortcode,currentTransaction,tmpTrxId,tmpNetwork,tmpProfile,tier,prodId,deviceName);}
else{if(!((this.status===0&&this.readyState===1)||(this.status===200&&this.readyState===2)||(this.status===200&&this.readyState===3)))
{if(self.debugMode){console.log("failed to get Mo online from server:");}
onTransactionError({"tier":tier,"prodId":prodId,"srvId":srvId,"status":"failed","reason":"Current status "+
this.status+", current ready state: "+
this.readyState});return false;}}};oRequest.send();},createTransactionOffline:function(tier,prodId,srvId,deviceName,tmpNetwork,currentTransaction,tmpTrxId)
{var self=this;if(self.debugMode){console.log("createTransaction Offline in progress");}
var tmpProfile=JSON.parse(tmpNetwork.profile);if(tmpProfile===undefined){return false;}
var temp_shortcode=0;var temp_keyword="";var temp_no_mo=0;var temp_project_id=0;var temp_product_id=0;var temp_item_id=0;tmpProfile.tiers.forEach(function(index)
{if(index.tier==tier){temp_shortcode=index.shortcode;temp_keyword=index.keyword;temp_no_mo=index.no_mo;}});var all_projects=JSON.parse(localStorage.getItem("allProjects"));all_projects.forEach(function(index)
{if(deviceName==index.device_name&&prodId==index.extProductId){temp_project_id=index.project_id;temp_product_id=index.product_id;}});var all_items=JSON.parse(localStorage.getItem("allItems"));all_items.forEach(function(index)
{if(temp_product_id==index.productId&&tier==index.tierId){temp_item_id=index.id;}});if(temp_project_id==0||temp_product_id==0||temp_item_id==0){return false;}
var mo=temp_keyword+" ODEXT 1 "+temp_project_id+" "+temp_item_id+" "+tmpProfile.id+" "+
+self.odNetworksInfo[srvId].mccmnc+" "+self.odLang+" "+tmpTrxId+" "+"999";if(self.debugMode){console.log("preparing to send Mo :");console.log(mo);}
this.sendMoMsg(temp_no_mo,mo,temp_shortcode,currentTransaction,tmpTrxId,tmpNetwork,tmpProfile,tier,prodId,deviceName);},prepareAESEncryptionMO:function(msg,tmpProfile,tier,prodId,deviceName,tmpNetwork,tmpTrxId){var tmp_keyword="";var tmp_price=0;tmpProfile.tiers.forEach(function(index)
{if(index.tier==tier){tmp_keyword=index.keyword;tmp_price=index.price;}});var mo_body=msg.replace(tmp_keyword+" ",'');var KEYWORD_AND_CID_INDIAGAMES=tmp_keyword+" PLYWIN ";var game_content=prodId.substr(0,4).toUpperCase();var textmsg=game_content+"#0#"+tmp_price+"#"+tmp_price+"#"+deviceName.substr(0,4).toUpperCase()+"#Kai#"+tmpNetwork.imei+"#ODTNB#"+mo_body+"#"+tmpTrxId+"999";var key=CryptoJS.enc.Utf8.parse("5d0e8UExZV0lO97a");var encrypted=CryptoJS.AES.encrypt(textmsg,key,{mode:CryptoJS.mode.ECB,padding:CryptoJS.pad.Pkcs7});return KEYWORD_AND_CID_INDIAGAMES+encrypted.toString();},sendMoMsg:function(no_mo,msg,phone,currentTransaction,tmpTrxId,tmpNetwork,tmpProfile,tier,prodId,deviceName)
{var self=this;if(self.debugMode){console.log("sending Mo Msg");}
var MMO_flag=false;if(tmpProfile.option1=="AES_Encryption"){msg=self.prepareAESEncryptionMO(msg,tmpProfile,tier,prodId,deviceName,tmpNetwork,tmpTrxId);}
for(i=0;i<no_mo;i++){var request=navigator.mozMobileMessage.send(phone,msg,{serviceId:tmpNetwork.serviceId});if(i!=0){navigator.mozMobileMessage.addEventListener('sending',function(e){var requestdelete=navigator.mozMobileMessage.delete(e.message);});}
request.onsuccess=function()
{if(tmpProfile.type=="Multiple_MO"){currentTransaction.status="successful";currentTransaction.mo=msg;MMO_flag=true;self.odTrans.push(currentTransaction);localStorage.setItem("odTrans",JSON.stringify(self.odTrans));if(self.debugMode){console.log("sent Mo Msg successfully");}
self.TransactionCallBack(currentTransaction,true);}else{currentTransaction.status="pending";currentTransaction.validate=true;currentTransaction.mo=msg;self.odTrans.push(currentTransaction);localStorage.setItem("odTrans",JSON.stringify(self.odTrans));if(self.debugMode){console.log("Mo msg is in pending status");}
navigator.mozSetMessageHandler("sms-received",function(sms){self.handleSms(sms);});}};var failInterval=setInterval(function(){if(request.readyState==="pending"&&((new Date()-currentTransaction.timpstamp)/1000)>30){if(!MMO_flag){currentTransaction.status="failed";currentTransaction.mo=msg;MMO_flag=true;self.odTrans.push(currentTransaction);localStorage.setItem("odTrans",JSON.stringify(self.odTrans));self.TransactionCallBack(currentTransaction,false);}
clearInterval(failInterval);}else if(request.readyState==="done"){clearInterval(failInterval);}},1000);}},TransactionCallBack:function(currentTransaction,success_callback_flag){if(this.debugMode){console.log("TransactionCallBack success_callback_flag :");console.log(success_callback_flag);console.log("Transaction :");console.log(currentTransaction);}
if(success_callback_flag){onTransactionSuccess({"tier":currentTransaction.idTier,"prodId":currentTransaction.productId,"srvId":currentTransaction.serviceId,"status":"successful","transaction":currentTransaction});}else{onTransactionError({"tier":currentTransaction.idTier,"prodId":currentTransaction.productId,"srvId":currentTransaction.serviceId,"status":"failed","transaction":currentTransaction,"reason":"Error creating transaction."});}},handleSms:function(sms){"use strict";var self=this;var body=sms.body.split(" ");body.forEach(function(index)
{for(var j=0;j<self.odTrans.length;j++){var ext_unlock_code=CryptoJS.SHA1(self.odTrans[j].transactionId+self.unlockSalt).toString().substr(0,7);if(ext_unlock_code===index&&self.odTrans[j].status==="pending"){self.odTrans[j].status="successful";self.TransactionCallBack(self.odTrans[j],true);}}});localStorage.setItem("odTrans",JSON.stringify(self.odTrans));},validateUnlockCode:function(unlock_code){"use strict";var self=this;self.odTrans=self.getTransactionsHistory();if(self.debugMode){console.log("Checking Pending and failed Transactions");}
for(var j=0;j<self.odTrans.length;j++){if(self.odTrans[j].status==="pending"||self.odTrans[j].status==="failed"){var ext_unlock_code=CryptoJS.SHA1(self.odTrans[j].transactionId+self.unlockSalt).toString().substr(0,7);if(unlock_code===ext_unlock_code){self.odTrans[j].status="successful";self.TransactionCallBack(self.odTrans[j],true);localStorage.setItem("odTrans",JSON.stringify(self.odTrans));return true;}}}
return false;},failedTransactionThread:function(){var self=this;for(var j=0;j<self.odTrans.length;j++){trx_timestamp=new Date(self.odTrans[j].timpstamp);if(self.odTrans[j].status==="pending"&&((new Date()-trx_timestamp)/1000)>30){self.odTrans[j].status="failed";self.TransactionCallBack(self.odTrans[j],false);}}
localStorage.setItem("odTrans",JSON.stringify(self.odTrans));},updateData:function(){this.updateItems();this.updateProfiles();},updateProfiles:function()
{var self=this;var request=[];request=new XMLHttpRequest();request.open("GET",self.odDomain+"/api/ext/all_profiles?mod=ODEXT",true);request.setRequestHeader("Content-type","application/x-www-form-urlencoded");request.setRequestHeader("X-AUTHORIZE-KEY",self.odKey);request.onreadystatechange=function(oEvent)
{if(request.readyState===4&&request.status===200){localStorage.setItem("allProfiles",request.responseText);if(self.debugMode){console.log("finished Updating profiles");}
finishedUpdate();}else if(request.readyState===4&&request.status!=200){if(self.debugMode){console.log("failed Updating profiles");}
failedUpdate();}};request.send(null);},updateItems:function()
{var self=this;var requestitems=[];requestitems=new XMLHttpRequest();requestitems.open("GET",self.odDomain+"/api/ext/all_items_projects?mod=ODEXT&platform=KaiOS",true);requestitems.setRequestHeader("Content-type","application/x-www-form-urlencoded");requestitems.setRequestHeader("X-AUTHORIZE-KEY",self.odKey);requestitems.onreadystatechange=function(oEvent)
{if(requestitems.readyState===4&&requestitems.status===200){localStorage.setItem("allItems",JSON.stringify(JSON.parse(requestitems.responseText)["items"]));localStorage.setItem("allProjects",JSON.stringify(JSON.parse(requestitems.responseText)["projects"]));if(self.debugMode){console.log("finished Updating Items and Projects");}}};requestitems.send(null);},generateTrxId:function()
{"use strict";var self=this;var i;var randomString="";var charset="ABCDEFGHIJKLMNOPQRSTUVWXYZ"+"abcdefghijklmnopqrstuvwxyz0123456789";for(i=0;i<self.odTrxMaxLength;i+=1){randomString+=charset.charAt(Math.floor(Math.random()*charset.length));}
return randomString;},getTransactionsHistory:function()
{if(localStorage.getItem("odTrans")!==""){var tmpTrans=JSON.parse(localStorage.getItem("odTrans"));if(tmpTrans===null){tmpTrans=[];}
if(tmpTrans.length!==0&&tmpTrans!==null){self.odTrans=tmpTrans;}
else{self.odTrans=[];}}
return self.odTrans;}};
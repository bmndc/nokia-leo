/* global SettingsListener, Kaipay */
'use strict';

const Utils = (function () {
  const TOKENKEY = 'cachedRestrictedToken';
  const TOKEN_EXPIRATION_TIME_SHIFT_IN_MS = 60 * 1000;
  const TOKEN_EXPIRATION_10_MIN_IN_MS = 10 * 60 * 1000;

  // Cache unchanged device information
  let DEVICE_INFO = null;

  let slotId = 0;
  let slotIdChanged = false;

  SettingsListener.observe('ril.data.defaultServiceId', 0, (id) => {
    slotId = id;
    slotIdChanged = true;
  });

  function getDeviceInfo() {
    if (DEVICE_INFO !== null) {
      return Promise.resolve(DEVICE_INFO);
    }

    const deviceInfoQuery = {
      'deviceinfo.cu': '',
      'app.update.custom': '',
      'deviceinfo.platform_build_id': '',
      'deviceinfo.build_number': '',
      'deviceinfo.os': 'unknown',
      'deviceinfo.hardware': 'unknown',
      'deviceinfo.software': 'unknown',
      'deviceinfo.product_model': '',
      'deviceinfo.platform_version': '',
      'apps.serviceCenterUrl': ''
    };

    return new Promise((resolve) => {
      getSettings(deviceInfoQuery).then((deviceInfo) => {
        DEVICE_INFO = deviceInfo;
        resolve(deviceInfo);
      });
    });
  }

  function getConnectionType() {
    let type = 'unknown';
    if (navigator.mozWifiManager &&
      navigator.mozWifiManager.connection.status === 'connected') {
      type = 'wifi';
    } else if (navigator.mozMobileConnections &&
      navigator.mozMobileConnections[slotId].data.connected) {
      type = 'cell';
    }

    return type;
  }

  function connectionType() {
    if (navigator.mozWifiManager &&
      navigator.mozWifiManager.connection.status === 'connected') {
      return 'wifi';
    }

    const conns = window.navigator.mozMobileConnection ||
      window.navigator.mozMobileConnections;
    return conns[slotId].data.type;
  }

  function getTimeZoneOffset() {
    const t = new Date();
    let tzo = -t.getTimezoneOffset();
    if (tzo !== 0) {
      tzo = tzo / 60;
    }
    return tzo;
  }

  function getTimeStamp() {
    const t = new Date();
    const tzo = -t.getTimezoneOffset();
    const dif = tzo >= 0 ? '+' : '-';
    return (
      t.getFullYear() +
      '-' +
      (t.getMonth() + 1).toString().padStart(2, '0') +
      '-' +
      t.getDate().toString().padStart(2, '0') +
      'T' +
      t.getHours().toString().padStart(2, '0') +
      ':' +
      t.getMinutes().toString().padStart(2, '0') +
      ':' +
      t.getSeconds().toString().padStart(2, '0') +
      dif +
      Math.abs(tzo / 60).toString().padStart(2, '0') +
      ':' +
      Math.abs(tzo % 60).toString().padStart(2, '0')
    );
  }

  function getSettings(settingKeysAndDefaults) {
    const results = {};

    function run(gen) {
      return new Promise((resolve) => {
        const g = gen();

        function next(data) {
          const result = g.next(data);

          if (result.done) {
            return resolve(results);
          }

          result.value.then((data) => next(data));
        }

        next();
      });
    }

    function* generator() {
      for (let key in settingKeysAndDefaults) {
        let defaultValue = settingKeysAndDefaults[key];
        yield query(key, defaultValue);
      }
    }

    function query(key, defaultValue) {
      return navigator.mozSettings.createLock().get(key).then((result) => {
        let value = result[key];

        if (!value) {
          value = defaultValue;
        }

        results[key] = value;
      });
    }

    return run(generator);
  }

  function getImeiCode() {
    return new Promise((resolve) => {
      const cache = localStorage.getItem('imei');
      if (cache && !slotIdChanged) return resolve(cache);

      navigator.mozMobileConnections[slotId].getDeviceIdentities()
        .then((deviceInfo) => {
          if (deviceInfo.imei) {
            resolve(deviceInfo.imei);
            localStorage.setItem('imei', deviceInfo.imei);
            slotIdChanged = false;
          }
        });
    });
  }

  function isNoSIM() {
    const mozConnections = navigator.mozMobileConnections;

    for (let i = 0; i < mozConnections.length; i++) {
      if (mozConnections[i].iccId) {
        return false;
      }
    }

    return true;
  }

  function showPaidApps() {
    return new Promise((resolve, reject) => {
      if (isNoSIM()) {
        reject();
      } else {
        new Kaipay({ data: { type: 'profile' } })
          .then((result) => {
            if (result) {
              resolve();
            }
          })
          .catch((error) => {
            reject(error);
          });
      }
    });
  }

  function getRestrictedToken() {
    return new Promise((resolve, reject) => {
      const cachedRestrictedToken = JSON.parse(localStorage.getItem(TOKENKEY));

      if (cachedRestrictedToken &&
          cachedRestrictedToken.tokenExpirationDate > Date.now()) {
        // use cached token
        resolve(cachedRestrictedToken);
        return;
      }

      // fetch restricted token
      navigator.kaiAuth.getRestrictedToken('apps')
        .then((credential) => {
          let expires_in = 0;

          if ('expiresInSeconds' in credential) {
            expires_in = credential.expiresInSeconds * 1000 -
              TOKEN_EXPIRATION_TIME_SHIFT_IN_MS;
          } else {
            expires_in = TOKEN_EXPIRATION_10_MIN_IN_MS;
          }

          resolve(credential);
          credential.tokenExpirationDate = expires_in + Date.now();
          localStorage.setItem(TOKENKEY, JSON.stringify(credential));
        })
        .catch(() => reject());
    });
  }

  return {
    getImeiCode,
    getSettings,
    getRestrictedToken,
    slotId,
    getDeviceInfo,
    getConnectionType,
    getTimeZoneOffset,
    getTimeStamp,
    connectionType,
    showPaidApps
  };
}());

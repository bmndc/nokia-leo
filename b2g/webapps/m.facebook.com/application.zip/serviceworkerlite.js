/**
 * (c) Facebook, Inc. and its affiliates. Confidential and proprietary.
 */

const BUMP_EVENT_LIFECYCLE_KEY = 'push_event';
const LOG_NDID_URI =
  'https://m.facebook.com/notifications/client/push/kaios/delivered/';
const LOG_CLICKED_URI =
  'https://m.facebook.com/notifications/client/push/kaios/clicked/';
const FBLITE_FOR_KAIOS_APPID = 2031026267189037;

const USE_DEFERRED_PUSH = 'use_deferred_push';
const LOG_PUSH_EVENTS = 'log_push_events';
const DEFERRED_PUSH_NOTIF_TYPE = 'deferredPushNotif';
const CLOSE_ACTION_STRING = "Dismiss";
const OPEN_ACTION_STRING = "Open";
const CANARY_CACHE_KEY = "canary";

self.addEventListener('push', event => {
  if (!event.data || !event.data.json) {
    return;
  }
  const pushEventData = event.data.json();
  let iconURL = '/img/icons/fb_logo128x128.png';
  if (pushEventData.ppu) {
    var regexp = /^https?:\/\//i;
    if (regexp.test(pushEventData.ppu)) {
      iconURL = pushEventData.ppu;
    }
  }
  var title = pushEventData.title ? pushEventData.title : '';

  event.waitUntil(
    genPushOptions(pushEventData, iconURL, event.timeStamp).then(options => {
        return genGK(USE_DEFERRED_PUSH).then(shouldUseDeferredPushRes => {
            return handlePushEvent(shouldUseDeferredPushRes, title, options);
        }).then(genLogEvent(LOG_NDID_URI, pushEventData));
    }).catch(function(err) {
    })
  );

});


self.addEventListener('fetch', event => {
  // Let the browser do its default thing
  // for non-GET requests.
  if (
    event.request.method != 'GET' ||
    !event.request.url.endsWith('?usecache')
  ) {
    return;
  }

  event.respondWith(
    (function() {
      // Try to get the response from cache.
      return caches
        .open(CANARY_CACHE_KEY)
        .then(cache => {
          return cache.match(event.request).then(cachedResponse => {
            if (cachedResponse) {
              return cachedResponse;
            }
            return fetch(event.request);
          });
        })
        .catch(() => {
          // fallback to fetch in case open/match fails.
          return fetch(event.request);
        });
    })()
  );
});

self.addEventListener('notificationclick', event => {
  const notification = event.notification;
  switch (event.action) {
    case 'close':
      if (notification.data && !notification.data.dismiss_saves) {
        notification.close();
      }
      break;
    default:
      const fbNotif = JSON.stringify(notification.data.fbNotif);
      event.waitUntil(
        getAppWindow().then(fbWindow => {
          if (fbWindow) {
            fbWindow.postMessage(fbNotif);
          } else {
            return self.clients.openApp({msg: fbNotif});
          }
        }).then(genLogEvent(LOG_CLICKED_URI, notification.data.fbNotif))
      );
      if (notification.data && notification.data.open_deletes) {
        notification.close();
      }
  }
});

function getAppWindow() {
  return self.clients
    .matchAll({
      includeUncontrolled: true,
      type: 'window',
    })
    .then(function(clientList) {
      // Check all open windows for one that matches the FB app URL
      for (var i = 0; i < clientList.length; i++) {
        const client = clientList[i];
        if (new RegExp('app://m.facebook.com', 'i').test(client.url)) {
          return client;
        }
      }
      return null;
    });
}

function handlePushEvent(shouldUseDeferredPush, title, options) {
  return getAppWindow().then(fbWindow => {
    if (!fbWindow || shouldUseDeferredPush === false) {
      return self.registration.showNotification(title, options);
    }
    return new Promise(function(resolve, reject) {
      const pushPayload = {
        type: DEFERRED_PUSH_NOTIF_TYPE,
        payloadTitle: title,
        payloadOptions: options,
      };
      fbWindow.postMessage(JSON.stringify(pushPayload));
      resolve(pushPayload);
    });
  });
}

function genPushOptions(pushEventData, iconURL, eventTimeSpent) {
    var closePromise = genTranslation(CLOSE_ACTION_STRING, CLOSE_ACTION_STRING);
    var openPromise = genTranslation(OPEN_ACTION_STRING, OPEN_ACTION_STRING);
    return Promise.all([closePromise, openPromise]).then(values => {
        var closeActionText = (values[0] === undefined) ? CLOSE_ACTION_STRING : values[0];
        var openActionText = (values[1] === undefined) ? OPEN_ACTION_STRING : values[1];
        return {
            actions: pushEventData.actions || [
                {action: 'close', title: closeActionText},
                {action: 'open', title: openActionText},
            ],
            body: pushEventData.message || '',
            icon: iconURL,
            tag: pushEventData.i || pushEventData.t || 'n' + Date.now(),
            dir: 'auto',
            data: {
                fbNotif: pushEventData,
                dismiss_saves: !!pushEventData.dismiss_saves,
                open_deletes: !!pushEventData.open_deletes,
            },
            timestamp: pushEventData.time || eventTimeSpent,
            renotify: true,
            requireInteraction: true,
        };
    });
}

function genLogEvent(uri, eventData) {
  return genGK(LOG_PUSH_EVENTS).then( shouldLog =>
    {
      if (!shouldLog) {
        return null;
      }
      try {
        const dataToSend = new Map();
        dataToSend.set('appid', FBLITE_FOR_KAIOS_APPID);
        if (eventData) {
          if (eventData.hasOwnProperty('i')) {
            dataToSend.set('notif_id', eventData.i);
          }
          if (eventData.hasOwnProperty('d')) {
            dataToSend.set('ndid', eventData.d);
          }
          if (eventData.hasOwnProperty('type')) {
            dataToSend.set('notif_type', eventData.type);
          }
        }
        dataToSend.set(BUMP_EVENT_LIFECYCLE_KEY, true);

        return genSendDataToUri(uri, dataToSend).catch(() => {});
      } catch (_) {
        // failed to send log, nothing we can do about it
      }
    });
}

// ============ ServiceWorkerRequest ================

function genJsonFromUri(requestInfo) {
  return genFetchUri(requestInfo).then(response => {
    return response.text().then(body => {
      if (!body || body === '') {
        return body;
      }

      // Strip the shield.
      // This should use `CSRFGuard.clean` instead.
      const dataString = body.substring(9);
      return JSON.parse(dataString);
    });
  });
}

function genSendDataToUri(url, data) {
  const toAppend = serializeData(data);
  return genJsonFromUri(url + '?' + toAppend);
}

function genFetchUri(requestInfo) {
  const request =
    requestInfo instanceof Request
      ? requestInfo
      : new Request(requestInfo, {credentials: 'include', mode: 'no-cors'});

  return fetch(request);
}

function serializeData(map) {
  const kvPairs = [];
  const componentsObject = flattenQueryData(map);

  for (var component in componentsObject) {
    if (Object.prototype.hasOwnProperty.call(componentsObject, component)) {
      var key = encodeURIComponent(component);
      if (componentsObject[component] === undefined) {
        kvPairs.push(key);
      } else {
        kvPairs.push(
          key + '=' + encodeURIComponent(componentsObject[component]));
      }
    }
  }

  return kvPairs.join('&');
}

function flattenQueryData(map, name, componentsObject) {
  name = name || '';
  componentsObject = componentsObject || {};
  if (map === null || map === undefined) {
    componentsObject[name] = undefined;
  } else if (map instanceof Map) {
    for (var [key, value] of map.entries()) {
      if (value !== undefined) {
        flattenQueryData(
          value,
          name ? name + '[' + key + ']' : key,
          componentsObject);
      }
    }
  } else {
    componentsObject[name] = map;
  }
  return componentsObject;
}

// ============ TranslationStore ================

const TRANSLATION_DB_NAME = "translations";
const TRANSLATION_STORE_NAME = "translations";

var translationCache = {};

function genTranslation(key, defaultVal) {
    if (translationCache[key] !== undefined) {
        return Promise.resolve(translationCache[key]);
    }
    return getData(TRANSLATION_DB_NAME, TRANSLATION_STORE_NAME, key).then(val => {
        translationCache[key] = val;
        return translationCache[key];
    }).catch(function(err) {
        return defaultVal;
    });
}

// ============ GKStore ================

const GK_DB_NAME = "gks";
const GK_STORE_NAME = "gks";

var gkCache = {};

function genGK(key) {
  if (gkCache[key] !== undefined) {
    return new Promise(function(resolve, reject) {
      resolve(gkCache[key]);
    });
  }
  return getData(GK_DB_NAME, GK_STORE_NAME, key).then(val => {
    gkCache[key] = (val === 'true');
    return gkCache[key];
  });
}

// ============ IndexedDB ================

const READ_ONLY = "readonly";

function getDB(dbName){
    return new Promise(function (resolve, reject) {
        var openRequest = self.indexedDB.open(dbName);
        openRequest.onsuccess = function (event) {
            resolve(openRequest.result);
        }
        openRequest.onerror = function (event) {
            reject(event.error);
        }
    });
}

function promisifyRequest(transaction, request){
    return new Promise(function (resolve, reject) {
        request.onsuccess = function (event) {
            resolve(event.target.result);
        }
        request.onerror = function (event) {
            reject(event.error);
        }
    }).then(function(res) {
        return new Promise(function (resolve, reject) {
            transaction.oncomplete = function (event) {
                resolve(res);
            }
            transaction.onerror = function (event) {
                reject(event.error);
            }
        });
    });
}

function getData(dbName, storeName, key){
    return getDB(dbName).then(function(db) {
        var transaction = db.transaction(storeName,READ_ONLY);
        var objectStore = transaction.objectStore(storeName);
        var request = objectStore.get(key);
        return promisifyRequest(transaction, request);
    });
}

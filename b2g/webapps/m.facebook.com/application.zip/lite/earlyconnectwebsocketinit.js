/**
 * (c) Facebook, Inc. and its affiliates. Confidential and proprietary.
 */

(function() {
    let host = null;
    var token = window.localStorage.getItem('sharedprefs.default.transient_token_int');
    if (!token) {
        token = "";
    }
    const hostsString = window.localStorage.getItem(
        'sharedprefs.default.tcp_server_addresses_paid'
    );

    if (hostsString) {
        let hostsList;
        try {
            hostsList = JSON.parse(hostsString);
        } catch(_) {
            return;
        }

        if (hostsList.length) {
            host = hostsList[0];
        }
    }
    if (!host) {
        return;
    }
    // Proxygen expects the token string to be 10 chars and padded with 0.
    const padding = '0'.repeat(10 - token.length);
    window.__lws = new WebSocket('wss://' + host + ':443/ws/' + padding + token);
})();

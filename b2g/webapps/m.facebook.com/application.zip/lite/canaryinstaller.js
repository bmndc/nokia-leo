/**
 * (c) Facebook, Inc. and its affiliates. Confidential and proprietary.
 */

const ENDPOINT = "https://m.facebook.com/kaiosapp/jio/canary/?group=";
const HASH_KEY = "canary_hash";
const CANARY_CACHE_KEY = "canary";
const SHARED_PREFS_PREFIX = "sharedprefs.default.";
const IS_CANARY_KEY = SHARED_PREFS_PREFIX + "kite_is_canary";
const CANARY_GROUP_KEY = SHARED_PREFS_PREFIX + "kite_canary_group";
const URL = document.currentScript.getAttribute('value');
var installerFrame;


window.addEventListener("message", receiveMessage, false);

if (document.readyState == "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}

function init() {
    var isCanary = localStorage.getItem(IS_CANARY_KEY);
    if (isCanary !== "true") {
      clearCache();
      return;
    }

    var group = localStorage.getItem(CANARY_GROUP_KEY);
    if (!group) {
        return;
    }
    var url = ENDPOINT + group;
    var hash = localStorage.getItem(HASH_KEY);
    if (hash) {
        url += '&hash=' + hash;
    }
    installerFrame = createInvisibleIframe();
    installerFrame.src = url;
    if (window.KiteClientLogger) {
      installerFrame.onload = _ => {
        window.KiteClientLogger.logEvent('canary_installer_frameloaded');
      }
    }

    document.body.appendChild(installerFrame);
}

function createInvisibleIframe() {
  const frame = document.createElement('iframe');
  frame.style = "display:none";
  frame.tabIndex = -1;
  return frame;
}

function receiveMessage(event)
{
   const logger = window.KiteClientLogger || { logEvent:()=> {}};
   if (!event.data || !event.data.result) {
      logger.logEvent('canary_installer_invalid');
      return;
    }
    unload();
    if (event.data.result === "noupdate") {
      logger.logEvent('canary_installer_noupdate');
      return;
    }
    if (event.data.result === 'removed') {
      logger.logEvent('canary_installer_removed');
      clearCache();
      return;
    }
    caches.open(CANARY_CACHE_KEY).then(cache => {
        var init = new Object();
        init.url = URL;
        return cache.put(init.url, new Response(event.data.payload, init));
    }).then(() => {
      localStorage.setItem(HASH_KEY, event.data.hash);
      logger.logEvent('canary_installer_updated');
    });
}

function unload() {
  window.removeEventListener("message", receiveMessage, false);
  if (document.body && document.body.contains(installerFrame)) {
      document.body.removeChild(installerFrame);
   }
}

function clearCache() {
  if (window.KiteClientLogger) {
    window.KiteClientLogger.logEvent('canary_installer_clear');
  }
  localStorage.removeItem(HASH_KEY);
  localStorage.removeItem(IS_CANARY_KEY);
  localStorage.removeItem(CANARY_GROUP_KEY);
  caches.delete(CANARY_CACHE_KEY);
}


(function(exports){'use strict';let CONTENT_TYPE='application/xml';let AUTHTYPE_MAPPING={'PAP':'1','CHAP':'2'};let TYPE_MAPPING={'w2':'default','25':'default','110':'default','143':'default','w4':'mms','ap0004':'supl'};function ParsedProvisioningDoc(provisioningDoc){this._provisioningDoc=provisioningDoc;this._applicationNodes=null;this._napDefNodes=null;this._pxLogicalNodes=null;this._pxPhysicalNodes=null;this._apns=[];this._proxies=[];this._apnsReady=false;}
ParsedProvisioningDoc.prototype.getPxPhysicalNodes=function(toProxyNode){let toProxy=toProxyNode.getAttribute('value');let pxLogicalNode=null,i=0;for(i=0;i<this._pxLogicalNodes.length;i++){let selector='parm[name="PROXY-ID"][value="'+toProxy+'"]';pxLogicalNode=this._pxLogicalNodes[i].querySelector(selector);if(pxLogicalNode){break;}}
if(!pxLogicalNode){return null;}
return this._pxLogicalNodes[i].querySelectorAll('characteristic[type="PXPHYSICAL"]');};ParsedProvisioningDoc.prototype.getNapDefNode=function(toNapId){for(let i=0;i<this._napDefNodes.length;i++){let selector='parm[name="NAPID"][value="'+toNapId+'"]';let napDefNode=this._napDefNodes[i].querySelector(selector);if(napDefNode){return this._napDefNodes[i];}}
return null;};ParsedProvisioningDoc.prototype.parse=function(){if(!this._provisioningDoc){return;}
function parsePxPhysicalNode(pxPhysicalNode,isMmsProxy){let obj={};let proxyKey=null,portKey=null;proxyKey=isMmsProxy?'mmsproxy':'proxy';portKey=isMmsProxy?'mmsport':'port';let pxAddrNode=pxPhysicalNode.querySelector('parm[name="PXADDR"]');if(pxAddrNode){obj[proxyKey]=pxAddrNode.getAttribute('value');}
obj['TO-NAPID']=[];let toNapIdNodes=pxPhysicalNode.querySelectorAll('parm[name="TO-NAPID"]');if(toNapIdNodes){for(let i=0;i<toNapIdNodes.length;i++){let toNapIdNode=toNapIdNodes[i];if(toNapIdNode){obj['TO-NAPID'].push(toNapIdNode.getAttribute('value'));}}}
let portNodes=pxPhysicalNode.querySelectorAll('characteristic[type="PORT"]');for(let j=0;j<portNodes.length;j++){let portNode=portNodes[j].querySelector('parm[name="PORTNBR"]');obj[portKey]=portNode.getAttribute('value');}
let proxyIdNode=pxPhysicalNode.querySelector('parm[name="PHYSICAL-PROXY-ID"]');if(proxyIdNode){obj.pxPhId=proxyIdNode.getAttribute('value');}
let pxPhDomainNode=pxPhysicalNode.querySelector('parm[name="DOMAIN"]');if(pxPhDomainNode){obj.pxPhDomain=pxPhDomainNode.getAttribute('value');}
return obj;}
function parseNapDefNode(napDefNode){function parseValidityNode(validityNode){let obj={};let countryNode=validityNode.querySelector('parm[name="COUNTRY"]');if(countryNode){obj.countrycode=countryNode.getAttribute('value');}
let networkNode=validityNode.querySelector('parm[name="NETWORK"]');if(networkNode){obj.networkcode=networkNode.getAttribute('value');}
let systemIdNode=validityNode.querySelector('parm[name="SID"]');if(systemIdNode){obj.sid=systemIdNode.getAttribute('value');}
let socNode=validityNode.querySelector('parm[name="SOC"]');if(socNode){obj.soc=socNode.getAttribute('value');}
let valduntilNode=validityNode.querySelector('parm[name="VALIDUNTIL"]');if(valduntilNode){obj.validuntil=valduntilNode.getAttribute('value');}
return obj;}
let obj={};let napIdNode=napDefNode.querySelector('parm[name="NAPID"]');if(napIdNode){obj.NAPID=napIdNode.getAttribute('value');}
let nameNode=napDefNode.querySelector('parm[name="NAME"]');if(nameNode){obj.carrier=nameNode.getAttribute('value');}
let apnNode=napDefNode.querySelector('parm[name="NAP-ADDRESS"]');if(apnNode){obj.apn=apnNode.getAttribute('value');}
let apnFormatNode=napDefNode.querySelector('parm[name="NAP-ADDRTYPE"]');if(apnFormatNode){obj.apnFormat=apnFormatNode.getAttribute('value');}
let napAuthInfoNode=napDefNode.querySelector('characteristic[type="NAPAUTHINFO"]');if(napAuthInfoNode){let authTypeNode=napAuthInfoNode.querySelector('parm[name="AUTHTYPE"]');if(authTypeNode){let authType=AUTHTYPE_MAPPING[authTypeNode.getAttribute('value')];if(authType){obj.authtype=authType;}}
let authNameNode=napAuthInfoNode.querySelector('parm[name="AUTHNAME"]');if(authNameNode){obj.user=authNameNode.getAttribute('value');}
let authSecretNode=napAuthInfoNode.querySelector('parm[name="AUTHSECRET"]');if(authSecretNode){obj.password=authSecretNode.getAttribute('value');}
let authentryNode=napAuthInfoNode.querySelector('parm[name="AUTH-ENTITY"]');if(authentryNode){obj.authEnty=authentryNode.getAttribute('value');}
let authSpiNode=napAuthInfoNode.querySelector('parm[name="SPI"]');if(authSpiNode){obj.spi=authSpiNode.getAttribute('value');}}
let validityNode=napDefNode.querySelector('characteristic[type="VALIDITY"]');if(validityNode){obj.validity=parseValidityNode(validityNode);}
return obj;}
let parser=new DOMParser();let domDocument=parser.parseFromString(this._provisioningDoc,CONTENT_TYPE);this._applicationNodes=domDocument.querySelectorAll('characteristic[type="APPLICATION"]');this._napDefNodes=domDocument.querySelectorAll('characteristic[type="NAPDEF"]');this._pxLogicalNodes=domDocument.querySelectorAll('characteristic[type="PXLOGICAL"]');this._pxPhysicalNodes=domDocument.querySelectorAll('characteristic[type="PXPHYSICAL"]');let napDefNode=null;let apn=null;let type=[];let proxy=null;if(!this._applicationNodes.length){for(let i=0;i<this._napDefNodes.length;i++){napDefNode=this._napDefNodes[i];apn=parseNapDefNode(napDefNode);let defapn={};for(let key in apn){defapn[key]=apn[key];}
type=[];type.push('default');defapn.types=type;this._apns.push(defapn);let suplapn={};for(let key in apn){suplapn[key]=apn[key];}
type=[];type.push('supl');suplapn.types=type;this._apns.push(suplapn);}
for(let i=0;i<this._pxPhysicalNodes.length;i++){let pxPhysicalNode=this._pxPhysicalNodes[i];proxy=parsePxPhysicalNode(pxPhysicalNode,false);this._proxies.push(proxy);}
return;}
let applicationNode=null;for(let j=0;j<this._applicationNodes.length;j++){applicationNode=this._applicationNodes[j];let appIdNode=null,appId=null;appIdNode=applicationNode.querySelector('parm[name="APPID"]');appId=appIdNode.getAttribute('value');let toProxyNodes=null;toProxyNodes=applicationNode.querySelectorAll('parm[name="TO-PROXY"]');let toNapIdNodes=null;toNapIdNodes=applicationNode.querySelectorAll('parm[name="TO-NAPID"]');let addrNode=null,addr=null;addrNode=applicationNode.querySelector('parm[name="ADDR"]');if(addrNode){addr=addrNode.getAttribute('value');}
if(appId&&(appId!=='w2')&&(appId!=='w4')){continue;}
if(!toNapIdNodes&&!toProxyNodes){continue;}
type=[];type.push(TYPE_MAPPING[appId]);if(toProxyNodes){for(let l=0;l<toProxyNodes.length;l++){let pxPhysicalNodes=this.getPxPhysicalNodes(toProxyNodes[l]);if(!pxPhysicalNodes){continue;}
for(let m=0;m<pxPhysicalNodes.length;m++){proxy=parsePxPhysicalNode(pxPhysicalNodes[m],(TYPE_MAPPING[appId]==='mms'));this._proxies.push(proxy);for(let n=0;n<proxy['TO-NAPID'].length;n++){napDefNode=this.getNapDefNode(proxy['TO-NAPID'][n]);apn=parseNapDefNode(napDefNode);apn.types=type;if((TYPE_MAPPING[appId]==='mms')&&addr){apn.mmsc=addr;}
this._apns.push(apn);}}}}
if(toNapIdNodes){for(let o=0;o<toNapIdNodes.length;o++){let toNapId=toNapIdNodes[o].getAttribute('value');if(!toNapId){continue;}
napDefNode=this.getNapDefNode(toNapId);apn=parseNapDefNode(napDefNode);apn.types=type;if((TYPE_MAPPING[appId]==='mms')&&addr){apn.mmsc=addr;}
this._apns.push(apn);}}}};ParsedProvisioningDoc.prototype.getApns=function(){function addProperties(src,dst){for(let key in src){dst[key]=src[key];}}
if(this._apnsReady){return this._apns;}
for(let i=0;i<this._proxies.length;i++){let proxy=this._proxies[i];for(let j=0;j<proxy['TO-NAPID'].length;j++){let TO_NAPID=proxy['TO-NAPID'][j];for(let k=0;k<this._apns.length;k++){let apn=this._apns[k];if(TO_NAPID===apn.NAPID){addProperties(proxy,apn);}}}}
this._apnsReady=true;return this._apns;};ParsedProvisioningDoc.prototype.from=function(provisioningDoc){let obj=new ParsedProvisioningDoc(provisioningDoc);obj.parse();return obj;};exports.ParsedProvisioningDoc=new ParsedProvisioningDoc();})(window);